import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Modifier;

import org.junit.Test;


public abstract class Student {
	protected String studentName;
	protected String studentClass;
	protected static int totalNoOfStudents=0;
	static int getTotalNoOfStudents()
	{
		return totalNoOfStudents;
	}
	public Student()
	{}
	public Student(String studentName, String studentClass) {
		this.studentName = studentName;
		this.studentClass = studentClass;
		totalNoOfStudents++;
	}
	abstract public int getPercentage();
	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentClass="
				+ studentClass + "]";
	}	
}
class HistoryStudent extends Student{
	private int historyMarks;
	private int civicsMarks;
	
	public HistoryStudent()
	{}

	public HistoryStudent(String studentName,String studentClass,int historyMarks, int civicsMarks) {
		super(studentName,studentClass);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}


	public String displayHistoryStudent() {
		return "HistoryStudent [historyMarks=" + historyMarks
				+ ", civicsMarks=" + civicsMarks + ", studentName="
				+ studentName + ", studentClass=" + studentClass + ", Total Student="+ totalNoOfStudents+"]";
	}
	@Override
	public int getPercentage() {
	
		return ((historyMarks+civicsMarks)*100)/200;
	}
}

class ScienceStudent extends Student {
	private int physicsMarks;
	private int chemistryMarks;
	private int mathsMarks;
	
	@Override
	public int getPercentage() {

		return ((physicsMarks+chemistryMarks+mathsMarks)*100)/300;
	}
	public ScienceStudent()
	{}
	public ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}	
	
	public String displayScienceStudent() {
		return "ScienceStudent [physicsMarks=" + physicsMarks
				+ ", chemistryMarks=" + chemistryMarks + ", mathsMarks="
				+ mathsMarks + ", studentName=" + studentName
				+ ", studentClass=" + studentClass + ", Total Student="+ totalNoOfStudents+"]";
	}	
}

class StudentTester {
	public static void main(String[] args) {
		ScienceStudent scienceStudent = new ScienceStudent("RAJ", "JAVA", 55,66, 88);
		System.out.println(scienceStudent.displayScienceStudent());
		HistoryStudent historyStudent = new HistoryStudent("kumar",
				"indian history", 50, 60);
		System.out.println(historyStudent.displayHistoryStudent());
		System.out.println(scienceStudent.getPercentage());
		System.out.println(historyStudent.getPercentage());
	}
}
