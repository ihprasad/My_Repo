import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


public class COJ_CE_01_EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public final void testCalculateGrossSalary() {
		fail("Not yet implemented"); // TODO
	}

}
