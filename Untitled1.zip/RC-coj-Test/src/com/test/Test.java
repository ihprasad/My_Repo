package com.test;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double i = 550.00;
		System.out.println(i * 20/(double)100);

	}
}