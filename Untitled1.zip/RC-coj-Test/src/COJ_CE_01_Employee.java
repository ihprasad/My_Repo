public class COJ_CE_01_Employee {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer;
	}
}

class COJ_CE_01_Manager {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	double projectAllowance;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer + projectAllowance;
	}
}

class COJ_CE_01_Trainer {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	double perkPerBatch;
	int batchCount;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer
				+ ((double) batchCount * perkPerBatch);
	}
}

class COJ_CE_01_Sourcing {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;

	public double calculateGrossSalary() {
		return basicSalary
				+ HRAPer
				+ DAPer
				+ (((enrollmentReached / enrollmentTarget) * 100) * perkPerEnrollment);
	}
}

class COJ_CE_TaxUtil {
	public double calculateTax(COJ_CE_01_Employee emp) {
		if (emp.calculateGrossSalary() > 30000)
				return emp.calculateGrossSalary() * 20 / 100;
		else 
			return emp.calculateGrossSalary() * 5 / 100;
	}

	public double calculateTax(COJ_CE_01_Manager mgr) {
		if (mgr.calculateGrossSalary() > 30000)
			return mgr.calculateGrossSalary() * 20 / 100;
	else 
		return mgr.calculateGrossSalary() * 5 / 100;
	}

	public double calculateTax(COJ_CE_01_Trainer tr) {
		if (tr.calculateGrossSalary() > 30000)
			return tr.calculateGrossSalary() * 20 / 100;
	else 
		return tr.calculateGrossSalary() * 5 / 100;
	}

	public double calculateTax(COJ_CE_01_Sourcing sr) {
		if (sr.calculateGrossSalary() > 30000)
			return sr.calculateGrossSalary() * 20 / 100;
	else 
		return sr.calculateGrossSalary() * 5 / 100;
	}
}