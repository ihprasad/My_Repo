
import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.Test;

public class StudentTest {
	@Test
	public void StudentAbstractTest() {
		try {
			assertTrue(Class.forName("Student").getModifiers() == (Modifier.ABSTRACT + Modifier.PUBLIC));
			System.out
					.println("#####StudentModifierTest | Passed | 10 / 10 | Passed for StudentModifierTest#####");
		} catch (AssertionError e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0 / 10 | Failed for StudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() +"#####");
		}
	}


	@Test
	public void historyStudentDefaultConstructorTest() {
		try
		{			
			assertNotNull(new HistoryStudent());
			System.out.println("#####HistoryStudentDefaultConstructorTest | Passed | 10 / 10 | Passed for HistoryStudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 | Failed for HistoryStudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	
	@Test
	public void historyStudentParameterizedConstructorTest() {
		try
		{			
			assertNotNull(new HistoryStudent("RAJ","INTER",55, 77));
			System.out.println("#####HistoryStudentParameterizedConstructorTest | Passed | 20 / 20 | Passed for HistoryStudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 20 | Failed for HistoryStudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
		
	
		
	@Test
	public void HistoryStudentModifierTest() {
		try
		{			
			int modifier1=new HistoryStudent().getClass().getDeclaredFields()[0].getModifiers();
			int modifier2=new HistoryStudent().getClass().getDeclaredFields()[1].getModifiers();
			assertTrue(modifier1 == Modifier.PRIVATE && modifier2 == Modifier.PRIVATE);
			System.out.println("#####HistoryStudentModifierTest | Passed | 10 / 10 | Passed for HistoryStudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentModifierTest | Failed | 0 / 40 | Failed for HistoryStudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentModifierTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void HistoryStudentgetPercentageTest() {
		try
		{			
			assertEquals(75,new HistoryStudent("Satya","9",70,80).getPercentage());
			System.out.println("#####HistoryStudentgetPercentageTest | Passed | 10 / 10 | Passed for HistoryStudentgetPercentageTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 40 | Failed for HistoryStudentgetPercentageTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	@Test
	public void HistoryStudentInheritanceTest() {
		try
		{			
			assertTrue(new HistoryStudent().getClass().getSuperclass().getName().equals("Student"));
			System.out.println("#####HistoryStudentInheritance | Passed | 10 / 10 | Passed for HistoryStudentInheritance#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentInheritance | Failed | 0 / 40 | Failed for HistoryStudentInheritance#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentInheritance | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentInheritance | Failed | 0 / 40 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	



	@Test
	public void studentDefaultConstructorTest() {
		try
		{			
			assertNotNull(new ScienceStudent());
			System.out.println("#####ScienceStudentDefaultConstructorTest | Passed | 10 / 10 | Passed for ScienceStudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 40 | Failed for ScienceStudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	
	@Test
	public void studentParameterizedConstructorTest() {
		try
		{			
			assertNotNull(new ScienceStudent("RAJ","JAVA",55,66,88));
			System.out.println("#####ScienceStudentParameterizedConstructorTest | Passed | 20 / 20 | Passed for ScienceStudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 20 | Failed for ScienceStudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
		
	
	@Test
	public void ScienceStudentDisplayMethodTest() {
		try
		{			
			ScienceStudent scienceStudent=new ScienceStudent("RAJ","JAVA",55,66,88);
			assertEquals("ScienceStudent [physicsMarks=55, chemistryMarks=66, mathsMarks=88, studentName=RAJ, studentClass=JAVA, Total Student=3]",scienceStudent.displayScienceStudent());			
			System.out.println("#####StudentDisplayMethodTest | Passed | 20 / 20 | Passed for ScienceStudentDisplayMethodTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentDisplayMethodTest | Failed | 0 / 20 | Failed for ScienceStudentDisplayMethodTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####ScienceStudentDisplayMethodTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentDisplayMethodTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}	
	
	
	@Test
	public void ScienceStudentModifierTest() {
		try
		{			
			int modifier1=new ScienceStudent().getClass().getDeclaredFields()[0].getModifiers();
			int modifier2=new ScienceStudent().getClass().getDeclaredFields()[1].getModifiers();
			int modifier3=new ScienceStudent().getClass().getDeclaredFields()[1].getModifiers();
			assertTrue(modifier1 == Modifier.PRIVATE && modifier2 == Modifier.PRIVATE && modifier3 == Modifier.PRIVATE);
			System.out.println("#####ScienceStudentModifierTest | Passed | 10 / 10 | Passed for ScienceStudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentModifierTest | Failed | 0 / 40 | Failed for ScienceStudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentModifierTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	@Test
	public void ScienceStudentgetPercentageTest() {
		try
		{			
			assertEquals("69",new ScienceStudent("RAJ","JAVA",55,66,88).getPercentage());
			System.out.println("#####ScienceStudentgetPercentageTest | Passed | 10 / 10 | Passed for ScienceStudentgetPercentageTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 40 | Failed for ScienceStudentgetPercentageTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void ScienceStudentInheritanceTest() {
		try
		{			
			assertTrue(new ScienceStudent().getClass().getSuperclass().getName().equals("Student"));
			System.out.println("#####ScienceStudentInheritance | Passed | 10 / 10 | Passed for ScienceStudentInheritance#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentInheritance | Failed | 0 / 40 | Failed for ScienceStudentInheritance#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentInheritance | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentInheritance | Failed | 0 / 40 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	
}