import java.util.HashMap;
import java.util.Map;

public class COJ_31_EmployeeDetailsMap {

	private Map<Integer, String> employeeIdNameMap;

	// TODO getter/setter

	public COJ_31_EmployeeDetailsMap() {
		employeeIdNameMap = new HashMap<Integer, String>();
	}

	public COJ_31_EmployeeDetailsMap(Map<Integer, String> employeeIdNameMap) {
		this.employeeIdNameMap = employeeIdNameMap;
	}

	public Map<Integer, String> getEmployeeIdNameMap() {
		return employeeIdNameMap;
	}

	public void setEmployeeIdNameMap(Map<Integer, String> employeeIdNameMap) {
		this.employeeIdNameMap = employeeIdNameMap;
	}

	public String getEmployeeName(int employeeId) {
		if (employeeIdNameMap == null)
			return null;
		String s = employeeIdNameMap.get(employeeId);
		return (s != null) ? s : null;
	}
}