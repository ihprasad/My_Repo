import java.util.HashMap;

import java.util.Map;

public class COJ_28_ArrayToMap {

	public static Map convertToMap(String[] names) {
		// ADD YOUR CODE HERE

		if (names == null || names.length == 0)
			return null;

		HashMap lhm = new HashMap();
		int key = 1;
		for (String name : names) {
			lhm.put(key, name);
			key++;
		}
		return lhm;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(convertToMap(new String[] { "B", "C", "D", "A" }));
		System.out.println(convertToMap(null));
		System.out.println(convertToMap(new String[] {}));

	}

}
