import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


// -- DO NOT CHANGE CODE FOR EMPLOYEE CLASS 

public class COJ_29_Employee  {

	int id;
	String name;
	double salary;
	
	public COJ_29_Employee() {
		// TODO Auto-generated constructor stub
	}

	public COJ_29_Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ "]";
	}

}


// Class EmployeeDetails

class COJ_29_EmployeeDetails {

	//declare instance variable of type Map 
	//Variable name is employeeMap   
	
	Map<Integer, COJ_29_Employee> employeeMap;

	//add a getter and setter for the map
	
	
	/**
	* Default constructor,DO NOT DELETE.
	*/
	public COJ_29_EmployeeDetails() {
		employeeMap = new HashMap<Integer, COJ_29_Employee>();
	}

	public Map<Integer, COJ_29_Employee> getEmployeeMap() {
		return employeeMap;
	}

	public void setEmployeeMap(Map<Integer, COJ_29_Employee> employeeMap) {
		this.employeeMap = employeeMap;
	}

	/**
	* Add a given employee to the map.
	* 
	* @param emp
	* @return - return 1 on error, 2 when the employee already exists and 0 on
	*         success.
	*/

	
	public int addEmployee(COJ_29_Employee emp) {
		try {
			if (emp == null)
				return 1;
			int s1 = employeeMap.size();
			employeeMap.put(emp.getId(), emp);
			int s2 = employeeMap.size();
			return s1 == s2 ? 2 : 0;
		} catch (Exception e) {
			return 1;
		}

	}

	/**
	* Remove a Employee if it exists
	* 
	* @param EmployeeId
	* @return - 0 on success, 1 on error, and 2 if the Employee doesn't exist
	*/
	public int removeEmployee(int EmployeeId) {

		try {
			if (EmployeeId <= 0)
				return 1;
			int s1 = employeeMap.size();
			employeeMap.remove(EmployeeId);
			int s2 = employeeMap.size();
			return s1 == s2 ? 2 : 0;
		} catch (Exception e) {
			return 1;
		}

	}

	/**
	* Find a Employee in the map given the EmployeeId return null otherwise
	* 
	* @param EmployeeID
	* @return - null on error and Employee on success
	*/
	public COJ_29_Employee findEmployee(int EmployeeID) {
		
		return employeeMap.get(EmployeeID);  
		
	}

	/**
	* Return all employees in the map return null if map is empty
	* 
	* @return - null on empty map Or if map contains entries then return those
	*         employees as a list
	*/
	public List<COJ_29_Employee> getEmployeeList() {
		if(employeeMap == null)
			return null;
		return new ArrayList(employeeMap.values());
	}

}