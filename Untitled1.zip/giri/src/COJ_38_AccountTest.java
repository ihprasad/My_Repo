import static org.junit.Assert.*;

import java.lang.reflect.Method;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_38_AccountTest {

	@Test
	public void testField() {
		try {

			assertEquals("balance", new COJ_38_Account().getClass()
					.getDeclaredFields()[0].getName());

			System.out
					.println("#####AccountTest | Passed | 10 / 10 | Passed for correct field creation#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed for correct field creation#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed could not find required field#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testWithdrawMethodThere() {
		try {

			boolean isMethodThere = false;
			Method[] methods = new COJ_38_Account().getClass().getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString().contains("void COJ_38_Account.withdraw(int)")) {
					isMethodThere = true;
					break;
				}
			}

			assertTrue(isMethodThere);

			System.out
					.println("#####AccountTest | Passed | 10 / 10 | Passed for withdraw(int)#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed for withdraw(int)#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed could not find withdraw(int)#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testWithdrawMethodThreadSafe() {
		try {

			boolean isMethodThere = false;
			Method[] methods = new COJ_38_Account().getClass().getDeclaredMethods();
			for (Method m : methods) {

				if (m.toString().contains("void COJ_38_Account.withdraw(int)")
						&& m.toString().contains("synchronized")) {
					isMethodThere = true;
					break;
				}
			}

			assertTrue(isMethodThere);

			System.out
					.println("#####AccountTest | Passed | 15 / 15 | Passed for withdraw(int) is not thread-safe#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 15 | Failed for withdraw(int) is not thread-safe#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 15 | Failed could not find withdraw(int) is not thread-safe#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 15 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	// //
	@Test
	public void testDepositMethodThere() {
		try {

			boolean isMethodThere = false;
			Method[] methods = new COJ_38_Account().getClass().getDeclaredMethods();
			for (Method m : methods) {

				if (m.toString().contains("void COJ_38_Account.deposit(int)")) {
					isMethodThere = true;
					break;
				}
			}

			assertTrue(isMethodThere);

			System.out
					.println("#####AccountTest | Passed | 10 / 10 | Passed for deposit(int)#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed for deposit(int)#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed could not find deposit(int)#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDepositMethodThreadSafe() {
		try {

			boolean isMethodThere = false;
			Method[] methods = new COJ_38_Account().getClass().getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString().contains("void COJ_38_Account.deposit(int)")
						&& m.toString().contains("synchronized")) {
					isMethodThere = true;
					break;
				}
			}

			assertTrue(isMethodThere);

			System.out
					.println("#####AccountTest | Passed | 15 / 15 | Passed for deposit(int) is not thread-safe#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 15 | Failed for deposit(int) is not thread-safe#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 15 | Failed could not find deposit(int) is not thread-safe#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 15 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDepositMethodWorking() {
		try {

			COJ_38_Account a = new COJ_38_Account();
			a.deposit(5000);
			assertEquals(10000, a.balance);

			System.out
					.println("#####AccountTest | Passed | 20 / 20 | Passed for deposit(int) working#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 20 | Failed for deposit(int) working#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 20 | Failed could not find deposit(int) working#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 20 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testWithdrawMethodWorking() {
		try {

			COJ_38_Account a = new COJ_38_Account();
			a.withdraw(2000);
			assertEquals(3000, a.balance);

			System.out
					.println("#####AccountTest | Passed | 20 / 20 | Passed for withdraw(int) working#####");

		} catch (AssertionError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 20 | Failed for withdraw(int) working#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 20 | Failed could not find withdraw(int) working#####");
		} catch (Exception e) {
			System.out
					.println("#####AccountTest | Failed | 0 / 20 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

}
