import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;

import org.junit.Test;

public class COJ_32_OrderedMapTest {

	@Test
	public void testField() {
		try {
			Field[] fld = COJ_32_OrderedMap.class.getDeclaredFields();
			boolean var = false;
			for (int i = 0; i < fld.length; i++) {
				// System.out.println(fld[i].getGenericType().getTypeName());
				if ("insertionOrderMap".equals(fld[i].getName())) {
					if (fld[i]
							.getGenericType()
							.getTypeName()
							.equals("java.util.Map<java.lang.Integer, java.lang.String>"))
						var = true;
				}
			}
			assertTrue(var);

			System.out
					.println("#####OrderedMapTest | Passed | 10/10 | Passed for correct field creation#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed for correct field creation#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed could not find required field#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDefaultConstructor() {
		try {

			assertNotNull(new COJ_32_OrderedMap().insertionOrderMap);

			System.out
					.println("#####OrderedMapTest | Passed | 10/10 | Passed for user-defined default constructor#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed for user-defined default constructor#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed could not user-defined default constructor#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSetters() {
		try {

			boolean isSetterAvailable = false;
			Method[] methods = new COJ_32_OrderedMap().getClass().getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString().contains(
						"void COJ_32_OrderedMap.setInsertionOrderMap(java.util.Map)"))
					isSetterAvailable = true;
			}

			assertTrue(isSetterAvailable);

			// void OrderedMap.setInsertionOrderMap(java.util.Map)

			System.out
					.println("#####OrderedMapTest | Passed | 10/10 | Passed for setter method#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed for setter method#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed could not setter method#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/30 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetters() {
		try {

			boolean isGetterAvailable = false;
			Method[] methods = new COJ_32_OrderedMap().getClass().getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString().contains(
						"java.util.Map COJ_32_OrderedMap.getInsertionOrderMap()"))
					isGetterAvailable = true;
			}

			assertTrue(isGetterAvailable);

			// void OrderedMap.setInsertionOrderMap(java.util.Map)

			System.out
					.println("#####OrderedMapTest | Passed | 10/10 | Passed for getter method#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed for getter method#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed could not getter method#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetterAndSetter() {
		try {

			COJ_32_OrderedMap om = new COJ_32_OrderedMap();
			om.setInsertionOrderMap(new LinkedHashMap());
			assertTrue(om.getInsertionOrderMap() instanceof LinkedHashMap);

			System.out
					.println("#####OrderedMapTest | Passed | 10/10 | Passed for getter and setter working#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed for getter and setter working#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed could not getter and setter working#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testAddMethod() {
		try {

			boolean isAddElementMethodThere = false;
			Method[] methods = new COJ_32_OrderedMap().getClass().getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString().contains(
						"void COJ_32_OrderedMap.addElement(int,java.lang.String)"))
					isAddElementMethodThere = true;
			}

			assertTrue(isAddElementMethodThere);

			// void OrderedMap.setInsertionOrderMap(java.util.Map)

			System.out
					.println("#####OrderedMapTest | Passed | 10/10 | Passed for addElement() available#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed for addElement() available#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed could not addElement()#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testAddMethodLogic() {
		try {

			COJ_32_OrderedMap om = new COJ_32_OrderedMap();
			om.setInsertionOrderMap(new LinkedHashMap());
			om.addElement(1, "talent");
			om.addElement(2, "sprint");
			assertEquals("talent", om.insertionOrderMap.get(1));
			assertEquals("sprint", om.insertionOrderMap.get(2));

			// void OrderedMap.setInsertionOrderMap(java.util.Map)

			System.out
					.println("#####OrderedMapTest | Passed | 40/40 | Passed for addElement() logic#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/40 | Failed for addElement() logic#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/40 | Failed could not addElement() logic#####");
		} catch (Exception e) {
			System.out
					.println("#####OrderedMapTest | Failed | 0/40 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

}
