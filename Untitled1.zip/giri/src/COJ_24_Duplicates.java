import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;

public class COJ_24_Duplicates {
	// TODO define a List attribute called numberList
	private List<Integer> numberList;

	// define getters and setters

	public List<Integer> getNumberList() {
		return numberList;
	}

	public void setNumberList(List<Integer> numberList) {
		this.numberList = numberList;
	}

	/**
	 * Default constructor - DO NOT DELETE
	 */
	public COJ_24_Duplicates() {

	}

	/**
	 * Parameter constructor
	 * 
	 * @param numberList
	 */
	public COJ_24_Duplicates(List<Integer> numberList) {
		this.numberList = numberList;
	}

	/**
	 * Returns a new array list that contains only those elements from the
	 * original list that are repeated. The elements in the return list must be
	 * present only once. For example, if number 65 occurs twice, or thrice or
	 * four times in numberList, it should occur only once in the returning
	 * list. Return null if no numbers repeat or numberList is empty/null
	 * 
	 * @return
	 */
	public List<Integer> getDuplicatesList() {
		if (this.numberList == null)
			return null;
		if (this.numberList.isEmpty())
			return null;
		TreeSet ts = new TreeSet();
		ArrayList al = new ArrayList();
		for (int i = 0; i < numberList.size(); i++) {
			if (!ts.add(numberList.get(i))) {
				al.add(numberList.get(i));
			}
		}
		return new ArrayList(new HashSet(al));
	}

	public static void main(String[] args) {

		COJ_24_Duplicates d = new COJ_24_Duplicates();
		d.setNumberList(null);
		System.out.println(d.getDuplicatesList());

	}

}