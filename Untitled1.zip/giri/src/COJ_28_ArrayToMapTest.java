import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.TreeMap;
import java.util.TreeSet;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_28_ArrayToMapTest {

	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_28_ArrayToMap cls = new COJ_28_ArrayToMap();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - " + mm);
					if (mm.toString()
							.equals("public static java.util.Map COJ_28_ArrayToMap.convertToMap(java.lang.String[])"))
						me = true;
				}

				assertTrue(
						"No such method found: public static java.util.Map COJ_28_ArrayToMap.convertToMap(java.lang.String[])",
						me);
			} catch (AssertionError ae) {
				System.out
						.println("#####ArrayToMapTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####ArrayToMapTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testConvertToMapWithNull() {
		try {

			assertEquals(null, COJ_28_ArrayToMap.convertToMap(null));
			assertEquals(null, COJ_28_ArrayToMap.convertToMap(new String[] {}));

			System.out
					.println("#####ArrayToMapTest | Passed | 25/25 | Passed for null parameter#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed for null parameter#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed could not find method convertToMap(String[] names)#####");
		} catch (Exception e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testConvertToMapValues() {
		try {

			String[] s = { "A", "B", "C" };
			assertEquals(new TreeSet(Arrays.asList(s)), new TreeSet(
					COJ_28_ArrayToMap.convertToMap(s).values()));

			System.out
					.println("#####ArrayToMapTest | Passed | 25/25 | Passed for adding values#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed for adding values#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed could not find method convertToMap(String[] names)#####");
		} catch (Exception e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@Test
	public void testConvertToMapKeys() {
		try {

			String[] s = { "A", "B", "C", "D", "E", "F", "G" };
			TreeSet keys = new TreeSet();
			int k = 1;
			for (String st : s) {
				keys.add(k);
				k++;
			}
			assertEquals(keys, new TreeSet(COJ_28_ArrayToMap.convertToMap(s)
					.keySet()));

			System.out
					.println("#####ArrayToMapTest | Passed | 25/25 | Passed for adding keys#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed for adding keys#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed could not find method convertToMap(String[] names)#####");
		} catch (Exception e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@Test
	public void testConvertToMapKeysAndValues() {
		try {

			String[] s = { "A", "B", "C", "D", "E", "F", "G" };

			assertEquals("{1=A, 2=B, 3=C, 4=D, 5=E, 6=F, 7=G}", new TreeMap(
					COJ_28_ArrayToMap.convertToMap(s)).toString());

			System.out
					.println("#####ArrayToMapTest | Passed | 25/25 | Passed for adding keys and values#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed for adding keys and values#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed could not find method convertToMap(String[] names)#####");
		} catch (Exception e) {
			System.out
					.println("#####ArrayToMapTest | Failed | 0/25 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

}
