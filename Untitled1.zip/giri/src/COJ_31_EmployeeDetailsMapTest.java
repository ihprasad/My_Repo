import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;

import org.junit.Test;

public class COJ_31_EmployeeDetailsMapTest {

	@Test
	public void testField() {
		try {
			Field[] fld = COJ_31_EmployeeDetailsMap.class.getDeclaredFields();
			boolean var = false;
			for (int i = 0; i < fld.length; i++) {
				// System.out.println(fld[i].getGenericType().getTypeName());
				if ("employeeIdNameMap".equals(fld[i].getName())) {
					if (fld[i]
							.getGenericType()
							.getTypeName()
							.equals("java.util.Map<java.lang.Integer, java.lang.String>"))
						var = true;
				}
			}
			assertTrue(var);

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for correct field creation#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for correct field creation#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not find required field#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDefaultConstructor() {
		try {

			assertNotNull(new COJ_31_EmployeeDetailsMap().getEmployeeIdNameMap());

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for user-defined default constructor#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for user-defined default constructor#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not user-defined default constructor#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testFieldPrivate() {
		try {

			assertTrue(new COJ_31_EmployeeDetailsMap().getClass().getDeclaredFields()[0]
					.getModifiers() == Modifier.PRIVATE);
			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for private instance variable#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for private instance variable#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not private instance variable#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testParameterizedCons() {
		try {

			boolean isThereParameterizedCons = false;
			Constructor[] cons = new COJ_31_EmployeeDetailsMap().getClass()
					.getDeclaredConstructors();
			for (Constructor c : cons) {
				if (c.toString().contains("EmployeeDetailsMap(java.util.Map)")) {
					isThereParameterizedCons = true;
					break;
				}
			}

			assertTrue(isThereParameterizedCons);

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for parameterized constructor#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for parameterized constructor#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not getter method#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSetters() {
		try {

			boolean isSetterAvailable = false;
			Method[] methods = new COJ_31_EmployeeDetailsMap().getClass()
					.getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString()
						.contains(
								"void COJ_31_EmployeeDetailsMap.setEmployeeIdNameMap(java.util.Map)")) {
					isSetterAvailable = true;
					break;
				}
			}

			assertTrue(isSetterAvailable);

			// void OrderedMap.setInsertionOrderMap(java.util.Map)

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for setter method#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for setter method#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not setter method#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 30 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetters() {
		try {

			boolean isGetterAvailable = false;
			Method[] methods = new COJ_31_EmployeeDetailsMap().getClass()
					.getDeclaredMethods();
			for (Method m : methods) {

				if (m.toString()
						.contains(
								"java.util.Map COJ_31_EmployeeDetailsMap.getEmployeeIdNameMap()")) {
					isGetterAvailable = true;
					break;
				}
			}

			assertTrue(isGetterAvailable);

			// void OrderedMap.setInsertionOrderMap(java.util.Map)

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for getter method#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for getter method#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not getter method#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetterAndSetter() {
		try {

			COJ_31_EmployeeDetailsMap mp = new COJ_31_EmployeeDetailsMap();
			mp.setEmployeeIdNameMap(new HashMap());
			assertTrue(mp.getEmployeeIdNameMap() instanceof HashMap);

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 10 / 10 | Passed for getter and setter working#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed for getter and setter working#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed could not getter and setter working#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 10 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void textGetEmployeeName() {
		try {

			HashMap hm = new HashMap();
			hm.put(1, "James");
			hm.put(2, "Jones");
			hm.put(3, "John");

			COJ_31_EmployeeDetailsMap mp = new COJ_31_EmployeeDetailsMap();
			mp.setEmployeeIdNameMap(hm);
			assertEquals("James", mp.getEmployeeName(1));
			assertEquals("Jones", mp.getEmployeeName(2));
			assertEquals("John", mp.getEmployeeName(3));
			assertEquals(null, mp.getEmployeeName(4));

			hm = null;
			mp.setEmployeeIdNameMap(hm);
			assertEquals(null, mp.getEmployeeName(1));

			System.out
					.println("#####EmployeeDetailsMapTest | Passed | 30 / 30 | Passed for logic of getEmployeeName()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 30 | Failed for logic of getEmployeeName()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 30 | Failed could not logic of getEmployeeName()#####");
		} catch (Exception e) {
			System.out
					.println("#####EmployeeDetailsMapTest | Failed | 0 / 30 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

}
