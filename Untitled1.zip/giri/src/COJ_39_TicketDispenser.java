public class COJ_39_TicketDispenser extends Thread{
	int allottedSeats = 10;
	final int maxSeats = 100;
	int allotSeatNumber(){
		int allotSeat=0;
		synchronized(this){
			
		for(int startNumber = 1;startNumber<=maxSeats;startNumber++){
			
			if(startNumber==allottedSeats){
				try{
					Thread.sleep(1500);
				allottedSeats++;
				allotSeat = allottedSeats;
			
				break;
				}
				catch(Exception e){
					e.printStackTrace();
				}
				return allotSeat;
			}
			else{
				
			}
			}
	
		}
		return allotSeat;
	}
}


// Testing class

class COJ_39_Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final COJ_39_TicketDispenser t = new COJ_39_TicketDispenser();
		
		Thread t1 = new Thread(){
			public void run(){
				
			int allotSeat =	t.allotSeatNumber();
			System.out.println("allotted seat number is : "+allotSeat);
			}
		};t1.start();
		
		Thread t2 = new Thread(){
			public void run(){
				int allotSeat = t.allotSeatNumber();
				System.out.println("allotted seat number is : "+allotSeat);
			}
		};t2.start();
		
		
		Thread t3 = new Thread(){
			public void run(){
				int allotSeat = t.allotSeatNumber();
				System.out.println("allotted seat number is : "+allotSeat);
			}
		};t3.start();
	
	}

}