import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.Test;

public class COJ_39_TicketDispenserTest {

	@Test
	public void testField() {
		try {

			Field[] fld = new COJ_39_TicketDispenser().getClass()
					.getDeclaredFields();
			boolean fe = false;
			int count = 0;
			for (Field f : fld)
				if ((f.getName().equals("allottedSeats") && f.getGenericType()
						.toString().equals("int"))
						|| (f.getName().equals("maxSeats")
								&& f.getGenericType().toString().equals("int") && (f
								.getModifiers() == java.lang.reflect.Modifier
								.FINAL)))
					count++;
//					System.out.println(f.getName()
//							+ "-----"
//							+ f.getGenericType()
//							+ " *** "
//							+ (f.getModifiers() == java.lang.reflect.Modifier
//									.FINAL));
			if(count > 0)
				fe = true;
			assertTrue(fe);
			assertEquals(100, new COJ_39_TicketDispenser().maxSeats);
			

			assertEquals("allottedSeats", new COJ_39_TicketDispenser()
					.getClass().getDeclaredFields()[0].getName());

			System.out
					.println("#####TicketDispenserTest | Passed | 20 / 20 | Passed for correct field creation#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 20 | Failed for correct field creation#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 20 | Failed could not find required field#####");
		} catch (Exception e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 20 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testAllotSeatsMethodThere() {
		try {

			boolean isMethodThere = false;
			Method[] methods = new COJ_39_TicketDispenser().getClass()
					.getDeclaredMethods();
			for (Method m : methods) {
				if (m.toString().contains(
						"int COJ_39_TicketDispenser.allotSeatNumber()")) {
					isMethodThere = true;
					break;
				}
			}

			assertTrue(isMethodThere);

			System.out
					.println("#####TicketDispenserTest | Passed | 30 / 30 | Passed for allotSeatNumber()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 30 | Failed for allotSeatNumber()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 30 | Failed could not find allotSeatNumber()#####");
		} catch (Exception e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 30 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testAllotSeatsMethodWorking() {

		try {
			final COJ_39_TicketDispenser t = new COJ_39_TicketDispenser();

			Thread t1 = new Thread() {
				public void run() {

					assertTrue(t.allotSeatNumber() <= 100);
					assertTrue(t.allottedSeats == 100
							&& t.allotSeatNumber() == -1);

				}
			};
			t1.start();

			System.out
					.println("#####TicketDispenserTest | Passed | 50 / 50 | Passed for allotSeatNumber() working#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 50 | Failed for allotSeatNumber() working#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 50 | Failed could not find allotSeatNumber() working#####");
		} catch (Exception e) {
			System.out
					.println("#####TicketDispenserTest | Failed | 0 / 50 | Failed RuntimeError"
							+ e.getMessage() + "#####");
		}

	}

}
