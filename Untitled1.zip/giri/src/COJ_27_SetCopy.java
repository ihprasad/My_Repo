import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class COJ_27_SetCopy {

    /**
     * Copy all elements of source to Destination. return zero on successful
     * copy return 1 on error
     *
     * @param source
     * @param destination
     * @return integer
     */
	
    public static int copySets(Set<Integer> source, Set<Integer> destination) {
        if (source == null || destination == null)
            return 1;
          
        destination.addAll(source);
        return source.size() == destination.size() ? 0 : 1;
    }

    public static void main(String[] args){
    	HashSet<Integer> hs1 = new HashSet<Integer>(Arrays.asList(1,2,3,4,5,6));
		HashSet<Integer> hs2 = new HashSet<Integer>();
		
		System.out.println(hs1);
		System.out.println(hs2);
		
		new COJ_27_SetCopy().copySets(hs1, hs2);
		
		System.out.println(hs1);
		System.out.println(hs2);
    	
    }
    
}
