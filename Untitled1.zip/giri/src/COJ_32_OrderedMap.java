import java.util.LinkedHashMap;
import java.util.Map;

public class COJ_32_OrderedMap  {
   
    //TODO declare a Map that has an integer for key and String for value
   
    Map<Integer, String> insertionOrderMap;
   
    //add getter and setter
   
  
    /**
     * default constructor - DO NOT DELETE
     */
    public COJ_32_OrderedMap(){
       insertionOrderMap = new LinkedHashMap<Integer,String>();
    }
   
   
    public Map<Integer, String> getInsertionOrderMap() {
        return insertionOrderMap;
    }


    public void setInsertionOrderMap(Map<Integer, String> insertionOrderMap) {
        this.insertionOrderMap = insertionOrderMap;
    }


    /**
     * Method to add the given key and value in the map
     * @param id
     * @param name
     * @return
     */
    public void addElement(int key, String value){
        insertionOrderMap.put(key, value);
    }
}
