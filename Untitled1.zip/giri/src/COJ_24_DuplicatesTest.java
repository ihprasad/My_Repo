import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_24_DuplicatesTest {

	@BeforeClass
	public static void setBeforeClass() {

		Field[] fld = COJ_24_Duplicates.class.getDeclaredFields();
		boolean var = false;
		int count = 0;
		for (int i = 0; i < fld.length; i++) {
			// System.out.println(fld[i].getGenericType().getTypeName());
			if ("numberList".equals(fld[i].getName())) {
				if (fld[i].getGenericType().getTypeName()
						.equals("java.util.List<java.lang.Integer>"))
					if (fld[i].getModifiers() == java.lang.reflect.Modifier.PRIVATE)
						// count++;
						var = true;
			}
		}
		try {
			assertTrue("Variable 'numberList' not defined properly", var);

			COJ_24_Duplicates cls = new COJ_24_Duplicates();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method m1 = c.getMethod("getDuplicatesList");
				// System.out.println(m1.getGenericReturnType().getTypeName());
				assertTrue(
						"No such method found: public List<Integer> getDuplicatesList()",
						m1.getGenericReturnType().getTypeName()
								.equals("java.util.List<java.lang.Integer>"));
			} catch (AssertionError ae) {
				System.out
						.println("#####DuplicatesTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DuplicatesTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testGetCount() {
		try {
			COJ_24_Duplicates d = new COJ_24_Duplicates();
			COJ_24_Duplicates d1 = new COJ_24_Duplicates(Arrays.asList(1, 2, 3,
					4, 5, 6, 7, 8, 9));
			d.setNumberList(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
			assertEquals(0, d.getDuplicatesList().size());
			System.out
					.println("#####DuplicatesTest | Passed | 30/30 | Passed for no repeated value#####");

		} catch (AssertionError e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed for no repeated value#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed could not find method getDuplicatesList()#####");
		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@Test
	public void testGetCountNull() {
		try {
			COJ_24_Duplicates d = new COJ_24_Duplicates();
			d.setNumberList(null);
			assertEquals(null, d.getDuplicatesList());
			System.out
					.println("#####DuplicatesTest | Passed | 30/30 | Passed for null input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed for null input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed could not find method getDuplicatesList()#####");
		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@Test
	public void testGetCountWithRepeated() {
		try {

			COJ_24_Duplicates d = new COJ_24_Duplicates();
			d.setNumberList(Arrays.asList(1, 2, 3, 4, 5, 6, 6, 7, 7, 7, 8, 9));
			assertEquals(Arrays.asList(6, 7), d.getDuplicatesList());

			d.setNumberList(Arrays.asList(1, 4, 4, 4, 4, 4, 4, 6, 6, 7, 7, 7,
					8, 9));
			assertEquals(Arrays.asList(4, 6, 7), d.getDuplicatesList());

			System.out
					.println("#####DuplicatesTest | Passed | 30/30 | Passed for repeated values#####");

		} catch (AssertionError e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed for repeated values#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed could not find method getDuplicatesList()#####");
		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/30 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@Test
	public void TestSetNumberList() {
		try {

			COJ_24_Duplicates pojo = new COJ_24_Duplicates();

			List<Integer> numberList1 = new ArrayList<Integer>();
			numberList1.add(1);
			numberList1.add(2);

			pojo.setNumberList(numberList1);

			// then
			final Field field = pojo.getClass().getDeclaredField("numberList");
			field.setAccessible(true);
			assertEquals(field.get(pojo), numberList1);
			System.out
					.println("#####DuplicatesTest | Passed | 5/5 | Checking for setter method: setNumberList().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/5 | Checking for setter method: setNumberList().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DuplicatesTest | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void TestGetNumberList() {
		try {

			COJ_24_Duplicates pojo = new COJ_24_Duplicates();

			List<Integer> numberList1 = new ArrayList<Integer>();
			numberList1.add(1);
			numberList1.add(2);

			// pojo.setNumberList(numberList1);

			// then
			final Field field = pojo.getClass().getDeclaredField("numberList");
			field.setAccessible(true);
			field.set(pojo, numberList1);

			// when
			final List<Integer> result = pojo.getNumberList();

			// then
			assertEquals(result, numberList1);
			System.out
					.println("#####DuplicatesTest | Passed | 5/5 | Checking for getter method: getNumberList().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/5 | Checking for getter method: getNumberList().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DuplicatesTest | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
