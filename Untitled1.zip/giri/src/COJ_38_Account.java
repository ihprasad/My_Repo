public class COJ_38_Account {
	int balance = 5000;

	synchronized void deposit(int amount) {
		balance = balance + amount;
	}

	synchronized void withdraw(int amount) {
		balance = balance - amount;
	}
}


// class AccountTester to test multi-thread

class COJ_38_AccountTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final COJ_38_Account a = new COJ_38_Account();
		
		Thread t1 = new Thread(){
			public void run(){
				a.deposit(1000);
			}
		};
		t1.start();

		Thread t2 = new Thread(){
			public void run(){
				a.deposit(1000);
			}
		};
		t2.start();

		Thread t3 = new Thread(){
			public void run(){
				a.withdraw(1500);
			}
		};
		t3.start();
		
	}

}

