import static org.junit.Assert.*;

import java.util.List;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_29_EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		
	}

	@Test
	public void testField(){
		try{
			
			assertEquals("employeeMap", new COJ_29_EmployeeDetails().getClass().getDeclaredFields()[0].getName());
			
			System.out.println("#####EmployeeDetailsTest | Passed | 5 / 5 | Passed for correct field creation#####");

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed for correct field creation#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed could not find required field#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed RuntimeError" + e.getMessage()+"#####");
		} 
				
	}
	
	
	@Test
	public void testDefaultConstructor(){
		try{
			
			assertNotNull(new COJ_29_EmployeeDetails().getEmployeeMap());
			
			System.out.println("#####EmployeeDetailsTest | Passed | 5 / 5 | Passed for user-defined default constructor#####");

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed for user-defined default constructor#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed could not user-defined default constructor#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed RuntimeError" + e.getMessage()+"#####");
		} 
				
	}
	
	@Test
	public void testSetters(){
		try{
			
			
			boolean isSetterAvailable = false;
			Method[] methods = new COJ_29_EmployeeDetails().getClass().getDeclaredMethods();
			for(Method m : methods){
				if (m.toString().contains("void COJ_29_EmployeeDetails.setEmployeeMap(java.util.Map)")){
					isSetterAvailable = true;
					break;
				}
			}
			
			assertTrue(isSetterAvailable);
		
			
			System.out.println("#####EmployeeDetailsTest | Passed | 5 / 5 | Passed for setter method#####");

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed for setter method#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed could not find setter method#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed RuntimeError" + e.getMessage()+"#####");
		}
	}
	
	@Test
	public void testGetters(){
		try{
			
			boolean isGetterAvailable = false;
			Method[] methods = new COJ_29_EmployeeDetails().getClass().getDeclaredMethods();
			for(Method m : methods){
				
				if (m.toString().contains("java.util.Map COJ_29_EmployeeDetails.getEmployeeMap()")){
					isGetterAvailable = true;
					break;
				}
			}
			
			assertTrue(isGetterAvailable);
			
			System.out.println("#####EmployeeDetailsTest | Passed | 5 / 5 | Passed for getter method#####");

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed for getter method#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed could not find getter method#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 5 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}
	

	@Test
	public void testGetterAndSetter(){
		try{
			
			
			COJ_29_EmployeeDetails mp = new COJ_29_EmployeeDetails();
			mp.setEmployeeMap(new HashMap());
			assertTrue(mp.getEmployeeMap() instanceof Map);
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for getter and setter working#####");

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 10 | Failed for getter and setter working#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 10 | Failed could not find getter and setter working#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 10 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}

	
	
	@Test
	public void testAddEmployeeMethodThere(){
		try{
			
			boolean isMethodThere = false;
			Method[] methods = new COJ_29_EmployeeDetails().getClass().getDeclaredMethods();
			for(Method m : methods){
				if (m.toString().contains("int COJ_29_EmployeeDetails.addEmployee(COJ_29_Employee)")){
					isMethodThere = true;
					break;
				}
			}
			
			assertTrue(isMethodThere);
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for addEmployee()#####");
			
	
		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for addEmployee()#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find addEmployee()#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}

	@Test
	public void testRemoveEmployeeMethodThere(){
		try{
			
			boolean isMethodThere = false;
			Method[] methods = new COJ_29_EmployeeDetails().getClass().getDeclaredMethods();
			for(Method m : methods){
				if (m.toString().contains("int COJ_29_EmployeeDetails.removeEmployee(int)")){
					isMethodThere = true;
					break;
				}
			}
			
			assertTrue(isMethodThere);
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for removeEmployee(int)#####");
	
		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for removeEmployee(int)#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find removeEmployee(int)#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}
	
	@Test
	public void testFindEmployeeMethodThere(){
		try{
			
			boolean isMethodThere = false;
			Method[] methods = new COJ_29_EmployeeDetails().getClass().getDeclaredMethods();
			for(Method m : methods){
				if (m.toString().contains("Employee COJ_29_EmployeeDetails.findEmployee(int)")){
					isMethodThere = true;
					break;
				}
			}
			
			assertTrue(isMethodThere);
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for findEmployee(int)#####");
	

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for findEmployee(int)#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find findEmployee(int)#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}
	
	
	@Test
	public void testAddEmployeeMethodWorking(){
		try{
			
			COJ_29_EmployeeDetails cm = new COJ_29_EmployeeDetails();
			cm.addEmployee(new COJ_29_Employee(111, "john", 2000));
			COJ_29_Employee e1 = cm.employeeMap.get(111);
			assertTrue(e1.getId() == 111 && e1.getName().equals("john") && e1.getSalary() == 2000);
				
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for addEmployee() working#####");
			
	
		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for addEmployee() working#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find addEmployee() working#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}
	
	
	@Test
	public void testRemoveEmployeeMethodWorking(){
		try{
			
			COJ_29_EmployeeDetails cm = new COJ_29_EmployeeDetails();
			COJ_29_Employee e1 = new COJ_29_Employee(111, "James", 5000);
			cm.employeeMap.put(e1.getId(), e1);
			cm.removeEmployee(111);
			assertNull(cm.employeeMap.get(111));
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for removeEmployee(int) working#####");
	
		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for removeEmployee(int) working#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find removeEmployee(int) working#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}
	
	@Test
	public void testFindEmployeeMethodWorking(){
		try{
			
			COJ_29_EmployeeDetails cm = new COJ_29_EmployeeDetails();
			COJ_29_Employee e1 = new COJ_29_Employee(111, "James", 5000);
			cm.employeeMap.put(e1.getId(), e1);
			assertNotNull(cm.findEmployee(111));
			
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for findEmployee(int) working#####");
	

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for findEmployee(int) working#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find findEmployee(int) working#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}
	
	@Test
	public void testGetEmployeeListMethodWorking(){
		try{
			
			COJ_29_EmployeeDetails cm = new COJ_29_EmployeeDetails();
			COJ_29_Employee e1 = new COJ_29_Employee(111, "James", 5000);
			COJ_29_Employee e2 = new COJ_29_Employee(222, "James", 5000);
			COJ_29_Employee e3 = new COJ_29_Employee(333, "James", 5000);
			COJ_29_Employee e4 = new COJ_29_Employee(444, "James", 5000);
			COJ_29_Employee e5 = new COJ_29_Employee(555, "James", 5000);
			COJ_29_Employee e6 = new COJ_29_Employee(666, "James", 5000);
			COJ_29_Employee e7 = new COJ_29_Employee(777, "James", 5000);
			
			cm.employeeMap.put(e1.getId(), e1);
			cm.employeeMap.put(e2.getId(), e2);
			cm.employeeMap.put(e3.getId(), e3);
			cm.employeeMap.put(e4.getId(), e4);
			cm.employeeMap.put(e5.getId(), e5);
			cm.employeeMap.put(e6.getId(), e6);
			cm.employeeMap.put(e7.getId(), e7);
			
			assertTrue(cm.getEmployeeList().size() == 7);
			
			
			System.out.println("#####EmployeeDetailsTest | Passed | 10 / 10 | Passed for getEmployeeList() working#####");
	

		} catch (AssertionError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed for getEmployeeList() working#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed could not find getEmployeeList() working#####");
		} catch (Exception e) {
			System.out.println("#####EmployeeDetailsTest | Failed | 0 / 30 | Failed RuntimeError" + e.getMessage()+"#####");
		}	
				
	}

}


