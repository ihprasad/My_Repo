import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.TreeSet;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_27_SetCopyTest {

	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_27_SetCopy cls = new COJ_27_SetCopy();
			Class c = cls.getClass();
			Method lMethod;

			try {
				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - " + mm.toGenericString());
					if (mm.toGenericString()
							.equals("public static int COJ_27_SetCopy.copySets(java.util.Set<java.lang.Integer>,java.util.Set<java.lang.Integer>)"))
						me = true;
				}

				// **************************************
				//
				// Method m1 = c.getMethod("copySets");
				// System.out.println(m1.getGenericReturnType().getTypeName());
				assertTrue(
						"No such method found: public static int COJ_27_SetCopy.copySets(java.util.Set<java.lang.Integer>,java.util.Set<java.lang.Integer>)",
						me);
				System.out
						.println("#####SetCopyTest | Passed | 20/20 | Passed for method definition#####");

			} catch (AssertionError ae) {
				System.out
						.println("#####DuplicatesTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DuplicatesTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####DuplicatesTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testGetCountWithNull() {
		try {
			COJ_27_SetCopy sc = new COJ_27_SetCopy();

			assertEquals(1, sc.copySets(null, new HashSet()));
			assertEquals(1, sc.copySets(
					new HashSet(Arrays.asList(1, 2, 3, 4, 5, 6, 8, 9, 0, 1, 2,
							3, 4, 5)), null));
			assertEquals(1, sc.copySets(null, null));

			System.out
					.println("#####SetCopyTest | Passed | 40/40 | Passed for null parameters#####");

		} catch (AssertionError e) {
			System.out
					.println("#####SetCopyTest | Failed | 0/40 | Failed for null parameters#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SetCopyTest | Failed | 0/40 | Failed could not find method copySets(Set, Set)#####");
		} catch (Exception e) {
			System.out
					.println("#####SetCopyTest | Failed | 0/40 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}

	@Test
	public void testGetCount() {
		try {

			COJ_27_SetCopy sc = new COJ_27_SetCopy();

			HashSet<Integer> hs1 = new HashSet<Integer>(Arrays.asList(1, 2, 3,
					4, 5, 6));
			HashSet<Integer> hs2 = new HashSet<Integer>();
			new COJ_27_SetCopy().copySets(hs1, hs2);
			assertEquals(hs1.size(), hs2.size());
			assertEquals(true, hs1.equals(hs2));

			System.out
					.println("#####SetCopyTest | Passed | 40/40 | Passed for valid input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####SetCopyTest | Failed | 0/40 | Failed for valid input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SetCopyTest | Failed | 0/40 | Failed could not find method copySets(Set, Set)#####");
		} catch (Exception e) {
			System.out
					.println("#####SetCopyTest | Failed | 0/40 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}
}
