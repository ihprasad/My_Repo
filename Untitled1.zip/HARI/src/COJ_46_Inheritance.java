class COJ_46_Circle {
	double radius;

	COJ_46_Circle() {

	}

	COJ_46_Circle(double radius) {
		this.radius = radius;
	}

	public double getArea() {
		if (radius <= 0) {
			return -1;
		}
		return 3.14 * radius * radius;
	}

}

class COJ_46_Cylender extends COJ_46_Circle {

	private double height; // Private member variable

	public COJ_46_Cylender() { // constructor 1
		super(); // invoke superclass' constructor Circle()
		height = 1.0;
	}

	public COJ_46_Cylender(double radius, double height) {

		super(radius); // invoke superclass' constructor Circle(radius)
		this.height = height;
	}

	public double getVolume() {
		if(getArea() == -1 || height <= 0)
			return -1;
		return getArea() * height; // Use Circle's getArea()
	}

}

class COJ_46_Testing {
	public static void main(String[] args) {
		// TEST YOUR CODE HERE
	}

}