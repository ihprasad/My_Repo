import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_46_InheritanceTest {
	COJ_46_Circle obj;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			Class.forName("COJ_46_Circle");
			Class.forName("COJ_46_Cylender");
		} catch (ClassNotFoundException ce) {
			System.out
					.println("#####test|Failed|0/10|Class definition not found: "
							+ ce.getMessage() + "#####");
			System.exit(0);
		}

	}

	@Test
	public final void testFields() {

		// int marks = 0;

		try {
			// Class.forName("COJ_46_Circle");
			// obj = new COJ_46_Circle();

			Field[] fld = COJ_46_Circle.class.getDeclaredFields();
			Field[] fldc = COJ_46_Cylender.class.getDeclaredFields();
			HashMap<String, String> hmap = new HashMap<String, String>();

			for (Field f : fld) {
				String key = f.getName();
				String value = f.getGenericType().toString();
				hmap.put(key, value);
			}
			for (Field f : fldc) {
				String key = f.getName();
				String value = f.getGenericType().toString();
				hmap.put(key, value);
			}

			try {
				assertTrue("Field 'radius' not defined",
						hmap.containsKey("radius")
								&& hmap.get("radius").equals("double"));
				System.out
						.println("#####testCircleFields|Passed|5/5|passed for fields in COJ_46_Circle.#####");
				// marks++;
			} catch (AssertionError ae) {
				System.out
						.println("#####testCircleFields|Failed|0/5|Checking for fields in COJ_46_Circle: "
								+ ae.getMessage() + "#####");
			}

			fld = COJ_46_Cylender.class.getDeclaredFields();

			try {
				assertTrue("Field 'height' not defined",
						hmap.containsKey("height")
								&& hmap.get("height").equals("double"));
				System.out
						.println("#####testCylenderFields|Passed|5/5|passed for fields in COJ_46_Cylender.#####");
				// marks++;
			} catch (AssertionError ae) {
				System.out
						.println("#####testCylenderFields|Failed|0/5|Checking for fields in COJ_46_Cylender: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DayOfWeekTest|Failed|0/5|No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####DayOfWeekTest|Failed|0/5|Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	@Test
	public final void testMethods() {
		// Methods existance.

		try {
			COJ_46_Cylender cls = new COJ_46_Cylender();
			Class c = cls.getClass();

			Method[] m = c.getMethods();
			// int count = 0;
			boolean mev = false;
			boolean mea = false;
			for (Method mm : m) {
				// System.out.println("mm - " + mm);
				if (mm.toString().equals(
						"public double COJ_46_Cylender.getVolume()"))
					mev = true;

				if (mm.toString().equals(
						"public double COJ_46_Circle.getArea()"))
					mea = true;
			}
			try {
				assertTrue("getVolume() method not defined in class cylender",
						mev);
				System.out
						.println("#####testMethods|Passed|5/5|passed for method definition in cylender.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testMethods|Failed|0/5|Failed for method definition in cylender: "
								+ ae.getMessage() + "#####");
			}
			try {

				assertTrue("getArea() method not defined in class circle", mea);
				System.out
						.println("#####testMethods|Passed|5/5|passed for method definition in circle.#####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testMethods|Failed|0/5|Failed for method definition in circle: "
								+ ae.getMessage() + "#####");

			}
		} catch (Exception e) {
			System.out
					.println("#####DayOfWeekTest|Failed|0/5|Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	@Test
	public final void testGetArea() {
		try {
			try {

				assertEquals(78.5, new COJ_46_Circle(5).getArea(), 0);
				System.out
						.println("#####testGetArea|Passed|14/14|passed for calculating area of circle.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetArea|Failed|0/14|Checking for getArea method in COJ_46_Circle: "
								+ ae.getMessage() + "#####");
			}
			try {

				assertEquals(-1, new COJ_46_Circle(-5).getArea(), 0);
				System.out
						.println("#####testGetArea|Passed|14/14|passed for calculating area of circle with negative radius as input.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetArea|Failed|0/14|Failed for calculating area of circle with negative radius as input: "
								+ ae.getMessage() + "#####");
			}
		} catch (Exception e) {
			System.out
					.println("#####testGetArea|Failed|0/14|Runtime Exception: "
							+ e + "#####");
		}
	}

	@Test
	public final void testGetVolume() {
		try {
			try {

				assertEquals(235.5, new COJ_46_Cylender(5, 3).getVolume(), 0);
				System.out
						.println("#####testGetVolume|Passed|14/14|passed for calculating Volume of Cylender.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetVolume|Failed|0/14|Failed for calculating Volume of Cylender: "
								+ ae.getMessage() + "#####");
			}
			try {

				assertEquals(-1, new COJ_46_Cylender(-5, 3).getVolume(), 0);
				System.out
						.println("#####testGetVolume|Passed|14/14|passed for calculating volume of Cylender with negative radius as input.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetVolume|Failed|0/14|Failed for calculating volume of Cylender with negative radius as input: "
								+ ae.getMessage() + "#####");
			}
			try {

				assertEquals(-1, new COJ_46_Cylender(5, -3).getVolume(), 0);
				System.out
						.println("#####testGetVolume|Passed|14/14|passed for calculating volume of Cylender with negative height as input.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetVolume|Failed|0/14|Failed for calculating volume of Cylender with negative height as input: "
								+ ae.getMessage() + "#####");
			}
		} /*
		 * catch(NoSuchMethodError e){
		 * 
		 * }
		 */catch (Exception e) {
			System.out
					.println("#####testGetVolume|Failed|0/14|Runtime Exception: "
							+ e + "#####");
		}
	}

	@Test
	public final void testInheritance() {
		// fail("Not yet implemented"); // TODO
		try {
			assertTrue((new COJ_46_Cylender().getClass().getSuperclass()
					.getName()).equals("COJ_46_Circle"));

			// assertEquals(-1, new COJ_46_Cylender(5, -3).getVolume(), 0);
			System.out
					.println("#####testInheritance|Passed|10/10|passed for circle is super class of cylender.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testInheritance|Failed|0/10|Failed for circle is super class of cylender: "
							+ ae + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testInheritance|Failed|0/10|Runtime Exception: "
							+ e + "#####");
		}
	}

}
