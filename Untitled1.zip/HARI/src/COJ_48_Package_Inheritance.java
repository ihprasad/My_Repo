
public class COJ_48_Package_Inheritance {
	public static void main(String[] args) {
		
	}

}
