import java.util.HashMap;

public class Mapping {

	static HashMap<Integer, String> planets = new HashMap<Integer, String>();
	static HashMap<Integer, String> planets1 = new HashMap<Integer, String>();

	public static void main(String[] args) {
		planets.put(1, "Sun");
		planets.put(2, "Moon");
		planets.put(3, "Mars");
		planets.put(4, "Rahu");
		planets.put(5, "Mercury");
		planets.put(6, "Venus");
		planets.put(7, "Ketu");
		planets.put(8, "Saturn");
		planets.put(9, "Mars");

		planets1.put(1, "Sun");
		planets1.put(2, "Moon");
		planets1.put(3, "Mars");
		planets1.put(4, "Rahu");
		planets1.put(5, "Mercury");
		planets1.put(6, "Venus");
		planets1.put(7, "Ketu");
		planets1.put(9, "Mars");
		planets1.put(8, "Saturn");
		

		System.out.println(planets.equals(planets1));

	}

}
