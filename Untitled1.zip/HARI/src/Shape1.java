
public interface Shape1 {
	

}
