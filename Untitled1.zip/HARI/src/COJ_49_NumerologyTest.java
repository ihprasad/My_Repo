import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_49_NumerologyTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			Class.forName("Person");
			Class.forName("COJ_49_Numerology");
		} catch (ClassNotFoundException ce) {
			System.out
					.println("#####testClassDefinitions|Failed|0/100|Class not found: "
							+ ce.getMessage() + ".#####");
			System.exit(0);
		}
	}

	@Test
	public void testConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for employee

			cons = Class.forName("Person").getConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals("public Person(int,int,int)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue("public Person(int,int,int)", found);
				System.out
						.println("#####testConstructors | Passed | 5/5 | Checking for constructor.#####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testConstructors|Failed|0/5|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				// System.exit(0);
			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testConstructors|Failed|0/5|No such method found: "
							+ e.getMessage() + "#####");
			// System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testConstructors|Failed|0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
			// System.exit(0);
		}
	}

	@Test
	public void testFields() {
		try {
			// Class.forName("COJ_46_Circle");
			// obj = new COJ_46_Circle();

			Field[] fld = Class.forName("Person").getDeclaredFields();
			HashMap<String, String> hmap = new HashMap<String, String>();

			for (Field f : fld) {
				String key = f.getName();
				String value = f.getGenericType().toString();
				hmap.put(key, value);
			}

			String[] fArray = { "date", "month", "year", "destinyNumber" };
			String res = "";
			boolean flag = true;
			
			int mrks = 0;

			try {
				for (String s : fArray) {
					if (!hmap.containsKey(s) && !hmap.get(s).equals("int")) {
						flag = false;
						res += s + ",";
					}
				}
				if (res.length() > 0)
					res = res.substring(0, (res.length() - 1));
				
				assertTrue("Field(s) " + res + " not defined", flag);
				System.out
						.println("#####testFields|Passed|5/5|Fields in Person.#####");
				// marks++;
			} catch (AssertionError ae) {
				System.out
						.println("#####testFields|Failed|0/5|Checking for fields in Person: "
								+ ae.getMessage() + "#####");
			}
			hmap.clear();

			Field[] fldc = Class.forName("COJ_49_Numerology")
					.getDeclaredFields();
			for (Field f : fldc) {
				String key = f.getName();
				String value = f.getGenericType().toString();
				hmap.put(key, value);
			}

			try {

				if (!hmap.containsKey("planets")
						&& !hmap.get("planets")
								.equals("java.util.HashMap<java.lang.Integer, java.lang.String>")) {
					flag = false;
					res += "planets,";
				}

				if (!hmap.containsKey("planetsCharacteristics")
						&& !hmap.get("planetsCharacteristics")
								.equals("java.util.HashMap<java.lang.String, java.lang.String>")) {
					flag = false;
					res += "planetsCharacteristics,";
				}

				if (res.length() > 0)
					res = res.substring(0, (res.length() - 1));
				assertTrue("Field(s) " + res + " not defined", flag);
				System.out
						.println("#####testFields|Passed|5/5|passed for fields in COJ_49_Numerology.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testFields|Failed|0/5|Checking for fields in COJ_49_Numerology: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFields|Failed|0/10|No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out.println("#####testFields|Failed|0/10|Runtime Exception:"
					+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testMethods() {
		
		try {

			HashMap<Integer, String> planets = new HashMap<Integer, String>();
			planets.put(1, "Sun");
			planets.put(2, "Moon");
			planets.put(3, "Mars");
			planets.put(4, "Rahu");
			planets.put(5, "Mercury");
			planets.put(6, "Venus");
			planets.put(7, "Ketu");
			planets.put(8, "Saturn");
			planets.put(9, "Mars");

			HashMap<String, String> planetsCharacteristics = new HashMap<String, String>();
			planetsCharacteristics.put("Sun", "Confidence");
			planetsCharacteristics.put("Moon", "Emotions");
			planetsCharacteristics.put("Jupiter", "Knowledge");
			planetsCharacteristics.put("Rahu", "Extravagance");
			planetsCharacteristics.put("Mercury", "Intelligence");
			planetsCharacteristics.put("Venus", "Beauty");
			planetsCharacteristics.put("Ketu", "Philosophy");
			planetsCharacteristics.put("Saturn", "Discipline");
			planetsCharacteristics.put("Mars", "Vitality");

			COJ_49_Numerology num = new COJ_49_Numerology();
			num.loadHasMap();
			num.loadHashMapCharacteristics();
			
			Person p = new Person(12, 12, 1990);
			p.computeDestinyNumber();
			
			boolean flag = true;
			String str = "";

			try {
				assertTrue("loadHasMap method not defined properly", planets.equals(num.planets));
				System.out.println("#####testMethods|Passed|20/20|passed for loadHasMap method in COJ_49_Numerology.#####");	
			} catch (AssertionError ae) {
				System.out
						.println("#####testMethods|Failed|0/20|Failed for loadHasMap method in COJ_49_Numerology: "
								+ ae.getMessage() + "#####");
			}
			try{
				assertTrue("loadHashMapCharacteristics method not defined properly", planetsCharacteristics.equals(num.planetsCharacteristics));
				System.out.println("#####testMethods|Passed|20/20|passed for loadHashMapCharacteristics method in COJ_49_Numerology.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testMethods|Failed|0/20|Failed for loadHashMapCharacteristics method in COJ_49_Numerology: "
								+ ae.getMessage() + "#####");
			}
			
			try {
				
				
				assertTrue("getProperties() method not defined properly", "The character of person with 12-12-1990 birth date is Philosophy".equals(num.getProperties(p)));
				System.out.println("#####testMethods|Passed|20/20|passed for getProperties method in COJ_49_Numerology.#####");


			} catch (AssertionError ae) {
				System.out
						.println("#####testMethods|Failed|0/20|Failed for getProperties method in COJ_49_Numerology: "
								+ ae.getMessage() + "#####");
			}

			// Methods in Person
			
			try {
				
				assertTrue("computeDestinyNumber() method not defined properly", p.destinyNumber == 7);
				System.out.println("#####testMethods|Passed|25/25|passed for computeDestinyNumber method in Person.#####");


			} catch (AssertionError ae) {
				System.out
						.println("#####testMethods|Failed|0/25|Failed for computeDestinyNumber method in Person: "
								+ ae.getMessage() + "#####");
			}
			
					

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testMethods|Failed|0/85|No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out.println("#####testMethods|Failed|0/85|Runtime Exception:"
					+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	

}
