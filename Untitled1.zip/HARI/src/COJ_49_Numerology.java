import java.util.HashMap;

public class COJ_49_Numerology {
	HashMap<Integer, String> planets = new HashMap<Integer, String>();
	HashMap<String, String> planetsCharacteristics = new HashMap<String, String>();

	void loadHasMap() {
		planets.put(1, "Sun");
		planets.put(2, "Moon");
		planets.put(3, "Mars");
		planets.put(4, "Rahu");
		planets.put(5, "Mercury");
		planets.put(6, "Venus");
		planets.put(7, "Ketu");
		planets.put(8, "Saturn");
		planets.put(9, "Mars");
	}

	void loadHashMapCharacteristics() {
		planetsCharacteristics.put("Sun", "Confidence");
		planetsCharacteristics.put("Moon", "Emotions");
		planetsCharacteristics.put("Jupiter", "Knowledge");
		planetsCharacteristics.put("Rahu", "Extravagance");
		planetsCharacteristics.put("Mercury", "Intelligence");
		planetsCharacteristics.put("Venus", "Beauty");
		planetsCharacteristics.put("Ketu", "Philosophy");
		planetsCharacteristics.put("Saturn", "Discipline");
		planetsCharacteristics.put("Mars", "Vitality");
	}

	String getProperties(Person p) {
		p.computeDestinyNumber();
		int dn = p.destinyNumber;
		loadHasMap();
		loadHashMapCharacteristics();
		// System.out.println(planets.get((Integer)dn));
		return "The character of person with " + p.date + "-" + p.month + "-" + p.year
				+ " birth date is "
				+ planetsCharacteristics.get(planets.get(dn));
	}
}

class Person {

	int date;
	int month;
	int year;
	int destinyNumber;

	public Person(int date, int month, int year) {
		this.date = date;
		this.month = month;
		this.year = year;
	}

	void computeDestinyNumber() {
		int temp = Integer.parseInt("" + date + month + year);
		int sum = 0;
		while (true) {
			while (temp != 0) {
				sum += temp % 10;
				temp /= 10;
			}
			if (sum > 9) {
				temp = sum;
				sum = 0;
				continue;
			}
			break;
		}
		destinyNumber = sum;
	}
}