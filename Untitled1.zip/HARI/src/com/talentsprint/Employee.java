package com.talentsprint;

public class Employee {
	
	public int id;
	public String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String name, double basicSalary,
			double hRAPer, double dAPer) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
	}

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer;
	}


}
