package com.talentsprint;

public class Manager {
	
	int id;
	String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;
	public double projectAllowance;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Manager(int id, String name, double basicSalary,
			double hRAPer, double dAPer, double projectAllowance) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.projectAllowance = projectAllowance;
	}

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer + projectAllowance;
	}


}
