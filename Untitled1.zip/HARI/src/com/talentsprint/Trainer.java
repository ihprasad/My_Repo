package com.talentsprint;

public class Trainer {
	
	int id;
	String name;
	public double basicSalary;
	public double HRAPer;
	public double DAPer;
	public int batchCount;
	public double perkPerBatch;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer
				+ ((double) batchCount * perkPerBatch);
	}

	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Trainer(int id, String name, double basicSalary,
			double hRAPer, double dAPer, int batchCount, double perkPerBatch) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

}