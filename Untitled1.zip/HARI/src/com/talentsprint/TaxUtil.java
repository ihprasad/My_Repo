package com.talentsprint;

import com.talentsprint.employeepayrollsystem.entity.Employee;
import com.talentsprint.employeepayrollsystem.entity.Manager;
import com.talentsprint.employeepayrollsystem.entity.Sourcing;
import com.talentsprint.employeepayrollsystem.entity.Trainer;

public class TaxUtil {
	
	public double calculateTax(Employee emp) {
		if (emp.calculateGrossSalary() > 30000)
			return emp.calculateGrossSalary() * 0.2;
		else
			return emp.calculateGrossSalary() * 0.05;
	}

	public double calculateTax(Manager mgr) {
		if (mgr.calculateGrossSalary() > 30000)
			return mgr.calculateGrossSalary() * 0.2;
		else
			return mgr.calculateGrossSalary() * 0.05;
	}

	public double calculateTax(Trainer tr) {
		if (tr.calculateGrossSalary() > 30000)
			return tr.calculateGrossSalary() * 0.2;
		else
			return tr.calculateGrossSalary() * 0.05;
	}

	public double calculateTax(Sourcing scr) {
		if (scr.calculateGrossSalary() > 30000)
			return scr.calculateGrossSalary() * 0.2;
		else
			return scr.calculateGrossSalary() * 0.05;
	}

}
