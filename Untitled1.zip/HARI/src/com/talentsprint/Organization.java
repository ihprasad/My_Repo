package com.talentsprint;

import com.talentsprint.employeepayrollsystem.entity.Employee;


public class Organization {
	
	public String name;
	public Employee[] employeeList;
	public int noOfEmployees;

	public Organization() {
		super();
		// TODO Auto-generated constructor stub
		this.noOfEmployees = 0;
		this.employeeList = new Employee[10];
	}

	public int addEmployee(Employee e) {
		if (noOfEmployees == 10)
			return -1;

		int eid = e.id;
		if (noOfEmployees > 0)
			for (Employee emp : employeeList)
				if (emp != null && emp.id == eid)
					return -2;
		
		

		employeeList[noOfEmployees] = e;
		noOfEmployees++;

		return 0;
	}

	public Employee searchEmployeeByName(String name) {

		name = name.toLowerCase();
		for (Employee emp : employeeList)
			if (emp != null && ((emp.name).toLowerCase()).equals(name))
				return emp;

		return null;
	}

	public Employee getEmployeeById(int id) {

		// for (int i = 0; i < noOfEmployees; i++)
		// if (employeeList[i].id == id)
		// return employeeList[i];

		for (Employee emp : employeeList)
			if (emp != null && emp.id == id)
				return emp;

		return null;
	}

	public boolean deleteEmployee(int id) {
		for (int i = 0; i < noOfEmployees; i++)
			if (employeeList[i].id == id) {
				employeeList[i] = null;
				noOfEmployees--;
				int j = -1;
				for (j = i; j < noOfEmployees; j++) {
					employeeList[j] = employeeList[j + 1];
				}
				employeeList[j] = null;

				return true;
			}

		return false;

	}

	public void printAllEmployees() {
		System.out.println("id, name, basicSalary, HRAPer, DAPer");
		for (Employee emp : employeeList)
			if (emp != null)
				System.out.println(emp.id + ", " + emp.name + ", "
						+ emp.basicSalary + ", " + emp.HRAPer + ", "
						+ emp.DAPer);

	}

}
