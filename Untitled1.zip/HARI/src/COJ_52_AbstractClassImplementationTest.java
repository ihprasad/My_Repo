import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.talentsprint.employeepayrollsystem.entity.Employee;
import com.talentsprint.employeepayrollsystem.entity.Manager;
import com.talentsprint.employeepayrollsystem.entity.Sourcing;
import com.talentsprint.employeepayrollsystem.entity.Trainer;

public class COJ_52_AbstractClassImplementationTest extends TestCase {

	static PrintStream originalOut = System.out;
	OutputStream os = new ByteArrayOutputStream();
	PrintStream ps = new PrintStream(os);

	Shape shp;

	static {
		try {
			Class.forName("Rectangle");
			Class.forName("Circle");
			Class.forName("Triangle");
			Class.forName("Shape");
		} catch (ClassNotFoundException ce) {
			System.out
					.println("#####testClassDefinitions|Failed|0/100|Class not found: "
							+ ce.getMessage() + ".#####");
			System.exit(0);
		}
	}

	@BeforeClass
	protected void setUp() throws Exception {
		super.setUp();
		// obj = new COJ_47_Organization();

		System.setOut(ps);
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@After
	public void cleanUpStreams() {
		// Restore normal operation
		System.setOut(originalOut);
		System.setOut(null);
		System.setErr(null);

	}

	/*****************************************************************************/

	@Test
	public void testConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for employee

			cons = Class.forName("Rectangle").getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals("Rectangle(double,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue("Rectangle(double,double) ", found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
				System.exit(0);

			}

			// constructor for manager
			cons = Class.forName("Circle").getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals("Circle(double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue("Circle(double) ", found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}

			// constructor for Trainer
			cons = Class.forName("Triangle").getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals("Triangle(double,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue("Triangle(double,double) ", found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}

			marks = count * 10;
			originalOut.println("#####testConstructors|Passed|" + marks
					+ "/10|Passed for Constructors. #####");

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testConstructors|Failed|0/100|No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testConstructors|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testAbstract() {
		try {
			int count = 0;
			try {
				assertTrue(
						"",
						Class.forName("Shape").getModifiers() == Modifier.ABSTRACT);

				originalOut
						.println("#####testAbstract|Passed|10/10|Passed Shape as abstract. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testAbstract|Failed|0/100|Default structure is modified: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}
			try {
				Method[] methods = Class.forName("Shape").getDeclaredMethods();
				for (Method m : methods) {
					// originalOut.println(m.getName() + "---" +
					// (Modifier.ABSTRACT == m.getModifiers()) + "---" +
					// m.getReturnType());
					if (m.getName().equals("getArea"))
						if (Modifier.ABSTRACT == m.getModifiers()
								&& (m.getReturnType().toString())
										.equals("double"))
							count++;

					if (m.getName().equals("printDetails"))
						if (Modifier.ABSTRACT == m.getModifiers()
								&& (m.getReturnType().toString())
										.equals("void"))
							count++;
				}

				assertTrue("", count == 2);

				originalOut
						.println("#####testAbstract|Passed|10/10|Passed abstract methods. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testAbstract|Failed|0/100|Default structure is modified: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetArea() {

		try {

			try {
				shp = new Rectangle(30.3, 45.4);
				assertTrue("Failed for getArea of Rectangle",
						shp.getArea() == 1375.62);
				originalOut
						.println("#####testGetArea|Passed|20/20|Passed for method overridden in Rectangle. #####");

			} catch (AssertionError ae) {
				originalOut.println("#####testGetArea|Failed|0/20|"
						+ ae.getMessage() + "#####");
			}

			try {
				shp = new Circle(23.2);
				assertTrue("Failed for getArea of Circle",
						shp.getArea() == 1690.0736);
				originalOut
						.println("#####testGetArea|Passed|20/20|Passed for method overridden in Circle. #####");

			} catch (AssertionError ae) {
				originalOut.println("#####testGetArea|Failed|0/20|"
						+ ae.getMessage() + "#####");
			}

			try {
				shp = new Triangle(146.2, 40.0);
				assertTrue("Failed for getArea of Triangle",
						shp.getArea() == 2924.0);
				originalOut
						.println("#####testGetArea|Passed|20/20|Passed for method overridden in Triangle. #####");

			} catch (AssertionError ae) {
				originalOut.println("#####testGetArea|Failed|0/20|"
						+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testGetArea|Failed|0/60| No such method found: "
							+ e.getMessage() + "#####");
			// System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testGetArea|Failed|0/60 |Runtime Exception:"
							+ e.getMessage() + "#####");
			// System.exit(0);
		}

	}

	@Test
	public void testPrintDetails() {
		try {
			String str = "";
			try {
				shp = new Triangle(146.2, 40.0);
				shp.printDetails();

				assertEquals(
						"Type = Triangle\nBase = 146.2\nHeight = 40.0\nArea = 2924.0\n",
						os.toString());
				originalOut
						.println("#####testPrintDetails|Passed|10/10|Passed for printing details of Triangle. #####");
			} catch (AssertionError e) {
				System.out
						.println("#####testPrintDetails|Failed|0/10|Failed for printing details of Triangle: "
								+ e.getMessage() + ". #####");

			}

			try {
				shp = new Circle(23.2);
				shp.printDetails();
				assertEquals(
						"Type = Circle\nRadius = 23.2\nArea = 1690.0736\n",
						os.toString());
				originalOut
						.println("#####testPrintDetails|Passed|10/10|Passed for printing details of Circle. #####");
			} catch (AssertionError e) {
				System.out
						.println("#####testPrintDetails|Failed|0/10|Failed for printing details of Circle: "
								+ e.getMessage() + ". #####");

			}

			try {
				shp = new Rectangle(30.3, 45.4);
				shp.printDetails();
				assertEquals(
						"Type = Rectangle\nLength = 30.3\nBreadth = 45.4\nArea = 1375.62\n",
						os.toString());
				originalOut
						.println("#####testPrintDetails|Passed|10/10|Passed for printing details of Rectangle. #####");
			} catch (AssertionError e) {
				System.out
						.println("#####testPrintDetails|Failed|0/10|Failed for printing details of Rectangle: "
								+ e.getMessage() + ". #####");

			}
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testPrintDetails|Failed|0/10|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testPrintDetails|Failed|0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testFields() {
		try {
			Method[] mtd = Class.forName("COJ_52_AbstractClassImplementation")
					.getDeclaredMethods();
			for (Method m : mtd) {
				if ((m.getName().toString()).equals("largestArea")
						&& (m.getReturnType().toString()).equals("void")) {
					originalOut.println("********");
				}
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
