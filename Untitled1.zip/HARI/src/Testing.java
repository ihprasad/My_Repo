
public class Testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(new COJ_46_Cylender(5,3).getVolume()); 
		System.out.println(new COJ_46_Circle(-5).getArea()); 
		

	}

}
