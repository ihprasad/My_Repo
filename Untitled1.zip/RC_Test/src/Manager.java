
public class Manager extends Employee{

	String name;
	int p;
	double d;
}
