import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_26_ListToArrayTest {

	@BeforeClass
	public static void setUpBeforeClass() throws NoSuchMethodException,
			SecurityException {
		try {
			ArrayList<Integer> al = new ArrayList<Integer>();

			List<Integer> list = al;

			COJ_26_ListToArray.convertToArray(list);

			System.out
					.println("#####ArrayToList | Passed | 20/20 | Checking for Default structure.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####ArrayToList | Failed | 0/100 | Checking for Default structure.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####ArrayToList | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####ArrayToList | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testConvertToArray() {
		List<Integer> a1 = new ArrayList<Integer>();
		a1.add(1);
		a1.add(2);
		a1.add(3);
//		System.out.println(" ArrayList Elements");
//		System.out.println("\t" + a1);
		try {
//			int[] arr = ListToArray.convertToArray(a1);
//			int[] res = {1, 2, 3};
			assertArrayEquals(new int[]{1,2,3}, COJ_26_ListToArray.convertToArray(a1));
			System.out
					.println("#####testConvertToArray | Passed | 60/60 | Checking convert list to array.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testConvertToArray | Failed | 0/60 | Checking convert list to array.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testConvertToArray | Failed | 0/60 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testConvertToArray | Failed | 0/60 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testNullValue() {

		try {
			String[] inputArray = {};
			List<Integer> a1 = new ArrayList<Integer>();
			assertNull(null, COJ_26_ListToArray.convertToArray(a1));

			System.out
					.println("#####testNullValue | Passed | 20/20 | Checking for null list.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testNullValue | Failed | 0/20 | Checking for null list.#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testNullValue | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testNullValue | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");

		}

	}

}
