import static org.junit.Assert.*;

import java.lang.reflect.Method;

import org.junit.Before;
import org.junit.Test;

public class COJ_06_AnagramTest {

	@Test
	public void testFindAnagrams() {
		try {

			// Anagram obj = new Anagram();

			String result = new COJ_06_Anagram()
					.findAnagrams("listen,silent,part,leloh,trap,tensil,hi,prat,hello,dad");
			// result = new Anagram().findAnagrams("listen,all,silent,lal");

			assertEquals(
					"{listen,silent,tensil}\n{part,trap,prat}\n{leloh,hello}\n",
					result);

			System.out
					.println("#####testDuplicateWords | Passed | 25/25 | Test for duplicate Words in the input.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDuplicateWords | Failed | 0/25 | Test for duplicate Words in the input.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDuplicateWords | Failed | 0/25 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDuplicateWords | Failed | 0/25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDuplicateWords() {
		try {

			// Anagram obj = new Anagram();

			String result = new COJ_06_Anagram()
					.findAnagrams("listen,silent,part,leloh,trap,tensil,hi,prat,hello,listen");
			// result = new Anagram().findAnagrams("listen,all,silent,lal");

			assertEquals(
					"{listen,silent,tensil}\n{part,trap,prat}\n{leloh,hello}\n",
					result);

			System.out
					.println("#####testDuplicateWords | Passed | 15/15 | Test for duplicate Words in the input.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDuplicateWords | Failed | 0/15 | Test for duplicate Words in the input.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDuplicateWords | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDuplicateWords | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testDuplicateLetters() {
		try {

			// Anagram obj = new Anagram();

			String result = new COJ_06_Anagram()
					.findAnagrams("listen,all,silent,lal");
			// result = new Anagram().findAnagrams("listen,all,silent,lal");

			assertEquals(
					"{listen,silent}\n{all,lal}\n",
					result);

			System.out
					.println("#####testDuplicateLetters | Passed | 15/15 | Test for duplicate Letters in the input.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDuplicateLetters | Failed | 0/15 | Test for duplicate Letters in the input.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDuplicateLetters | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDuplicateLetters | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void tesNoAnagrams() {
		try {

			// Anagram obj = new Anagram();

			String result = new COJ_06_Anagram()
					.findAnagrams("listen,all");
			// result = new Anagram().findAnagrams("listen,all,silent,lal");

			assertEquals("",result);

			System.out
					.println("#####tesNoAnagrams | Passed | 15/15 | Test for input with no anagrams.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####tesNoAnagrams | Failed | 0/15 | Test for input with no anagrams.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####tesNoAnagrams | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####tesNoAnagrams | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void tesOnlyAnagrams() {
		try {

			// Anagram obj = new Anagram();

			String result = new COJ_06_Anagram()
					.findAnagrams("listen,all,silent,lal");
			// result = new Anagram().findAnagrams("listen,all,silent,lal");

			assertEquals(
					"{listen,silent}\n{all,lal}\n",
					result);

			System.out
					.println("#####tesOnlyAnagrams | Passed | 15/15 | Test for input with only anagrams.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####tesOnlyAnagrams | Failed | 0/15 | Test for input with only anagrams.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####tesOnlyAnagrams | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####tesOnlyAnagrams | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void tesOnlyOneWord() {
		try {

			// Anagram obj = new Anagram();

			String result = new COJ_06_Anagram()
					.findAnagrams("listen");
			// result = new Anagram().findAnagrams("listen,all,silent,lal");

			assertEquals("",result);

			System.out
					.println("#####tesOnlyOneWord | Passed | 15/15 | Test for input with only one word.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####tesOnlyOneWord | Failed | 0/15 | Test for input with only one word.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####tesOnlyOneWord | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####tesOnlyOneWord | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Before
	public void testIsMethodDef() {
		try {
			Class aClass = new COJ_06_Anagram().getClass();// obtain class object
			Method[] methods = aClass.getDeclaredMethods();

			boolean found = false;
			for (Method m : methods) {
				Class rt = m.getReturnType();
//				System.out.println(m.toString() + ":" + rt + " :: Modifier :: "	+ m.getModifiers());
				if (m.toString().contains("findAnagrams(java.lang.String)")
						&& (rt.toString()).equals("class java.lang.String")
						&& m.getModifiers() == java.lang.reflect.Modifier.PUBLIC) {
					found = true;
					break;
				}
			}
			if (!found) {
				System.out
						.println("Method not found: public static String findAnagrams(String) in Anagrams");
				System.exit(0);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

	}

}
