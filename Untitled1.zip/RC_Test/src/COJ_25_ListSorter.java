import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class COJ_25_ListSorter {

	public static List<Integer> sortIntList(List<Integer> inputList) {
		
		if(inputList.isEmpty() || inputList.equals(null) || inputList == null || inputList.size() == 0)
			return null;
		Collections.sort(inputList);
		return inputList;
	}
	
	public static void main(String[] args) {
		List<Integer> a1 = new ArrayList<Integer>();
		a1.add(3);
		a1.add(1);
		a1.add(3);
	}

}