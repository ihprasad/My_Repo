import static org.junit.Assert.*;

import java.lang.reflect.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_05_RectangleTest {

	static COJ_05_Rectangle obj;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// obj = new Rectangle();
		Field[] fld = COJ_05_Rectangle.class.getDeclaredFields();
		boolean var = false;
		// Arrays.sort(fld);
		int count = 0;
		// System.out.println(fld.length);
		for (int i = 0; i < fld.length; i++) {

			if ("x1".equals(fld[i].getName()) || "x2".equals(fld[i].getName())
					|| "y1".equals(fld[i].getName())
					|| "y2".equals(fld[i].getName())) {
				count++;
				// System.out.println(count);
			}

			if (count == 4)
				var = true;
		}

		if (!var) {
			System.out
					.println("#####TestRectangle | Passed | 0/100 | List of fields or name of fields mis-mached.#####");
			System.exit(0);

		}

	}

	@Test
	public void testRectangle() {
		Constructor[] cons = new COJ_05_Rectangle().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("Rectangle()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);

			assertTrue(accessible);
			System.out
					.println("#####TestRectangle | Passed | 7/7 | Default constructor test: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TestRectangle | Failed | 0/7 | Default constructor test: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TestRectangle | Failed | 0/7 | No such method found: Rectangle()#####");

		} catch (Exception e) {
			System.out
					.println("#####TestRectangle | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testRectangleIntInt() {
		Constructor[] cons = new COJ_05_Rectangle().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("Rectangle(int,int)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);

			assertTrue(accessible);
			System.out
					.println("#####testRectangleIntInt | Passed | 7/7 | Parameterized Constructor test for two integers: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testRectangleIntInt | Failed | 0/7 | Parameterized Constructor test for two integers: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testRectangleIntInt | Failed | 0/7 | No such method found: Rectangle(int, int)#####");

		} catch (Exception e) {
			System.out
					.println("#####testRectangleIntInt | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testRectangleIntIntIntInt() {
		Constructor[] cons = new COJ_05_Rectangle().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("Rectangle(int,int,int,int)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);

			assertTrue(accessible);
			System.out
					.println("#####testRectangleIntIntIntInt | Passed | 7/7 | Parameterized Constructor test for four integers: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testRectangleIntIntIntInt | Failed | 0/7 | Parameterized Constructor test for four integers: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testRectangleIntIntIntInt | Failed | 0/7 | No such method found: Rectangle(int, int, int, int)#####");

		} catch (Exception e) {
			System.out
					.println("#####testRectangleIntIntIntInt | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		} finally {

		}
	}

	@Test
	public void testGetHeight() {
		try {
			obj = null;
			obj = new COJ_05_Rectangle();
			int height = Math.abs(obj.y2 - obj.y1);

			assertEquals(0, obj.getHeight());
			obj = null;
			obj = new COJ_05_Rectangle(2, 5);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(5, obj.getHeight());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, 4, 6);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(1, obj.getHeight());
			System.out
					.println("#####testGetHeight | Passed | 7/7 | Checking for getHeight()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetHeight | Failed | 0/7 | Checking for getHeight()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetHeight | Failed | 0/7 | No such method found: getHeight()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetHeight | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetWidth() {
		try {
			obj = null;
			obj = new COJ_05_Rectangle();
			int height = Math.abs(obj.y2 - obj.y1);

			assertEquals(0, obj.getWidth());
			obj = null;
			obj = new COJ_05_Rectangle(2, 5);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(2, obj.getWidth());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, 5, 6);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(3, obj.getWidth());
			System.out
					.println("#####testGetWidth | Passed | 7/7 | Checking for getWidth()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetWidth | Failed | 0/7 | Checking for getWidth()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetWidth | Failed | 0/7 | No such method found: getWidth()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetWidth | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetArea() {

		try {

			obj = null;
			obj = new COJ_05_Rectangle();

			assertEquals(0, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5);

			assertEquals(10, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5);

			assertEquals(10, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, -5);

			assertEquals(10, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5, 5, 6); // x1 negative

			assertEquals(7, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, -5, 6); // x2 negative

			assertEquals(7, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, -5, 5, 6); // y1 negative

			assertEquals(33, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, 5, -6); // y2 negative

			assertEquals(33, obj.getArea());
			// ***********************************************************

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5, -5, 6); // x1, x2 negative

			assertEquals(3, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(-2, -5, 5, 6); // x1, y1 negative

			assertEquals(77, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5, 5, -6); // x1,y2 negative

			assertEquals(77, obj.getArea());
			// *****************************************************************
			obj = null;
			obj = new COJ_05_Rectangle(2, -5, -5, 6); // y1, x2 negative

			assertEquals(77, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, -5, 5, -6); // y1, y2 negative

			assertEquals(3, obj.getArea());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, -5, -6); // y2,x2 negative

			assertEquals(77, obj.getArea());

			System.out
					.println("#####testGetArea | Passed | 7/7 | Checking for getArea()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetArea | Failed | 0/7 | Checking for getArea()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetArea | Failed | 0/7 | No such method found: getArea()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetArea | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetPerimeter() {

		// perimeter = 2*(Math.abs(x2 - x1)+Math.abs(y2 -y1))
		try {

			obj = null;
			obj = new COJ_05_Rectangle();

			assertEquals(0, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5);

			assertEquals(14, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5);

			assertEquals(14, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, -5);

			assertEquals(14, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5, 5, 6); // x1 negative

			assertEquals(16, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, -5, 6); // x2 negative

			assertEquals(16, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, -5, 5, 6); // y1 negative

			assertEquals(28, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, 5, -6); // y2 negative

			assertEquals(28, obj.getPerimeter());
			// ***********************************************************

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5, -5, 6); // x1, x2 negative

			assertEquals(8, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(-2, -5, 5, 6); // x1, y1 negative

			assertEquals(36, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(-2, 5, 5, -6); // x1,y2 negative

			assertEquals(36, obj.getPerimeter());
			// *****************************************************************
			obj = null;
			obj = new COJ_05_Rectangle(2, -5, -5, 6); // y1, x2 negative

			assertEquals(36, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, -5, 5, -6); // y1, y2 negative

			assertEquals(8, obj.getPerimeter());

			obj = null;
			obj = new COJ_05_Rectangle(2, 5, -5, -6); // y2,x2 negative

			assertEquals(36, obj.getPerimeter());

			System.out
					.println("#####testGetPerimeter | Passed | 7/7 | Checking for getPerimeter()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetPerimeter | Failed | 0/7 | Checking for getPerimeter()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetPerimeter | Failed | 0/7 | No such method found: getPerimeter()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetPerimeter | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testMove() {
		try {
			try {

				COJ_05_Rectangle pojo;
				pojo = new COJ_05_Rectangle();
				pojo.move(5, 5);
				String result = "" + pojo.x1 + pojo.y1 + pojo.x2 + pojo.y2;
				// System.out.println(result);
				assertEquals("5555", result);
				pojo = new COJ_05_Rectangle(1, 2, 3, 4);
				pojo.move(5, 5);
				result = "" + pojo.x1 + pojo.y1 + pojo.x2 + pojo.y2;
				// System.out.println(result);
				assertEquals("6789", result);

				System.out
						.println("#####testMove | Passed | 11/11 | Checking for move() with positive inputs x and y#####");

			} catch (AssertionError e) {
				System.out
						.println("#####testMove | Failed | 0/11 | Checking for move() with positive inputs x and y#####");
			}
			try {

				COJ_05_Rectangle pojo;
				pojo = new COJ_05_Rectangle();
				pojo.move(-5, 5);
				String result = "" + pojo.x1 + pojo.y1 + pojo.x2 + pojo.y2;
				// System.out.println(result);
				assertEquals("-55-55", result);
				pojo = new COJ_05_Rectangle(1, 2, 3, 4);
				pojo.move(-5, 5);
				result = "" + pojo.x1 + pojo.y1 + pojo.x2 + pojo.y2;
				// System.out.println(result);
				assertEquals("-47-29", result);

				System.out
						.println("#####testMove | Passed | 11/11 | Checking for move() with negative input x#####");

			} catch (AssertionError e) {
				System.out
						.println("#####testMove | Failed | 0/11 | Checking for move() with negative input x#####");
			}
			
			try {

				COJ_05_Rectangle pojo;
				pojo = new COJ_05_Rectangle();
				pojo.move(5, -5);
				String result = "" + pojo.x1 + pojo.y1 + pojo.x2 + pojo.y2;
				// System.out.println(result);
				assertEquals("5-55-5", result);
				pojo = new COJ_05_Rectangle(1, 2, 3, 4);
				pojo.move(5, -5);
				result = "" + pojo.x1 + pojo.y1 + pojo.x2 + pojo.y2;
				// System.out.println(result);
				assertEquals("6-38-1", result);

				System.out
						.println("#####testMove | Passed | 11/11 | Checking for move() with negative input y#####");

			} catch (AssertionError e) {
				System.out
						.println("#####testMove | Failed | 0/11 | Checking for move() with negative input y#####");
			}
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testMove | Failed | 0/33 | No such method found: move(int,int)#####");

		} catch (Exception e) {
			System.out
					.println("#####testMove | Failed | 0/33 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testIsPointInside() {

		try {

			try {

				assertFalse(new COJ_05_Rectangle().isPointInside(3, 3));
				assertFalse(new COJ_05_Rectangle(1, 4).isPointInside(3, 3));
				assertFalse(new COJ_05_Rectangle(4, 4, 4, 4).isPointInside(3, 3));
				System.out
						.println("#####testIsPointInside | Passed | 9/9 | Checking for point being outside the rectangle#####");

			} catch (AssertionError e) {
				System.out
						.println("#####testIsPointInside | Failed | 0/9 | Checking for point being outside the rectangle#####"
								+ e.getMessage());
			}

			try {
				assertTrue(new COJ_05_Rectangle().isPointInside(0, 0));

				assertTrue(new COJ_05_Rectangle(3, 3).isPointInside(3, 3));

				assertTrue(new COJ_05_Rectangle(4, 4).isPointInside(3, 3));

				assertTrue(new COJ_05_Rectangle(1, 2, 4, 4).isPointInside(3, 3));

				System.out
						.println("#####testIsPointInside | Passed | 9/9 | Checking for point being inside the rectangle#####");

			} catch (AssertionError e) {
				System.out
						.println("#####testIsPointInside | Failed | 0/9 | Checking for point being inside the rectangle#####"
								+ e.getMessage());
			}

		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testIsPointInside | Failed | 0/18 | No such method found: isPointInside(int,int)#####");

		} catch (Exception e) {
			System.out
					.println("#####testIsPointInside | Failed | 0/18 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
