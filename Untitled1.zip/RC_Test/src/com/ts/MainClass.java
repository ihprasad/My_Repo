package com.ts;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean b = true || false;
		System.out.println(true || false);

	}

	static int test(int a, int b) {
		b = a;
		if (a == b)
			return 1;
		return 0;
	}

}
