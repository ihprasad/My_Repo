package com.ts;

import static org.junit.Assert.*;

import java.lang.reflect.*;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.Test;

public class RectangleTest {

	static Rectangle obj;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// obj = new Rectangle();
		Field[] fld = Rectangle.class.getDeclaredFields();
		boolean var = false;
		// Arrays.sort(fld);
		int count = 0;
		// System.out.println(fld.length);
		for (int i = 0; i < fld.length; i++) {

			if ("x1".equals(fld[i].getName()) || "x2".equals(fld[i].getName())
					|| "y1".equals(fld[i].getName())
					|| "y2".equals(fld[i].getName())) {
				count++;
				// System.out.println(count);
			}

			if (count == 4)
				var = true;
		}
		try {
			assertTrue(var);
			System.out
					.println("#####TestRectangle | Passed | 5/5 | Checking for variables.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####TestRectangle | Failed | 0/100 | Checking for variables.#####");
			System.exit(0);
		}

	}

	@Test
	public void testRectangle() {
		try {
			// obj = new Rectangle();
			assertNotNull(new Rectangle());
			System.out
					.println("#####TestRectangle | Passed | 5/5 | Default constructor test: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TestRectangle | Failed | 0/5 | Default constructor test: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TestRectangle | Failed | 0/5 | No such method found: Rectangle()#####");

		} catch (Exception e) {
			System.out
					.println("#####TestRectangle | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testRectangleIntInt() {
		try {
			assertNotNull(new Rectangle(2, 5));
			System.out
					.println("#####testRectangleIntInt | Passed | 5/5 | Parameterized Constructor test for two integers: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testRectangleIntInt | Failed | 0/5 | Parameterized Constructor test for two integers: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testRectangleIntInt | Failed | 0/5 | No such method found: Rectangle(int, int)#####");

		} catch (Exception e) {
			System.out
					.println("#####testRectangleIntInt | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testRectangleIntIntIntInt() {
		try {
			obj = new Rectangle(2, 5, 4, 6);
			assertNotNull(obj);
			System.out
					.println("#####testRectangleIntIntIntInt | Passed | 5/5 | Parameterized Constructor test for four integers: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testRectangleIntIntIntInt | Failed | 0/5 | Parameterized Constructor test for four integers: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testRectangleIntIntIntInt | Failed | 0/5 | No such method found: Rectangle(int, int, int, int)#####");

		} catch (Exception e) {
			System.out
					.println("#####testRectangleIntIntIntInt | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		} finally {

		}
	}

	@Test
	public void testGetHeight() {
		try {
			obj = null;
			obj = new Rectangle();
			int height = Math.abs(obj.y2 - obj.y1);

			assertEquals(0, obj.getHeight());
			obj = null;
			obj = new Rectangle(2, 5);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(5, obj.getHeight());

			obj = null;
			obj = new Rectangle(2, 5, 4, 6);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(1, obj.getHeight());
			System.out
					.println("#####testGetHeight | Passed | 20/20 | Checking for getHeight()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetHeight | Failed | 0/20 | Checking for getHeight()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetHeight | Failed | 0/20 | No such method found: getHeight()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetHeight | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetWidth() {
		try {
			obj = null;
			obj = new Rectangle();
			int height = Math.abs(obj.y2 - obj.y1);

			assertEquals(0, obj.getWidth());
			obj = null;
			obj = new Rectangle(2, 5);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(2, obj.getWidth());

			obj = null;
			obj = new Rectangle(2, 5, 5, 6);
			// height = Math.abs(obj.y2 - obj.y1);

			assertEquals(3, obj.getWidth());
			System.out
					.println("#####testGetWidth | Passed | 20/20 | Checking for getWidth()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetWidth | Failed | 0/20 | Checking for getWidth()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetWidth | Failed | 0/20 | No such method found: getWidth()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetWidth | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetArea() {

		try {

			obj = null;
			obj = new Rectangle();

			assertEquals(0, obj.getArea());

			obj = null;
			obj = new Rectangle(2, 5);

			assertEquals(10, obj.getArea());

			obj = null;
			obj = new Rectangle(-2, 5);

			assertEquals(10, obj.getArea());

			obj = null;
			obj = new Rectangle(2, -5);

			assertEquals(10, obj.getArea());

			obj = null;
			obj = new Rectangle(-2, 5, 5, 6); // x1 negative

			assertEquals(7, obj.getArea());

			obj = null;
			obj = new Rectangle(2, 5, -5, 6); // x2 negative

			assertEquals(7, obj.getArea());

			obj = null;
			obj = new Rectangle(2, -5, 5, 6); // y1 negative

			assertEquals(33, obj.getArea());

			obj = null;
			obj = new Rectangle(2, 5, 5, -6); // y2 negative

			assertEquals(33, obj.getArea());
			// ***********************************************************

			obj = null;
			obj = new Rectangle(-2, 5, -5, 6); // x1, x2 negative

			assertEquals(3, obj.getArea());

			obj = null;
			obj = new Rectangle(-2, -5, 5, 6); // x1, y1 negative

			assertEquals(77, obj.getArea());

			obj = null;
			obj = new Rectangle(-2, 5, 5, -6); // x1,y2 negative

			assertEquals(77, obj.getArea());
			// *****************************************************************
			obj = null;
			obj = new Rectangle(2, -5, -5, 6); // y1, x2 negative

			assertEquals(77, obj.getArea());

			obj = null;
			obj = new Rectangle(2, -5, 5, -6); // y1, y2 negative

			assertEquals(3, obj.getArea());

			obj = null;
			obj = new Rectangle(2, 5, -5, -6); // y2,x2 negative

			assertEquals(77, obj.getArea());

			System.out
					.println("#####testGetArea | Passed | 20/20 | Checking for getArea()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetArea | Failed | 0/20 | Checking for getArea()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetArea | Failed | 0/20 | No such method found: getArea()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetArea | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetPerimeter() {

		// perimeter = 2*(Math.abs(x2 - x1)+Math.abs(y2 -y1))
		try {

			obj = null;
			obj = new Rectangle();

			assertEquals(0, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, 5);

			assertEquals(14, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(-2, 5);

			assertEquals(14, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, -5);

			assertEquals(14, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(-2, 5, 5, 6); // x1 negative

			assertEquals(16, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, 5, -5, 6); // x2 negative

			assertEquals(16, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, -5, 5, 6); // y1 negative

			assertEquals(28, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, 5, 5, -6); // y2 negative

			assertEquals(28, obj.getPerimeter());
			// ***********************************************************

			obj = null;
			obj = new Rectangle(-2, 5, -5, 6); // x1, x2 negative

			assertEquals(8, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(-2, -5, 5, 6); // x1, y1 negative

			assertEquals(36, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(-2, 5, 5, -6); // x1,y2 negative

			assertEquals(36, obj.getPerimeter());
			// *****************************************************************
			obj = null;
			obj = new Rectangle(2, -5, -5, 6); // y1, x2 negative

			assertEquals(36, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, -5, 5, -6); // y1, y2 negative

			assertEquals(8, obj.getPerimeter());

			obj = null;
			obj = new Rectangle(2, 5, -5, -6); // y2,x2 negative

			assertEquals(36, obj.getPerimeter());

			System.out
					.println("#####testGetPerimeter | Passed | 20/20 | Checking for getPerimeter()#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetPerimeter | Failed | 0/20 | Checking for getPerimeter()#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetPerimeter | Failed | 0/20 | No such method found: getPerimeter()#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetPerimeter | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	
	/*
	 * @Test public void testMove() { obj = null; obj = new Rectangle(2, 5, -5,
	 * -6); }
	 * 
	 * @Test public void testIsPointInside() {
	 * 
	 * // boolean in = (pointx > x1 & pointx < x2 & pointy> y1 & pointy < y2 );
	 * }
	 */
}
