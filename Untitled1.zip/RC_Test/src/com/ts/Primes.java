package com.ts;

public class Primes {
	
	public static void main(String[] args) {
		
		Primes ob = new Primes();
		
		System.out.println(ob.getPrimes(3, 40));
		
	}
	
	 boolean isPrime(int n) //funton for checking prime
     {
         int count=0;
         for(int i=1; i<=n; i++)
             {
                 if(n%i == 0)
                     count++;
             }
         if(count == 2)
             return true;
          else
             return false;
     }
	 
	 String getPrimes(int a, int b){
		 
		 Primes ob = new Primes();
		 String tprimes = "";

         int p = a;
         int q = b;
          
         if(p>q || p < 1 || q > 99)
             return "Error";
         else
         {
             System.out.println("nThe Twin Prime Numbers within the given range are : ");
             for(int i=p; i<=(q-2); i++)
             {
                 if(ob.isPrime(i) == true && ob.isPrime(i+2) == true)
                 {
                	 tprimes += i + "," + (i+2) + ";";
                 }
             }
             if(tprimes.length() == 0)
            	 tprimes += "No Twin Primes Found";
         }                 
		 return tprimes;
	 }

}
