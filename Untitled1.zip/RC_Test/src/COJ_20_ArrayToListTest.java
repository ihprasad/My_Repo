import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_20_ArrayToListTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// System.out.println("Testing");

		try {
			COJ_20_ArrayToList cls = new COJ_20_ArrayToList();
			Class c = cls.getClass();

			String[] ar = {};
			// System.out.println("TEST");

			Method lMethod = c.getMethod("convertToList", ar.getClass());
			// System.out.println(lMethod.toString());
			assertEquals(
					"public static java.util.List COJ_20_ArrayToList.convertToList(java.lang.String[])",
					lMethod.toString());

			System.out
					.println("#####ArrayToList | Passed | 20/20 | Checking for Default structure.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####ArrayToList | Failed | 0/100 | Checking for Default structure.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####ArrayToList | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####ArrayToList | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testConvertToList() {

		try {
			String[] inputArray = { "Talent", "Sprint" };
			ArrayList<String> list = new ArrayList<String>(
					Arrays.asList(inputArray));
			assertEquals(list, COJ_20_ArrayToList.convertToList(inputArray));

			System.out
					.println("#####testConvertToList | Passed | 60/60 | Checking for list.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testConvertToList | Failed | 0/60 | Checking for list.#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testConvertToList | Failed | 0/60 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####ArrayToList | Failed | 0/60 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNullValue() {

		try {
			String[] inputArray = {};
			assertNull(null, COJ_20_ArrayToList.convertToList(inputArray));

			System.out
					.println("#####testNullValue | Passed | 20/20 | Checking for null as input.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testNullValue | Failed | 0/20 | Checking for null as input.#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testNullValue | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testNullValue | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");

		}

	}

}
