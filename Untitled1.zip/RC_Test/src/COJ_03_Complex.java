

public class COJ_03_Complex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Testing");
		COJ_03_Complex c1 = new COJ_03_Complex(2, 3);
		COJ_03_Complex c2 = new COJ_03_Complex(3, 4);
		COJ_03_Complex c = new COJ_03_Complex();
		c = c.add(c1, c2);
		System.out.println(c.real);
		System.out.println(c.printComplex());

	}

	private float real;
	private float imaginary;

	/*** DECLARE TWO FLOAT VARIABLES CALLED "real" AND "imaginary" ******/

	/**
	 * Default constructor - DO NOT DELETE!!
	 */
	public COJ_03_Complex() {
		this.real = 0;
		this.imaginary = 0;
	}

	/**
	 * @param real
	 * @param imaginary
	 */
	public COJ_03_Complex(float real, float imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	/**
	 * Method that adds c2 and c1 and returns the result as a new Complex number
	 * 
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static COJ_03_Complex add(COJ_03_Complex c1, COJ_03_Complex c2) {
		COJ_03_Complex c = new COJ_03_Complex();
		c.real = c1.real + c2.real;
		c.imaginary = c1.imaginary + c2.imaginary;
		
		return c;

	}

	/**
	 * Method that subtracts c2 from c1 and returns the result as a new Complex
	 * number
	 * 
	 * @param c1
	 * @param c2
	 * @return
	 */
	public static COJ_03_Complex substract(COJ_03_Complex c1, COJ_03_Complex c2) {
		COJ_03_Complex c = new COJ_03_Complex();
		c.real = c1.real - c2.real;
		c.imaginary = c1.imaginary - c2.imaginary;
		return c;

	}

	/**
	 * Method that prints the variables of this class in the format
	 * (real,imaginary) for Example: (4.5,7.0)
	 * 
	 * @return
	 */
	public String printComplex() {
		return ("(" + real + "," + imaginary + ")");
	}

}
