import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_25_ListSorterTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			ArrayList<Integer> al = new ArrayList<Integer>();

			List<Integer> list = al;

			COJ_25_ListSorter.sortIntList(list);

			System.out
					.println("#####ListSorter | Passed | 20/20 | Checking for Default structure.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####ListSorter | Failed | 0/100 | Checking for Default structure.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####ListSorter | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####ListSorter | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testSortIntList() {
		List<Integer> a1 = new ArrayList<Integer>();
		a1.add(1);
		a1.add(2);
		a1.add(3);
		// System.out.println(" ArrayList Elements");
		// System.out.println("\t" + a1);
		try {
			// int[] arr = ListToArray.convertToArray(a1);
			// int[] res = {1, 2, 3};
			assertArrayEquals(new int[] { 1, 2, 3 },
					COJ_26_ListToArray.convertToArray(a1));
			System.out
					.println("#####testSortIntList | Passed | 30/30 | Checking sortIntList for ordered input.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testSortIntList | Failed | 0/30 | Checking sortIntList for ordered input.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSortIntList | Failed | 0/30 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSortIntList | Failed | 0/30 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSortIntListInorder() {
		List<Integer> a1 = new ArrayList<Integer>();
		a1.add(3);
		a1.add(1);
		a1.add(2);
		// System.out.println(" ArrayList Elements");
		// System.out.println("\t" + a1);
		try {
			// int[] arr = ListToArray.convertToArray(a1);
			// int[] res = {1, 2, 3};
			List<Integer> l = new ArrayList<Integer>();
			l.add(1);
			l.add(2);
			l.add(3);
			// assertArrayEquals(l,ListSorter.sortIntList(a1));

			assertEquals(l, COJ_25_ListSorter.sortIntList(a1));

			System.out
					.println("#####testSortIntListInorder | Passed | 30/30 | Checking sortIntList for inordered input.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testSortIntListInorder | Failed | 0/30 | Checking sortIntList for inordered input.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSortIntListInorder | Failed | 0/30 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSortIntListInorder | Failed | 0/30 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testNullValue() {

		try {
			List<Integer> a1 = new ArrayList<Integer>();
//			System.out.println(a1);
			assertEquals(null, COJ_25_ListSorter.sortIntList(a1));
			
			System.out
					.println("#####testNullValue | Passed | 20/20 | Checking for null list.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####testNullValue | Failed | 0/20 | Checking for null list.#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testNullValue | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testNullValue | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");

		}

	}

}
