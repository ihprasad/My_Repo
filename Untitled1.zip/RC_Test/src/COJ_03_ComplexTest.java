import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_03_ComplexTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		Field[] fld = COJ_03_Complex.class.getDeclaredFields();
		boolean var = false;
		int count = 0;
		for (int i = 0; i < fld.length; i++) {

			if ("real".equals(fld[i].getName())
					|| "imaginary".equals(fld[i].getName())) {
				if (fld[i].getModifiers() == java.lang.reflect.Modifier.PRIVATE)
					count++;
			}

			if (count == 2)
				var = true;
		}
		try {
			assertTrue("Required structure didn't match ",var); // assert 1
			COJ_03_Complex cls = new COJ_03_Complex();
			Class c = cls.getClass();
			// parameter type is null
			Class[] cArg = new Class[2];
			cArg[0] = COJ_03_Complex.class;
			cArg[1] = COJ_03_Complex.class;

			Method lMethod = c.getMethod("add", cArg);
			// System.out.println("method = " + lMethod.toString());
			assertEquals("public static COJ_03_Complex COJ_03_Complex.add(COJ_03_Complex,COJ_03_Complex)",
					lMethod.toString());
			lMethod = c.getMethod("substract", cArg);
			// System.out.println("method = " + lMethod.toString());
			assertEquals(
					"public static COJ_03_Complex COJ_03_Complex.substract(COJ_03_Complex,COJ_03_Complex)",
					lMethod.toString());

			lMethod = c.getMethod("printComplex");
			// System.out.println("method = " + lMethod.toString());
			assertEquals("public java.lang.String COJ_03_Complex.printComplex()",
					lMethod.toString());

			System.out
					.println("#####ComplexTest | Passed | 5/5 | Checking for Default structure.#####");
		} catch (AssertionError ae) {
			System.out
					.println("#####ComplexTest | Failed | 0/100 | Checking for Default structure: "+ ae.getMessage()+"#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####ComplexTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####ComplexTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testComplex() {

		try {
			assertNotNull(new COJ_03_Complex());
			System.out
					.println("#####testComplex | Passed | 5/5 | Default constructor test: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testComplex | Failed | 0/5 | Default constructor test: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testComplex | Failed | 0/5 | No such method found: Complex()#####");

		} catch (Exception e) {
			System.out
					.println("#####testComplex | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testComplexFloatFloat() {
		try {
			assertNotNull(new COJ_03_Complex(5f, 4f));
			System.out
					.println("#####testComplexFloatFloat | Passed | 5/5 | Default constructor test: Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testComplexFloatFloat | Failed | 0/5 | Default constructor test: Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testComplexFloatFloat | Failed | 0/5 | No such method found: Complex(float, float)#####");

		} catch (Exception e) {
			System.out
					.println("#####testComplexFloatFloat | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testAdd() {

		COJ_03_Complex c1 = new COJ_03_Complex(2f, 2f);
		COJ_03_Complex c2 = new COJ_03_Complex(2f, 2f);
		COJ_03_Complex c0 = new COJ_03_Complex(4f, 4f);

		COJ_03_Complex cx = new COJ_03_Complex();
		try {
			// assertEquals(cx, Complex.add(c1, c2));

			COJ_03_Complex cls = new COJ_03_Complex();
			Class c = cls.getClass();
			Class[] cArg = new Class[2];
			cArg[0] = COJ_03_Complex.class;
			cArg[1] = COJ_03_Complex.class;
			Method lMethod = c.getMethod("add", cArg);

			assertEquals(c, lMethod.getReturnType());

			//
			//
			// Complex c11 = new Complex(2f,3f);
			// Complex c21 = new Complex(1f,3f);
			// Complex c01 = new Complex();
			// assertEquals(c01, new Complex().add(c11, c21));
			//

			System.out
					.println("#####testAdd | Passed | 30/30 | Test for add(): Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testAdd | Failed | 0/30 | Test for add(): Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testAdd | Failed | 0/30 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testAdd | Failed | 0/30 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSubtract() {

		// Complex c = new Complex();
		try {
			COJ_03_Complex cls = new COJ_03_Complex();
			Class c = cls.getClass();
			Class[] cArg = new Class[2];
			cArg[0] = COJ_03_Complex.class;
			cArg[1] = COJ_03_Complex.class;
			Method lMethod = c.getMethod("substract", cArg);

			assertEquals(c, lMethod.getReturnType());

			System.out
					.println("#####testSubtract | Passed | 30/30 | Test for subtract(): Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testSubtract | Failed | 0/30 | Test for subtract(): Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testSubtract | Failed | 0/30 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSubtract | Failed | 0/30 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testPrintComplex() {
		try {
			COJ_03_Complex c = new COJ_03_Complex();
			// assertEquals("(0,0)", c.printComplex());
			COJ_03_Complex c1 = new COJ_03_Complex(2, 3);
			COJ_03_Complex c2 = new COJ_03_Complex(3, 4);
			c = c.add(c1, c2);
			assertEquals("(5.0,7.0)", c.printComplex());
			// System.out.println();
			c = c.substract(c1, c2);
			assertEquals("(-1.0,-1.0)", c.printComplex());

			System.out
					.println("#####testPrintComplex | Passed | 25/25 | Test for printComplex(): Passed#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testPrintComplex | Failed | 0/25 | Test for printComplex(): Failed#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testPrintComplex | Failed | 0/25 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPrintComplex | Failed | 0/25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
