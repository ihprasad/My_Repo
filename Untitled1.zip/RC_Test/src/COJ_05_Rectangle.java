public class COJ_05_Rectangle {
	int x1;
	int y1;
	int x2;
	int y2;

	public COJ_05_Rectangle() {
		this.x1 = 0;
		this.x2 = 0;
		this.y1 = 0;
		this.y2 = 0;

	}

	public COJ_05_Rectangle(int width, int height) {
		this.x1 = 0;
		this.y1 = 0;
		x2 = width;
		y2 = height;

	}

	/**
	 * @param x1
	 * @param y1
	 * @param x2
	 * @param y2
	 */
	public COJ_05_Rectangle(int x1, int y1, int x2, int y2) {
		this.x1 = x1;
		this.x2 = x2;
		this.y1 = y1;
		this.y2 = y2;

	}

	/**
	 * calculate and return the height of the rectangle
	 * 
	 * @return
	 */
	public int getHeight() {
		int height = Math.abs(y2 - y1);
		return height;
	}

	/**
	 * calculate and return the width of the rectangle
	 * 
	 * @return
	 */
	public int getWidth() {
		int width = Math.abs(x2 - x1);
		return width;
	}

	/**
	 * calculate and return the area of the rectangle
	 * 
	 * @return
	 */
	public int getArea() {
		int area = Math.abs(x2 - x1) * Math.abs(y2 - y1);
		return area;
	}

	/**
	 * calculate and return the perimeter of the rectangle
	 * 
	 * @return
	 */
	public int getPerimeter() {
		int perimeter = 2 * (Math.abs(x2 - x1) + Math.abs(y2 - y1));
		return perimeter;
	}

	/**
	 * Move the "ENTIRE" rectangle by the given deltax and deltay this means
	 * that all the corners should be moved
	 * 
	 * @param deltax
	 * @param deltay
	 */

	public void move(int deltax, int deltay) {
		x1 = x1 + deltax;
		y1 = y1 + deltay;
		x2 = x2 + deltax;
		y2 = y2 + deltay;

	}

	/**
	 * Find if a given point as given by co-ordinates pointx and pointy are
	 * inside or outside the rectangle.
	 * 
	 * @param pointx
	 * @param pointy
	 * @return
	 */
	public boolean isPointInside(int pointx, int pointy) {
		return (pointx >= x1 && pointx <= x2 && pointy >= y1 && pointy <= y2);
	}

	public static void main(String[] args) {
		COJ_05_Rectangle pojo;
		pojo = new COJ_05_Rectangle();
		pojo.move(-5, 5);
		
		System.out.println(pojo.x1 + "  " + pojo.y1 + "  " + pojo.x2 + "  " + pojo.y2);
	}

}