
public class CricketStatistics {

	public static void main(String[] args) {
		String[] playerDetails = {"Ganguly;india;120;8500","Sachin;india;200;11500"};
		CricketStatistics c = new CricketStatistics(playerDetails);
		String k[] = c.getPlayersFromCountry("india");
		for(int i = 0; i <  k.length;i++)
		{
			System.out.println(k[i]);
		}

	}
	
	/**
	 * A String array that stores player details
	 * MAX Size of input given can be assumed as 10.
	 */
	private String[] cricketerData;
	
	//TODO getter and setter
	
		
	/**
	 * Default constructor - DO NOT DELETE
	 */
	public CricketStatistics(){	}
	
	/**
	 * constructor 
	 */
	public CricketStatistics(String[] playerDetails){		
		this.cricketerData = playerDetails;	
		
	}
	
	/**
	 * Read the member string array and return the players from the given country
	 * @param country
	 * @return - array of players from that country
	 */
	public String[] getPlayersFromCountry(String country){
		String k[] = null;
		String m[] = new String[10];
		int l = 0;
		for(int i = 0;i < cricketerData.length;i++)
		{
		String a[] =cricketerData[i].split(";");
		if(a[1].equals(country))
		{
			m[l] = a[0];
			l++;
		}
		}
		String p[] = new String[l];
		if(l == 0)
		{
			return k;
		}
		else
		{
			
			for(int i =0;i < l;i++)
			{
			p[i] = m[i];	
			}
			
			return p;
		}
	}
	
	/**
	 * Read the member string array and return the details of the player with the given name
	 * @param name
	 * @return - String with player details
	 */
	public String getPlayerDetails(String name){
		String k = null;
		for(int i = 0;i < cricketerData.length;i++)
		{
		String a[] =cricketerData[i].split(";");
		if(a[0].equals(name))
		{
			k = cricketerData[i];
		}
		}
		return k;
	}
	
	
	/**
	 * Read the member string array in CricketerData.java and return the highest score of the given player
	 * @param name
	 * @return
	 */
	public String getHighestScore(String name){
		String k = null;
		for(int i = 0;i < cricketerData.length;i++)
		{
		String a[] =cricketerData[i].split(";");
		if(a[0].equals(name))
		{
			k = a[2];
		}
		}
		return k;
	}

	public String[] getCricketerData() {
		return cricketerData;
	}

	public void setCricketerData(String[] cricketerData) {
		this.cricketerData = cricketerData;
	}

	

}
