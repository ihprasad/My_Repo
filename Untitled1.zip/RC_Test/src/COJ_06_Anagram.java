import java.util.Arrays;

public class COJ_06_Anagram {

	public static void main(String[] args) {
		COJ_06_Anagram c = new COJ_06_Anagram();
		String k = c
				.findAnagrams("listen,silent,part,leloh,trap,tensil,hi,prat,hello,listen");
		
		String k1 = c.findAnagrams("listen,all,silent,lal");
		System.out.println(k);
		
		System.out.println(k1 + 2);
	}

	public String findAnagrams(String input) {
		String res = "";
		String m = "";
		int a[] = new int[5];
		int k = 0;
		int p = 0;
		int count = 0;
		String in[] = input.split(",");
		for (int i = 0; i < in.length; i++) {

			if (i != 0) {
				for (int s = 0; s < a.length; s++) {
					if (i == a[s]) {
						count++;
					}
				}
			}
			if (count == 0) {

				res = "{" + in[i];
				for (int j = i + 1; j < in.length; j++) {
					if (isAnagram(in[i], in[j])) {
						res = res + "," + in[j];
						k++;
						a[p] = j;
						p++;
					}

				}

				res = res + "}";
				if (k != 0) {

					m = m + res + "\n";
				}
				k = 0;
			}
			count = 0;
		}

		return m;

	}

	boolean isAnagram(String word1, String word2) {

		word1 = word1.toUpperCase();
		word2 = word2.toUpperCase();
		char c1[] = word1.toCharArray();
		char c2[] = word2.toCharArray();
		Arrays.sort(c1);
		Arrays.sort(c2);
		String w1 = new String(c1);
		String w2 = new String(c2);
		if (word1.equals(word2)) {
			return false;
		} else {
			return (w1.compareTo(w2) == 0);
		}

	}

}
