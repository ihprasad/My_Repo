import java.util.ArrayList;
import java.util.List;

public class COJ_26_ListToArray {

	public static int[] convertToArray(List<Integer> inputList) {
		int count = 0;
		
		if(inputList.isEmpty() || inputList.equals(null) || inputList == null)
			return null;
	
		for(int i =0;i<inputList.size();i++)
		{
			
			if(inputList.get(i)!= null)
			{
				count++;
			}
		}
		int a[] = new int[inputList.size()];
//		int j = 0;
		for(int m =0;m<inputList.size();m++)
		{
			
			
			
				a[m] = inputList.get(m);
				
			
		}
		return a;
	}
	
	public static void main(String[] args) {
		List<Integer> a1 = new ArrayList<Integer>();
	      a1.add(1);
	      a1.add(2);
	      a1.add(3);
	      System.out.println(" ArrayList Elements");
	      System.out.println("\t" + a1);
	      
	      int[] arr = convertToArray(a1);
	      
	      for(int i : arr)
	    	  System.out.println(i);
	}

}


