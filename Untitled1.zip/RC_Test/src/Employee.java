
public class Employee {
	
	public String name;
	public float salary;

}
