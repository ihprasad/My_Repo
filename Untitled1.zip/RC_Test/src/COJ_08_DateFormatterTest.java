import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_08_DateFormatterTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		

	}

	@Test
	public void testFormatComma() {
		try {

			assertEquals("2014-12-23",
					new COJ_08_DateFormatter().format("23,dec,2014"));

			System.out
					.println("#####testFormatComma | Passed | 15/15 | Checking for input with  comma.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testFormatComma | Failed | 0/15 | Checking for input with  comma.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFormatComma | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testFormatComma | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testFormatSpace() {
		try {

			assertEquals("2012-05-21",
					new COJ_08_DateFormatter().format("21 May 2012"));
			System.out
					.println("#####testFormatSpace | Passed | 15/15 | Checking for input with space.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testFormatSpace | Failed | 0/15 | Checking for input with space.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFormatSpace | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testFormatSpace | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testFormatCommaSpace() {
		try {

			assertEquals("2012-05-21",
					new COJ_08_DateFormatter().format("21, May, 2012"));
			System.out
					.println("#####testFormatCommaSpace | Passed | 15/15 | Checking for input with  comma and space.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testFormatCommaSpace | Failed | 0/15 | Checking for input with  comma and space.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFormatCommaSpace | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testFormatCommaSpace | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testFormatBoth() {
		try {

			assertEquals("2012-05-21",
					new COJ_08_DateFormatter().format("21, May 2012"));
			System.out
					.println("#####testFormatBoth | Passed | 20/20 | Checking for input with both comma and space.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testFormatBoth | Failed | 0/20 | Checking for input with both comma and space.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFormatBoth | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testFormatBoth | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testFormatInvalid() {
		try {

			assertNull(new COJ_08_DateFormatter().format("21-May-2012"));
			assertNull(new COJ_08_DateFormatter().format("dd mmm yyyy"));
			System.out
					.println("#####testFormatInvalid | Passed | 15/15 | Checking for input with separator ortherthan comma and space.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testFormatInvalid | Failed | 0/15 | Checking for input with separator ortherthan comma and space.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFormatInvalid | Failed | 0/15 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testFormatInvalid | Failed | 0/15 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testFormatFullMonth() {
		try {

			assertEquals("2012-12-21",
					new COJ_08_DateFormatter().format("21,December,2012"));
			System.out
					.println("#####testFormatFullMonth | Passed | 20/20 | Checking for input with full name of month.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testFormatFullMonth | Failed | 0/20 | Checking for input with full name of month.#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testFormatFullMonth | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testFormatFullMonth | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

}
