
public class Clerk extends Employee {

}
