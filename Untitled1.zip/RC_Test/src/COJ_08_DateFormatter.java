public class COJ_08_DateFormatter {

	public static void main(String[] args) {
		COJ_08_DateFormatter d = new COJ_08_DateFormatter();

		String k = "23,december,2014";
		String l = "21, May, 2012";
		String m = "21 May 2012";
		String res = d.format(k);
		System.out.println(res);
		System.out.println(d.format(l));
		System.out.println(d.format(m));
		System.out.println(d.format("ab nnd jjjj"));
	}

	public String format(String input) {
		int k = 0, count = 0;
		String p = "00";
		String l = "";

		for (int i = 0; i < input.length(); i++) {
			if (input.charAt(i) == ',' || input.charAt(i) == ' ') {
				count++;
			}
		}
		if (count > 0) {
			input = input.replace(" , ", ",");
			input = input.replace(" ,", ",");
			input = input.replace(", ", ",");
			input = input.replace(" ", ",");
			String in[] = input.split(",");
			String mon[] = { "0", "jan", "feb", "mar", "apr", "may", "jun",
					"jul", "aug", "sep", "oct", "nov", "dec" };
			String month[] = { "0", "January", "Febraury", "March", "April",
					"May", "June", "July", "August", "September", "October",
					"November", "December" };

			for (int i = 1; i <= 12; i++) {
				if ((month[i]).equalsIgnoreCase(in[1]) || mon[i].equalsIgnoreCase(in[1])) {
					k = i;
					break;
				}
			
			
//			for (int i = 1; i <= 12; i++) {
//				if (month[i].equals(in[1]) || mon[i].equals(in[1])) {
//					k = i;
//					break;
//				}
			}

			if (k < 10) {
				l = "0" + k;
			}
			if (l.equals(p)) {
				return null;
			} else if (k < 10) {
				return in[2] + "-" + l + "-" + in[0];
			} else {
				return in[2] + "-" + k + "-" + in[0];
			}
		} else {
			return null;
		}
	}
}
