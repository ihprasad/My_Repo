import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


public class ECC_43_TwinPrimesTest {

	@Test
	public void twinPrimesTest() {
		try

		{
			assertEquals("3,5;5,7;11,13;17,19;29,31;",ECC_43_TwinPrimes.getTwinPrimes(1,40));
			System.out.println("#####TwinPrimesTest | Passed | 40 / 40 | Passed for TwinPrimes test#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 40 | Failed for TwinPrimes test#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 40 | No such method found: "+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
			.println("#####TwinPrimesTest | Failed | 0 / 40 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	@Test
	public void twinPrimesNegativeTest() {
		try
		{
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(-5,25));
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(-5,-25));
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(5,-25));
			System.out.println("#####TwinPrimesTest | Passed | 10 / 10 | Passed for Negative input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | Failed for negative input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####TwinPrimesTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void twinPrimesZeroTest() {
		try
		{
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(0,10));
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(10,0));
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(0,0));
			System.out.println("#####TwinPrimesTest | Passed | 10 / 10 | Passed for twinPrimesZero input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | Failed for twinPrimesZero input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####TwinPrimesTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	
	
	@Test
	public void twinPrimesMaxRangeTest() {
		try
		{
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(1,105));
			System.out.println("#####TwinPrimesTest | Passed | 20 / 20 | Passed for MaxRangeNumber input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 20 | Failed for MaxRangeNumber input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####TwinPrimesTest | Failed | 0 / 10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void firstInputBeingGreaterthanSecondTest() {
		try
		{
			assertEquals("Error",ECC_43_TwinPrimes.getTwinPrimes(10,5));
			System.out.println("#####TwinPrimesTest | Passed | 10 / 10 | Passed for firstInputBeingGreaterthanSecondTest input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | Failed for firstInputBeingGreaterthanSecondTest input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####TwinPrimesTest | Failed | 0 / 10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	
	
	@Test
	public void rangeOfNoTwinPrimesTest() {
		try
		{
			assertEquals("No Twin Primes Found",ECC_43_TwinPrimes.getTwinPrimes(31,40));
			System.out.println("#####TwinPrimesTest | Passed | 10 / 10 | Passed for rangeOfNoTwinPrimesTest input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | Failed for rangeOfNoTwinPrimesTest input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####TwinPrimesTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####TwinPrimesTest | Failed | 0 / 10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
}
