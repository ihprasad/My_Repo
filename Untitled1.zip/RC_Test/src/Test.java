

import java.lang.*;

//import javax.xml.datatype.DatatypeConstants.Field;

public class Test {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Manager mgr = new Manager();
// gets the super class name
		Class cls;
		cls = mgr.getClass();
		cls = cls.getSuperclass();
		System.out.println(cls.getName());
		
		
		Class c = Class.forName("Employee");
		
//		Class c1 = mgr.getClass().getSuperclass();
		
		System.out.println("C1 " + mgr.getClass().getSuperclass().toString().equals("class Employee"));
		
		// getting name and type of a variable
//		
//		java.lang.reflect.Field[] fld = Manager.class.getDeclaredFields();
//        for (int i = 0; i < fld.length; i++)
//        {
//            System.out.println("Variable Name is : " + fld[i].getName());
//            System.out.println("Generic typr : " + fld[i].getGenericType());
//        }                    

	}

}
