import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class COJ_20_ArrayToList {

	/**
	 * This method converts the input array into a List and return that list
	 * return null for null input
	 * @param inputArray
	 * @return
	 */
	public static List<String> convertToList(String[] inputArray) {
		
		if(inputArray.length == 0 || inputArray.equals(null) || inputArray == null)
			return null;

		ArrayList<String> list = new ArrayList<String>(Arrays.asList(inputArray));
		
	return list;	
	}
	
	public static void main(String[] args) {
		String[] inputArray = {"Talent", "Sprint"};
		List<String> a = convertToList(inputArray);
		for(String s : a)
			System.out.println(s);
	}
	
}
