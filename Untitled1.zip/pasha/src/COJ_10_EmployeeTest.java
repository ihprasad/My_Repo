import static org.junit.Assert.*;

import java.lang.reflect.Constructor;

import org.junit.BeforeClass;
import org.junit.Test;


public class COJ_10_EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
// COJ_10_Manager test case
	@Test
	public void COJ_10_ManagerSetSalaryTest() {
		try {
			try {
				COJ_10_Employee emp = new COJ_10_Manager("Satya", 1, 10000, COJ_10_ManagerType.HR);
				double salary = emp.getSalary();
				assertTrue(Math.abs(salary - 20000.0) < 0.1);
				System.out
						.println("#####ManagerSetSalaryTest | Passed | 10/10 | Passed for HR SalaryTest#####");

			} catch (AssertionError aerrr) {
				System.out
						.println("#####ManagerSetSalaryTest | Failed | 0/10 | Failed for HR COJ_10_ManagerSalaryTest through constructor#####");

			}
			try {
				COJ_10_Employee emp = new COJ_10_Manager("Satya", 1, 10000, COJ_10_ManagerType.SALES);
				double salary = emp.getSalary();
				assertTrue(Math.abs(salary - 15000.0) < 0.1);
				System.out
						.println("#####ManagerSetSalaryTest | Passed | 10/10 | Passed for SALES COJ_10_Manager SalaryTest#####");

			} catch (AssertionError aerrr) {
				System.out
						.println("#####ManagerSetSalaryTest | Failed | 0/10 | Failed for HR SalaryTest through constructor#####");

			}
		} catch (NoSuchMethodError nerror) {
			System.out
					.println("#####MangerSetSalaryTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####MangerSetSalaryTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_10_ManagerDefaultConstructorsTest() {
		try {
			boolean flag = false;
			Constructor s[] = Class.forName("COJ_10_Manager").getConstructors();
			for (int i = 0; i < s.length; i++) {
				if (s[i].toString().equals("public COJ_10_Manager()"))
					flag = true;
			}
			assertTrue(flag);
			System.out
					.println("#####ManagerDefaultConstructorTest | Passed | 10/10 | Passed for COJ_10_ManagerConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ManagerDefaultConstructorTest | Failed | 0/10 | Failed for COJ_10_ManagerDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ManagerDefaultConstructorTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ManagerDefaultConstructorTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_10_ManagerParameterizedConstructorsTest() {
		try {
			boolean flag = false;
			Constructor s[] = Class.forName("COJ_10_Manager").getConstructors();
			for (int i = 0; i < s.length; i++) {
				if (s[i].toString()
						.equals("public COJ_10_Manager(java.lang.String,int,double,COJ_10_ManagerType)"))
					flag = true;
			}
			assertTrue(flag);
			System.out
					.println("#####ManagerParameterizedConstructorTest | Passed | 10/10 | Passed for COJ_10_ManagerConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ManagerParameterizedConstructorTest | Failed | 0/10 | Failed for COJ_10_ManagerParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ManagerParameterizedConstructorTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ManagerParameterizedConstructorTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_10_ManagerInheritanceTest() {
		try {
			String superClass = new COJ_10_Manager().getClass().getSuperclass()
					.toString();
			assertTrue(superClass.equals("class COJ_10_Employee"));
			System.out
					.println("#####ManagerSuperClassTest | Passed | 10/10 | Passed for COJ_10_ManagerSuperClassTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ManagerSuperClassTest | Failed | 0/10 | Failed for COJ_10_ManagerSuperClassTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ManagerSuperClassTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ManagerSuperClassTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	// clerk test case
	
	@Test
	public void clerkSetSalaryTest() {
		try {
			COJ_10_Clerk c =new COJ_10_Clerk("James", 111, 1000, 30, 40);
			assertEquals((int)1000, (int)c.getSalary());
			c.setAccuracy(81);
			c.setSpeed(71);
			assertEquals((int)2000, (int)c.getSalary());
			c.setAccuracy(82);
			c.setSpeed(72);
			assertEquals((int)2000, (int)c.getSalary());

			
			System.out
					.println("#####ClerkTest | Passed | 10/10 | Passed for ClerkSetSalaryTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ClerkTest | Failed | 0/10 | Failed for ClerkSetSalaryTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ClerkTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ClerkTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
// above this
	@Test
	public void clerkDefaultConstructorsTest() {
		try {
			boolean flag = false;
			Constructor s[] = Class.forName("COJ_10_Clerk").getConstructors();
			for (int i = 0; i < s.length; i++) {
				if (s[i].toString().equals("public COJ_10_Clerk()"))
					flag = true;
			}
			assertTrue(flag);
			System.out
					.println("#####ClerkDefaultConstructorTest | Passed | 10/10 | Passed for ClerkConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ClerkDefaultConstructorTest | Failed | 0/10 | Failed for ClerkDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ClerkDefaultConstructorTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ClerkDefaultConstructorTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void courseParameterizedConstructorsTest() {
		try {
			boolean flag = false;
			Constructor s[] = Class.forName("COJ_10_Clerk").getConstructors();
			for (int i = 0; i < s.length; i++) {
				if (s[i].toString().equals(
						"public COJ_10_Clerk(java.lang.String,int,double,int,int)"))

					flag = true;
			}
			assertTrue(flag);
			System.out
					.println("#####ClerkParameterizedConstructorTest | Passed | 10/10 | Passed for ClerkConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ClerkParameterizedConstructorTest | Failed | 0/10 | Failed for ClerkParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ClerkParameterizedConstructorTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ClerkParameterizedConstructorTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void clerkFieldsTest() {
		try {
			String fiel1 = new COJ_10_Clerk().getClass().getDeclaredFields()[0]
					.getName();
			String field2 = new COJ_10_Clerk().getClass().getDeclaredFields()[1]
					.getName();
			assertTrue(fiel1.equals("speed") && field2.equals("accuracy"));
			System.out
					.println("#####ClerkFieldTest | Passed | 10/10 | Passed for ClerkFieldTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ClerkFieldTest | Failed | 0/10 | Failed for ClerkFieldTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ClerkFieldTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ClerkFieldTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void clerkInheritanceTest() {
		try {
			String superClass = new COJ_10_Clerk().getClass().getSuperclass()
					.toString();
			assertTrue(superClass.equals("class COJ_10_Employee"));
			System.out
					.println("#####ClerkSuperClassTest | Passed | 10/10 | Passed for ClerkSuperClassTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ClerkSuperClassTest | Failed | 0/10 | Failed for ClerkSuperClassTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ClerkSuperClassTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ClerkSuperClassTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}



}
