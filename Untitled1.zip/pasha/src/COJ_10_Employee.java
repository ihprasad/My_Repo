// COJ_10_Employee
public class COJ_10_Employee {

	private String name;
	private int employeeId;
	private double salary;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int empId) {
		this.employeeId = empId;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public COJ_10_Employee() {
		this.name = null;
		this.employeeId = 0;
		this.salary = 0;
	}

	public COJ_10_Employee(String name, int empId, double salary) {
		this.name = name;
		this.employeeId = empId;
		this.salary = salary;
	}

}

// ManagerType ENUM
enum COJ_10_ManagerType {
	HR, SALES
};

// Manager

class COJ_10_Manager extends COJ_10_Employee{

	private COJ_10_ManagerType type;

	public COJ_10_Manager() {
	}

	public COJ_10_Manager(String name, int employeeId, double salary,COJ_10_ManagerType type) {
		super(name,employeeId,salary);
		this.type = type;
		setSalary(salary);
	}
	@Override
	public void setSalary(double salary) {
		if (this.type == COJ_10_ManagerType.HR)
			super.setSalary( salary+ 10000);
		else if (this.type == COJ_10_ManagerType.SALES)
			super.setSalary(salary + 5000);
	}

	public COJ_10_ManagerType getType() {
		return type;
	}

	public void setType(COJ_10_ManagerType type) {
		this.type = type;
	}

}

// Clerk

class COJ_10_Clerk extends COJ_10_Employee {
	private int speed;
	private int accuracy;
	private boolean changed;

	public COJ_10_Clerk() {
	}

	public COJ_10_Clerk(String name, int employeeId, double salary, int speed,
			int accuracy) {
		super(name, employeeId, salary);
		this.speed = speed;
		this.accuracy = accuracy;
		this.changed = false;
		this.setSalary(salary);
	}

	@Override
	public void setSalary(double salary) {
		if (changed == false && speed > 70 && accuracy > 80) {
			changed = true;
			super.setSalary(salary + 1000);
		} else
			super.setSalary(salary);
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
		this.setSalary(super.getSalary());
	}

	public int getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
}





