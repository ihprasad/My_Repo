public class COJ_12_Student {
	public int studentId;
	public String studentName;
	private int marks;
	private char grade;

	private void calculateGrade() {
		if (marks > 90)
			grade = 'A';
		else if (marks > 80 && marks <= 90)
			grade = 'B';
		else if (marks > 70 && marks <= 80)
			grade = 'C';
		else if (marks > 60 && marks <= 70)
			grade = 'D';
		else if (marks <= 60)
			grade = 'E';
	}

	public COJ_12_Student() {
	}

	public COJ_12_Student(int studentId, String studentName, int marks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
	}

	public String displayDetails() {
		calculateGrade();
		return "Student [studentId=" + studentId + ", studentName="
				+ studentName + ", marks=" + marks + ", grade=" + grade + "]";
	}
	
	public static void main(String[] args) {
		try{
			COJ_12_Student s = new COJ_12_Student();
		System.out.println("--"+s.grade + "++");
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

}
