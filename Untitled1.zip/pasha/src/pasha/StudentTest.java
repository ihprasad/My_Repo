package pasha;
import static org.junit.Assert.*;

import java.lang.reflect.Constructor;

import org.junit.BeforeClass;
import org.junit.Test;


public class StudentTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	// Course testcases
	
	@Test
	public void courseDefaultConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Course").getConstructors();			
			for(int i=0;i<s.length;i++)
			{
				if(s[i].toString().equals("public Course()"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####CourseDefaultConstructorTest | Passed | 10 / 10 | Passed for CourseConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####CourseDefaultConstructorTest | Failed | 0 / 10 | Failed for CourseDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####CourseDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####CourseDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void courseParameterizedConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Course").getConstructors();			
			for(int i=0;i<s.length;i++)
			{
				if(s[i].toString().equals("public Course(int,java.lang.String)"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####CourseParameterizedConstructorTest | Passed | 30 / 30 | Passed for CourseConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####CourseParameterizedConstructorTest | Failed | 0 / 30 | Failed for CourseParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####CourseParameterizedConstructorTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####CourseParameterizedConstructorTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
			
	
	@Test
	public void courseDisplayMethodTest() {
		try
		{				
			Student student=new Student(10,"xyz",55);
			Course course=new Course(1,"java");
			course.addStudentToCourse(student);
			Department department=new Department(10,"Technical");	
			department.addCourseToDepartment(course);		
			assertEquals("Department [deptartmentId=10, deptartmentName=Technical, coursesInDepartment=Course [courseId=1, courseName=java, studentInCourse=Student [studentId=10, studentName=xyz, marks=55]]]",department.displayDepartmentDetails());			
			System.out.println("#####CourseDisplayMethodTest | Passed | 60 / 60 | Passed for CourseDisplayMethodTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####CourseDisplayMethodTest | Failed | 0 / 60 | Failed for CourseDisplayMethodTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####CourseDisplayMethodTest | Failed | 0 / 60 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####CourseDisplayMethodTest | Failed | 0 / 60 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}		

// Department testcases
	
	@Test
	public void departmentDefaultConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Department").getConstructors();			
			for(int i=0;i<s.length;i++)
			{
				if(s[i].toString().equals("public Department()"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####DepartmentDefaultConstructorTest | Passed | 10 / 10 | Passed for DepartmentConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####DepartmentDefaultConstructorTest | Failed | 0 / 10 | Failed for DepartmentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####DepartmentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####DepartmentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void departmentParameterizedConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Department").getConstructors();			
			for(int i=0;i<s.length;i++)
			{
				if(s[i].toString().equals("public Department(int,java.lang.String)"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####DepartmentParameterizedConstructorTest | Passed | 30 / 30 | Passed for DepartmentConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####DepartmentParameterizedConstructorTest | Failed | 0 / 30 | Failed for DepartmentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####DepartmentParameterizedConstructorTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####DepartmentParameterizedConstructorTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
			
	
	@Test
	public void departmentStudentDisplayMethodTest() {
		try
		{				
			Student student=new Student(10,"xyz",55);
			System.out.println("test1");
			Course course=new Course(1,"java");
			course.addStudentToCourse(student);
			System.out.println("test2");
			Department department=new Department(10,"Technical");	
			department.addCourseToDepartment(course);	
			System.out.println("test3");
			assertEquals("Department [deptartmentId=10, deptartmentName=Technical, coursesInDepartment=Course [courseId=1, courseName=java, studentInCourse=Student [studentId=10, studentName=xyz, marks=55]]]",department.displayDepartmentDetails());			
			System.out.println("#####DepartmentDisplayMethodTest | Passed | 60 / 60 | Passed for DepartmentDisplayMethodTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####DepartmentDisplayMethodTest | Failed | 0 / 60 | Failed for DepartmentDisplayMethodTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####DepartmentDisplayMethodTest | Failed | 0 / 60 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####DepartmentDisplayMethodTest | Failed | 0 / 60 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}		

}
