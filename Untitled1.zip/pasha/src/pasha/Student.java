package pasha;
public class Student {
	private int studentId;
	public String studentName;
	private int marks;

	public Student() {
	}

	public Student(int studentId, String studentName, int marks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.marks = marks;
	}

	public String displayStudentDetails() {
		return "Student [studentId=" + studentId + ", studentName="
				+ studentName + ", marks=" + marks + "]";
	}
}

// class Course Department

class Course {
	int courseId;
	String courseName;
	Student studentInCourse[];
	private static int counter = 0;

	public Course() {
	}

	public Course(int courseId, String courseName) {
		this.courseId = courseId;
		this.courseName = courseName;
		studentInCourse = new Student[20];
	}

	public void addStudentToCourse(Student student) {
		studentInCourse[counter++] = student;
	}

	public String displayCourseDetails() {
		String studentDetails = "";
		for (int i = 0; i < counter; i++) {
			studentDetails = studentDetails
					+ studentInCourse[i].displayStudentDetails();
		}
		// System.out.println(studentDetails);
		return "Course [courseId=" + courseId + ", courseName=" + courseName
				+ ", studentInCourse=" + studentDetails + "]";
	}
}

// class Department

class Department {
	int deptartmentId;
	String deptartmentName;
	Course courseInDepartment[];
	private static int counter = 0;

	public Department() {
	}

	public Department(int deptartmentId, String deptartmentName) {
		this.deptartmentId = deptartmentId;
		this.deptartmentName = deptartmentName;
		courseInDepartment = new Course[20];
	}

	public void addCourseToDepartment(Course course) {
		courseInDepartment[counter++] = course;
	}

	public String displayDepartmentDetails() {
		String courseDetails = "";
		for (Course s : courseInDepartment) {
			courseDetails = courseDetails + s.displayCourseDetails();
		}
		return "Department [deptartmentId=" + deptartmentId
				+ ", deptartmentName=" + deptartmentName
				+ ", coursesInDepartment=" + courseDetails + "]";
	}
}

// class TesterClass
class TesterClass1 {

	public static void main(String[] args) {
		Student student = new Student(10, "xyz", 55);
		Course course = new Course(1, "java");
		course.addStudentToCourse(student);
		Department department = new Department(10, "Technical");
		department.addCourseToDepartment(course);
		System.out.println(student.displayStudentDetails());
		System.out.println(course.displayCourseDetails());
		 System.out.println(department.displayDepartmentDetails());
		
	}
}
