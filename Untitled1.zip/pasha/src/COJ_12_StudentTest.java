import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.junit.Test;

public class COJ_12_StudentTest {
	@Test
	public void studentDefaultConstructorTest() {
		try {
			assertNotNull(new COJ_12_Student());
			System.out
					.println("#####StudentDefaultConstructorTest | Passed | 20/20 | Passed for StudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####StudentDefaultConstructorTest | Failed | 0/20 | Failed for StudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####StudentDefaultConstructorTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####StudentDefaultConstructorTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void studentParameterizedConstructorTest() {
		try {
			assertNotNull(new COJ_12_Student(100, "RAJ", 55));
			System.out
					.println("#####StudentParameterizedConstructorTest | Passed | 20/20 | Passed for StudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####StudentParameterizedConstructorTest | Failed | 0/20 | Failed for StudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####StudentParameterizedConstructorTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####StudentParameterizedConstructorTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void StudentDisplayMethodTest() {
		try {
			COJ_12_Student cOJ_12_Student = new COJ_12_Student(100, "RAJ", 55);
			assertEquals(
					"Student [studentId=100, studentName=RAJ, marks=55, grade=E]",
					cOJ_12_Student.displayDetails());
			System.out
					.println("#####StudentDisplayMethodTest | Passed | 20/20 | Passed for StudentDisplayMethodTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####StudentDisplayMethodTest | Failed | 0/20 | Failed for StudentDisplayMethodTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####StudentDisplayMethodTest | Failed | 0/20 | No such method found: StudentDisplay()#####");

		} catch (Exception e) {
			System.out
					.println("#####StudentDisplayMethodTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void StudentModifierTest() {
		try {
			Field[] fld = COJ_12_Student.class.getDeclaredFields();
			boolean var = false;
			int count = 0;
			for (int i = 0; i < fld.length; i++) {
				// System.out.println(fld[i].getGenericType().getTypeName());
				if ("studentId".equals(fld[i].getName())) {
					if (fld[i].getGenericType().getTypeName().equals("int"))
						if (fld[i].getModifiers() == java.lang.reflect.Modifier.PUBLIC)
							count++;
					// var = true;
				}
				if ("studentName".equals(fld[i].getName())) {
					if (fld[i].getGenericType().getTypeName()
							.equals("java.lang.String"))
						if (fld[i].getModifiers() == java.lang.reflect.Modifier.PUBLIC)
							count++;
					// var = true;
				}
				if ("marks".equals(fld[i].getName())) {
					if (fld[i].getGenericType().getTypeName().equals("int"))
						if (fld[i].getModifiers() == java.lang.reflect.Modifier.PRIVATE)
							count++;
					// var = true;
				}

				if ("grade".equals(fld[i].getName())) {
					if (fld[i].getGenericType().getTypeName()
							.equals("char"))
						if (fld[i].getModifiers() == java.lang.reflect.Modifier.PRIVATE)
							count++;
					// var = true;
				}

			}
			if (count == 4)
				var = true;

			assertTrue(var);

			System.out
					.println("#####StudentModifierTest | Passed | 20/20 | Passed for StudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0/20 | Failed for StudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void StudentGradeTest() {
		try {
			COJ_12_Student cls = new COJ_12_Student();
			Class c = cls.getClass();
			Method lMethod;
			Method[] m = c.getDeclaredMethods();
			boolean var = false;
			for (Method m1 : m) {
				if (m1.getName().equals("calculateGrade")
						&& m1.getGenericReturnType().getTypeName()
								.equals("void")
						&& m1.getModifiers() == java.lang.reflect.Modifier.PRIVATE)
					var = true;
			}
			assertTrue("No such method found: private void calculateGrade()",
					var);
			System.out
					.println("#####StudentGradeTest | Passed | 20/20 | Passed for StudentGradeTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####StudentGradeTest | Failed | 0/20 | StudentGradeTest "
							+ e.getMessage() + "#####");
		}
	}
}
