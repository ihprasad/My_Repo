package fails;

public class COJ_09_AbstractClassesStudents {
	public static void main(String[] args) {
		System.out.println(new ScienceStudent("RAJ", "JAVA", 55, 66, 88)
							.getPercentage());
	}

}




// Student class
abstract class Student {
	protected String studentName;
	protected String studentClass;
	protected static int totalNoOfStudent=0;
	abstract public int getPercentage();
	static int getTotalNoStudents()
	{
		return totalNoOfStudent;
	}
	public Student()
	{}
	public Student(String studentName, String studentClass) {
		this.studentName = studentName;
		this.studentClass = studentClass;
		totalNoOfStudent++;
	}
	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentClass="
				+ studentClass + "]";
	}	
}

// Science student class

class ScienceStudent extends Student {
	private int physicsMarks;
	private int chemistryMarks;
	private int mathsMarks;
	
	@Override
	
	public int getPercentage() {

		return ((physicsMarks+chemistryMarks+mathsMarks)*100)/300;
	}
	public ScienceStudent()
	{}
	public ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}	
	
	public String displayScienceStudent() {
		return "ScienceStudent [physicsMarks=" + physicsMarks
				+ ", chemistryMarks=" + chemistryMarks + ", mathsMarks="
				+ mathsMarks + ", studentName=" + studentName
				+ ", studentClass=" + studentClass + ", Total Student="+ totalNoOfStudent+"]";
	}	
}


// History student class

class HistoryStudent extends Student{
	private int historyMarks;
	private int civicsMarks;
	
	@Override
	public int getPercentage() {
	
		return ((historyMarks+civicsMarks)*100)/200;
	}
	
	public HistoryStudent()
	{}

	public HistoryStudent(String studentName,String studentClass,int historyMarks, int civicsMarks) {
		super(studentName,studentClass);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}


	public String displayHistoryStudent() {
		return "HistoryStudent [historyMarks=" + historyMarks
				+ ", civicsMarks=" + civicsMarks + ", studentName="
				+ studentName + ", studentClass=" + studentClass + ", Total Student="+ totalNoOfStudent+"]";
	}
}