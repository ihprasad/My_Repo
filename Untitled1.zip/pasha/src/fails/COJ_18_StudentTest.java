package fails;
import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.BeforeClass;
import org.junit.Test;


public class COJ_18_StudentTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	// science student
	
	@Test
	public void scienceStudentDefaultConstructorTest() {
		try
		{			
			assertNotNull(new COJ_18_ScienceStudent());
			System.out.println("#####ScienceStudentDefaultConstructorTest | Passed | 10 / 10 | Passed for ScienceStudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 40 | Failed for ScienceStudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	
	@Test
	public void scienceStudentParameterizedConstructorTest() {
		try
		{			
			assertNotNull(new COJ_18_ScienceStudent("RAJ","JAVA",55,66,88));
			System.out.println("#####ScienceStudentParameterizedConstructorTest | Passed | 20 / 20 | Passed for ScienceStudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 20 | Failed for ScienceStudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
		
	
	@Test
	public void ScienceStudentDisplayMethodTest() {
		try
		{			
			COJ_18_ScienceStudent scienceStudent=new COJ_18_ScienceStudent("RAJ","JAVA",55,66,88);
			assertEquals("ScienceStudent [physicsMarks=55, chemistryMarks=66, mathsMarks=88, studentName=RAJ, studentClass=JAVA, Total Student=3]",scienceStudent.displayScienceStudent());			
			System.out.println("#####StudentDisplayMethodTest | Passed | 20 / 20 | Passed for ScienceStudentDisplayMethodTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentDisplayMethodTest | Failed | 0 / 20 | Failed for ScienceStudentDisplayMethodTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####ScienceStudentDisplayMethodTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentDisplayMethodTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}	
	
	
	@Test
	public void ScienceStudentModifierTest() {
		try
		{			
			int modifier1=new COJ_18_ScienceStudent().getClass().getDeclaredFields()[0].getModifiers();
			int modifier2=new COJ_18_ScienceStudent().getClass().getDeclaredFields()[1].getModifiers();
			int modifier3=new COJ_18_ScienceStudent().getClass().getDeclaredFields()[1].getModifiers();
			assertTrue(modifier1 == Modifier.PRIVATE && modifier2 == Modifier.PRIVATE && modifier3 == Modifier.PRIVATE);
			System.out.println("#####ScienceStudentModifierTest | Passed | 10 / 10 | Passed for ScienceStudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentModifierTest | Failed | 0 / 40 | Failed for ScienceStudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentModifierTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	@Test
	public void ScienceStudentgetPercentageTest() {
		try
		{			
			assertEquals(69,new COJ_18_ScienceStudent("RAJ","JAVA",55,66,88).getPercentage());
			System.out.println("#####ScienceStudentgetPercentageTest | Passed | 10 / 10 | Passed for ScienceStudentgetPercentageTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 40 | Failed for ScienceStudentgetPercentageTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void ScienceStudentInheritanceTest() {
		try
		{			
			assertTrue(new COJ_18_ScienceStudent().getClass().getSuperclass().getName().equals("COJ_18_Student"));
			System.out.println("#####ScienceStudentInheritance | Passed | 10 / 10 | Passed for ScienceStudentInheritance#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ScienceStudentInheritance | Failed | 0 / 40 | Failed for ScienceStudentInheritance#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentInheritance | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ScienceStudentInheritance | Failed | 0 / 40 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	// History student
	
	@Test
	public void historyStudentDefaultConstructorTest() {
		try
		{			
			assertNotNull(new COJ_18_HistoryStudent());
			System.out.println("#####HistoryStudentDefaultConstructorTest | Passed | 10 / 10 | Passed for HistoryStudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 | Failed for HistoryStudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	
	@Test
	public void historyStudentParameterizedConstructorTest() {
		try
		{			
			assertNotNull(new COJ_18_HistoryStudent("RAJ","INTER",55, 77));
			System.out.println("#####HistoryStudentParameterizedConstructorTest | Passed | 20 / 20 | Passed for HistoryStudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 20 | Failed for HistoryStudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
		
	
	@Test
	public void historyStudentDisplayMethodTest() {
		try
		{			
			COJ_18_HistoryStudent historyStudent=new COJ_18_HistoryStudent("RAJ","INTER",55, 77);
			assertEquals("HistoryStudent [historyMarks=55, civicsMarks=77, studentName=RAJ, studentClass=INTER, Total Student=2]",historyStudent.displayHistoryStudent());			
			System.out.println("#####StudentDisplayMethodTest | Passed | 20 / 20 | Passed for HistoryStudentDisplayMethodTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentDisplayMethodTest | Failed | 0 / 20 | Failed for HistoryStudentDisplayMethodTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####HistoryStudentDisplayMethodTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentDisplayMethodTest | Failed | 0 / 20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}	
	
	
	@Test
	public void HistoryStudentModifierTest() {
		try
		{			
			int modifier1=new COJ_18_HistoryStudent().getClass().getDeclaredFields()[0].getModifiers();
			int modifier2=new COJ_18_HistoryStudent().getClass().getDeclaredFields()[1].getModifiers();
			assertTrue(modifier1 == Modifier.PRIVATE && modifier2 == Modifier.PRIVATE);
			System.out.println("#####HistoryStudentModifierTest | Passed | 10 / 10 | Passed for HistoryStudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentModifierTest | Failed | 0 / 40 | Failed for HistoryStudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentModifierTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void historyStudentgetPercentageTest() {
		try
		{			

			assertEquals(0,new COJ_18_HistoryStudent().getPercentage());
			System.out.println("#####HistoryStudentgetPercentageTest | Passed | 10 / 10 | Passed for HistoryStudentgetPercentageTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 40 | Failed for HistoryStudentgetPercentageTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	@Test
	public void HistoryStudentInheritanceTest() {
		try
		{			
			assertTrue(new COJ_18_HistoryStudent().getClass().getSuperclass().getName().equals("COJ_18_Student"));
			System.out.println("#####HistoryStudentInheritance | Passed | 10 / 10 | Passed for HistoryStudentInheritance#####");

		} catch (AssertionError e) {
			System.out
			.println("#####HistoryStudentInheritance | Failed | 0 / 40 | Failed for HistoryStudentInheritance#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####HistoryStudentInheritance | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####HistoryStudentInheritance | Failed | 0 / 40 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	
	// Student as abstract
	
	@Test
	public void StudentAbstractTest() {
		try
		{						
			
			
			assertTrue(Class.forName("COJ_18_Student").getModifiers() == (Modifier.ABSTRACT + Modifier.PUBLIC));
			
			
			System.out.println("#####StudentModifierTest | Passed | 10 / 10 | Passed for StudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####StudentModifierTest | Failed | 0 / 40 | Failed for StudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####StudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####StudentModifierTest | Failed | 0 / 40 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}



}
