package fails;
public abstract class COJ_18_Student {
	protected String studentName;
	protected String studentClass;
	protected static int totalNoOfStudent = 0;

	abstract public int getPercentage();

	static int getTotalNoStudents() {
		return totalNoOfStudent;
	}

	public COJ_18_Student() {
	}

	public COJ_18_Student(String studentName, String studentClass) {
		this.studentName = studentName;
		this.studentClass = studentClass;
		totalNoOfStudent++;
	}

	@Override
	public String toString() {
		return "Student [studentName=" + studentName + ", studentClass="
				+ studentClass + "]";
	}
}

// History student

class COJ_18_HistoryStudent extends COJ_18_Student{
	private int historyMarks;
	private int civicsMarks;
	
	@Override
	public int getPercentage() {
	
		return ((historyMarks+civicsMarks)*100)/200;
	}
	
	public COJ_18_HistoryStudent()
	{}

	public COJ_18_HistoryStudent(String studentName,String studentClass,int historyMarks, int civicsMarks) {
		super(studentName,studentClass);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}


	public String displayHistoryStudent() {
		return "HistoryStudent [historyMarks=" + historyMarks
				+ ", civicsMarks=" + civicsMarks + ", studentName="
				+ studentName + ", studentClass=" + studentClass + ", Total Student="+ totalNoOfStudent+"]";
	}
}


// Science student


class COJ_18_ScienceStudent extends COJ_18_Student {
	private int physicsMarks;
	private int chemistryMarks;
	private int mathsMarks;
	
	@Override
	
	public int getPercentage() {

		return ((physicsMarks+chemistryMarks+mathsMarks)*100)/300;
	}
	public COJ_18_ScienceStudent()
	{}
	public COJ_18_ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}	
	
	public String displayScienceStudent() {
		return "ScienceStudent [physicsMarks=" + physicsMarks
				+ ", chemistryMarks=" + chemistryMarks + ", mathsMarks="
				+ mathsMarks + ", studentName=" + studentName
				+ ", studentClass=" + studentClass + ", Total Student="+ totalNoOfStudent+"]";
	}	
}

