import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.Test;

public class COJ_18_StudentTest {
	@Test
	public void StudentAbstractTest() {
		try {
			assertTrue(Class.forName("COJ_18_Student").getModifiers() == (Modifier.ABSTRACT + Modifier.PUBLIC));
			System.out
					.println("#####StudentModifierTest | Passed | 10 / 10 | Passed for StudentModifierTest#####");
		} catch (AssertionError e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0 / 10 | Failed for StudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####StudentModifierTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void historyStudentDefaultConstructorTest() {
		try {
			assertNotNull(new COJ_18_HistoryStudent());
			System.out
					.println("#####HistoryStudentDefaultConstructorTest | Passed | 10 / 10 | Passed for HistoryStudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 | Failed for HistoryStudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####HistoryStudentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void histroyStudentParameterizedConstructorTest() {
		try {
			assertNotNull(new COJ_18_HistoryStudent("RAJ", "INTER", 55, 77));
			System.out
					.println("#####HistoryStudentParameterizedConstructorTest | Passed | 5 / 5 | Passed for HistoryStudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 5 | Failed for HistoryStudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 5 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####HistoryStudentParameterizedConstructorTest | Failed | 0 / 5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void HistoryStudentModifierTest() {
		try {
			int modifier1 = new COJ_18_HistoryStudent().getClass().getDeclaredFields()[0]
					.getModifiers();
			int modifier2 = new COJ_18_HistoryStudent().getClass().getDeclaredFields()[1]
					.getModifiers();
			assertTrue(modifier1 == Modifier.PRIVATE
					&& modifier2 == Modifier.PRIVATE);
			System.out
					.println("#####HistoryStudentModifierTest | Passed | 10 / 10 | Passed for HistoryStudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####HistoryStudentModifierTest | Failed | 0 / 10 | Failed for HistoryStudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####HistoryStudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####HistoryStudentModifierTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void HistoryStudentgetPercentageTest() {
		try {
			assertEquals(75,
					new COJ_18_HistoryStudent("Satya", "9", 70, 80).getPercentage());
			System.out
					.println("#####HistoryStudentgetPercentageTest | Passed | 10 / 10 | Passed for HistoryStudentgetPercentageTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 10 | Failed for HistoryStudentgetPercentageTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####HistoryStudentgetPercentageTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void HistoryStudentInheritanceTest() {
		try {
			assertTrue(new COJ_18_HistoryStudent().getClass().getSuperclass()
					.getName().equals("COJ_18_Student"));
			System.out
					.println("#####HistoryStudentInheritance | Passed | 10 / 10 | Passed for HistoryStudentInheritance#####");

		} catch (AssertionError e) {
			System.out
					.println("#####HistoryStudentInheritance | Failed | 0 / 10 | Failed for HistoryStudentInheritance#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####HistoryStudentInheritance | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####HistoryStudentInheritance | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void scienceStudentDefaultConstructorTest() {
		try {
			assertNotNull(new COJ_18_ScienceStudent());
			System.out
					.println("#####ScienceStudentDefaultConstructorTest | Passed | 10 / 10 | Passed for ScienceStudentDefaultConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 | Failed for ScienceStudentDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ScienceStudentDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void scienceStudentParameterizedConstructorTest() {
		try {
			assertNotNull(new COJ_18_ScienceStudent("RAJ", "JAVA", 55, 66, 88));
			System.out
					.println("#####ScienceStudentParameterizedConstructorTest | Passed | 10 / 10 | Passed for ScienceStudentParameterizedConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 10 | Failed for ScienceStudentParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ScienceStudentParameterizedConstructorTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}


	@Test
	public void ScienceStudentModifierTest() {
		try {
			int modifier1 = new COJ_18_ScienceStudent().getClass().getDeclaredFields()[0]
					.getModifiers();
			int modifier2 = new COJ_18_ScienceStudent().getClass().getDeclaredFields()[1]
					.getModifiers();
			int modifier3 = new COJ_18_ScienceStudent().getClass().getDeclaredFields()[1]
					.getModifiers();
			assertTrue(modifier1 == Modifier.PRIVATE
					&& modifier2 == Modifier.PRIVATE
					&& modifier3 == Modifier.PRIVATE);
			System.out
					.println("#####ScienceStudentModifierTest | Passed | 10 / 10 | Passed for ScienceStudentModifierTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ScienceStudentModifierTest | Failed | 0 / 10 | Failed for ScienceStudentModifierTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ScienceStudentModifierTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ScienceStudentModifierTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void ScienceStudentgetPercentageTest() {
		try {
			assertEquals(69,
					new COJ_18_ScienceStudent("RAJ", "JAVA", 55, 66, 88)
							.getPercentage());
			System.out
					.println("#####ScienceStudentgetPercentageTest | Passed | 10 / 10 | Passed for ScienceStudentgetPercentageTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 | Failed for ScienceStudentgetPercentageTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ScienceStudentgetPercentageTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void ScienceStudentInheritanceTest() {
		try {
			assertTrue(new COJ_18_ScienceStudent().getClass().getSuperclass()
					.getName().equals("COJ_18_Student"));
			System.out
					.println("#####ScienceStudentInheritance | Passed | 5 / 5 | Passed for ScienceStudentInheritance#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ScienceStudentInheritance | Failed | 0 / 5 | Failed for ScienceStudentInheritance#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ScienceStudentInheritance | Failed | 0 / 5 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ScienceStudentInheritance | Failed | 0 / 5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}