package test;

import static org.junit.Assert.*;

import java.lang.reflect.Constructor;

import org.junit.BeforeClass;
import org.junit.Test;

public class EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

// manager
	@Test
	public void managerDefaultConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Manager").getConstructors();			
			for(int i=0;i<s.length;i++)
			{
				if(s[i].toString().equals("public Manager()"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####ManagerDefaultConstructorTest | Passed | 10 / 10 | Passed for ManagerConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ManagerDefaultConstructorTest | Failed | 0 / 10 | Failed for ManagerDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ManagerDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ManagerDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void courseParameterizedConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Manager").getConstructors();			
			for(int i=0;i<s.length;i++)
			{				
				if(s[i].toString().equals("public Manager(int,int)"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####ManagerParameterizedConstructorTest | Passed | 30 / 30 | Passed for ManagerConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ManagerParameterizedConstructorTest | Failed | 0 / 30 | Failed for ManagerParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ManagerParameterizedConstructorTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ManagerParameterizedConstructorTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void managerEnumTest() {
		try
		{			
			String fiel1=new Manager().getClass().getDeclaredFields()[0].getName();
			String field2=new Manager().getClass().getDeclaredFields()[1].getName();
			assertTrue(fiel1.equals("speed") && field2.equals("accuracy"));
			System.out.println("#####ManagerFieldTest | Passed | 30 / 30 | Passed for ManagerFieldTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ManagerFieldTest | Failed | 0 / 40 | Failed for ManagerFieldTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ManagerFieldTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ManagerFieldTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void managerInheritanceTest() {
		try
		{			
			String superClass=new Manager().getClass().getSuperclass().toString();	
			assertTrue(superClass.equals("class Employee"));			
			System.out.println("#####ManagerSuperClassTest | Passed | 30 / 30 | Passed for ManagerSuperClassTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ManagerSuperClassTest | Failed | 0 / 30 | Failed for ManagerSuperClassTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ManagerSuperClassTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ManagerSuperClassTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void courseSetSalaryTest() {
		try
		{			
			//ADD CODE HERE
			System.out.println("#####ManagerParameterizedConstructorTest | Passed | 30 / 30 | Passed for ManagerConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ManagerParameterizedConstructorTest | Failed | 0 / 30 | Failed for ManagerParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ManagerParameterizedConstructorTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ManagerParameterizedConstructorTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	@Test
	public void clerkDefaultConstructorsTest() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Clerk").getConstructors();			
			for(int i=0;i<s.length;i++)
			{
				if(s[i].toString().equals("public Clerk()"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####ClerkDefaultConstructorTest | Passed | 10 / 10 | Passed for ClerkConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ClerkDefaultConstructorTest | Failed | 0 / 10 | Failed for ClerkDefaultConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ClerkDefaultConstructorTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ClerkDefaultConstructorTest | Failed | 0 / 10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void courseParameterizedConstructorsTest1() {
		try
		{			
			boolean flag=false;
			Constructor s[]=Class.forName("Clerk").getConstructors();			
			for(int i=0;i<s.length;i++)
			{				System.out.println(s[i].toString());
				if(s[i].toString().equals("public Clerk(int,int)"))
					flag=true;
			}
			assertTrue(flag);
			System.out.println("#####ClerkParameterizedConstructorTest | Passed | 30 / 30 | Passed for ClerkConstructorTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ClerkParameterizedConstructorTest | Failed | 0 / 30 | Failed for ClerkParameterizedConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ClerkParameterizedConstructorTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ClerkParameterizedConstructorTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void clerkFieldsTest() {
		try
		{			
			String fiel1=new Clerk().getClass().getDeclaredFields()[0].getName();
			String field2=new Clerk().getClass().getDeclaredFields()[1].getName();
			assertTrue(fiel1.equals("speed") && field2.equals("accuracy"));
			System.out.println("#####ClerkFieldTest | Passed | 30 / 30 | Passed for ClerkFieldTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ClerkFieldTest | Failed | 0 / 40 | Failed for ClerkFieldTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ClerkFieldTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ClerkFieldTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

	@Test
	public void clerkInheritanceTest() {
		try
		{			
			String superClass=new Clerk().getClass().getSuperclass().toString();	
			assertTrue(superClass.equals("class Employee"));			
			System.out.println("#####ClerkSuperClassTest | Passed | 30 / 30 | Passed for ClerkSuperClassTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####ClerkSuperClassTest | Failed | 0 / 30 | Failed for ClerkSuperClassTest#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ClerkSuperClassTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####ClerkSuperClassTest | Failed | 0 / 30 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}


}
