package test;

public class Employee {
	String name;
	int employeeId;
	double salary;
	public Employee() {
		super();
	}
	public Employee(String name, int employeeId, double salary) {
		super();
		this.name = name;
		this.employeeId = employeeId;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	

}
enum ManagerType {
	 HR,sales;

}

class Manager extends Employee {
	 ManagerType managerType;

	public Manager() {
		super();
	}

	public Manager(ManagerType managerType) {
		super();
		this.managerType = managerType;
	}

	public ManagerType getManagerType() {
		return managerType;
	}

	public void setManagerType(ManagerType managerType) {
		this.managerType = managerType;
	}
	 
	 void setSalary(Employee e){
				 ManagerType m = ManagerType.HR;
			if(m.equals(m)){
			 double  i = e.getSalary();
			 i = i+10000;
			 System.out.println("salary is .."+i);
		 }
		 else {
			 double  d = e.getSalary();
			 d = d + 5000;
			 System.out.println("salary is .."+d);
		 }
	 }

}
class Clerk extends Employee{
	int speed;
	int accuracy;
	public Clerk() {
		super();
	}
	public Clerk(int speed, int accuracy) {
		super();
		this.speed = speed;
		this.accuracy = accuracy;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAccuracy() {
		return accuracy;
	}
	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
	
	void setSalary(){
		if((speed>70) && (accuracy>80)){
			salary = salary+1000;
			System.out.println(salary);
		}
		else {
			salary = salary;
			System.out.println(salary);
		}
	}
	

}

