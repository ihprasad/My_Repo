public abstract class COJ_18_Student {
	protected String studentName;
	protected String studentClass;
	protected static int totalNoOfStudents=0;
	static int getTotalNoOfStudents()
	{
		return totalNoOfStudents;
	}
	public COJ_18_Student()
	{}
	public COJ_18_Student(String studentName, String studentClass) {
		this.studentName = studentName;
		this.studentClass = studentClass;
		totalNoOfStudents++;
	}
	abstract public int getPercentage();	
}
class COJ_18_HistoryStudent extends COJ_18_Student{
	private int historyMarks;
	private int civicsMarks;
	
	public COJ_18_HistoryStudent()
	{}

	public COJ_18_HistoryStudent(String studentName,String studentClass,int historyMarks, int civicsMarks) {
		super(studentName,studentClass);
		this.historyMarks = historyMarks;
		this.civicsMarks = civicsMarks;
	}


	
	@Override
	public int getPercentage() {
	
		return ((historyMarks+civicsMarks)*100)/200;
	}
}

class COJ_18_ScienceStudent extends COJ_18_Student {
	private int physicsMarks;
	private int chemistryMarks;
	private int mathsMarks;
	
	@Override
	public int getPercentage() {

		return ((physicsMarks+chemistryMarks+mathsMarks)*100)/300;
	}
	public COJ_18_ScienceStudent()
	{}
	public COJ_18_ScienceStudent(String studentName,String studentClass,int physicsMarks, int chemistryMarks, int mathsMarks) {
		super(studentName,studentClass);
		this.physicsMarks = physicsMarks;
		this.chemistryMarks = chemistryMarks;
		this.mathsMarks = mathsMarks;
	}	
	
	
}

class StudentTester {
	public static void main(String[] args) {
		COJ_18_ScienceStudent scienceStudent = new COJ_18_ScienceStudent("RAJ", "JAVA", 55,66, 88);
//		System.out.println(scienceStudent.displayScienceStudent());
		COJ_18_HistoryStudent historyStudent = new COJ_18_HistoryStudent("kumar",
				"indian history", 50, 60);
//		System.out.println(historyStudent.displayHistoryStudent());
		System.out.println(scienceStudent.getPercentage());
		System.out.println(historyStudent.getPercentage());
	}
}
