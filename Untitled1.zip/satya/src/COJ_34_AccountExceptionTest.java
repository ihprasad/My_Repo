import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

import org.junit.Test;

public class COJ_34_AccountExceptionTest {

	// Test cases for AccountManager
	@Test
	public void testAccountManagerConstructorTest() {			// constructor 1
		Constructor[] cons = new AccountManager().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("AccountManager()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####CorrectConstructorTest | Passed | 3/3 | Passed Constructor Created for AccountManager#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/3 | Failed Default Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####AccountManagerTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void checkMethodsCreationTest() {

		try {
			boolean accountMethodCreated = false;
			boolean depositMethodCreated = false;
			boolean withdrawalMethodCreated = false;

			AccountManager amg = new AccountManager();
			Method[] arr = amg.getClass().getDeclaredMethods();
			for (Method method : arr) {
				if (method.getModifiers() == java.lang.reflect.Modifier.PUBLIC) {

					Parameter[] parameters = method.getParameters();
					if (method.getName().equals("checkAccount")
							&& parameters.length == 1
							&& parameters[0].getParameterizedType().toString()
									.equals("int")) {
						accountMethodCreated = true;
					} else if (parameters.length == 2
							&& parameters[0].getParameterizedType().toString()
									.equals("int")
							&& parameters[1].getParameterizedType().toString()
									.equals("double")
							&& method.getName().equals("deposit")) {
						depositMethodCreated = true;
					} else if (parameters.length == 2
							&& parameters[0].getParameterizedType().toString()
									.equals("int")
							&& parameters[1].getParameterizedType().toString()
									.equals("double")
							&& method.getName().equals("withdraw")) {
						withdrawalMethodCreated = true;

					}
				}
			}

			try {

				assertTrue(accountMethodCreated);
				System.out
						.println("####CheckAccountTest | Passed | 5/5 | Passed CheckAccount Method Created#####");
				try {
					assertTrue(depositMethodCreated);
					System.out
							.println("####CheckAccountTest | Passed | 5/5 | Passed Deposit Method Created#####");
					try {
						assertTrue(withdrawalMethodCreated);
						System.out
								.println("####CheckAccountTest | Passed | 5/5 | Passed Withdraw Method Created#####");
					} catch (AssertionError ae) {
						System.out
								.println("####CheckAccountTest | Failed | 0/5 | Failed Withdraw Method Not Created#####");

					}

				} catch (AssertionError ae) {
					System.out
							.println("####CheckAccountTest | Failed | 0/5 | Failed Deposit Method Not Created#####");

				}
			} catch (AssertionError ae) {
				System.out
						.println("####CheckAccountTest | Failed | 0/5 | Failed CheckAccount Method Not Created#####");

			}
		} catch (Exception aer) {
			System.out
					.println("#####AccountManagerTest | Failed | 0/5 | Failed Runtime Exception:"
							+ aer.getMessage() + "#####");

		}
	}

	@Test
	public void testCheckAccount() {
		try {
			AccountManager amg = new AccountManager();
			assertTrue(amg.checkAccount(111));
			assertTrue(amg.checkAccount(222));
			assertTrue(amg.checkAccount(333));
			assertTrue(amg.checkAccount(444));
			System.out
					.println("####CheckAccountTest | Passed | 6/6 | Passed for Existing Account Numbers Check#####");
		} catch (AssertionError ae) {
			System.out
					.println("####CheckAccountTest | Failed | 0/6 | Failed for Existing Account Numbers Check#####");

		} catch (Exception e) {
			System.out
					.println("#####CheckAccountTest | Failed | 0/6 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");

		}
	}

	@Test
	public void testDipositTest() {
		try {
			AccountManager amg = new AccountManager();
			assertEquals(8000, amg.deposit(111, 3000), 0.001);
			assertEquals(4200, amg.deposit(555, 1000), 0.001);
			System.out
					.println("####CheckAccountDipositTest | Passed | 7/7 | Passed for ValidDiposit Check#####");
			try {
				amg.deposit(222, -3499);
				System.out
						.println("####CheckAccountDipositTest | Failed | 0/7 | Failed for Negative Amount Check#####");
			} catch (COJ_34_NegativeAmountException nae) {
				System.out
						.println("####CheckAccountDipositTest | Passsed | 7/7 | Passed for Negative Amount Check#####");
			}
			try {
				amg.deposit(2222, 9000);
				System.out
						.println("####CheckAccountDipositTest | Failed | 0/7 | Failed for Diposit in Unavailable Account#####");
			} catch (COJ_34_InvalidAccountException iae) {
				System.out
						.println("####CheckAccountDipositTest | Passsed | 7/7 | Passed for Diposit in Unavailable Account#####");
			}

		} catch (AssertionError ae) {
			System.out
					.println("####CheckAccountDipositTest | Failed | 0/7 | Failed for ValidDiposit Check#####");
		} catch (Exception e) {
			System.out
					.println("#####CheckAccountTest | Failed | 0/7 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");

		}
	}

	@Test
	public void testWithDrawTest() {
		try {
			AccountManager amg = new AccountManager();
			assertEquals(20000, amg.withdraw(222, 5000), 0.001);
			assertEquals(9000, amg.withdraw(888, 900), 0.001);
			System.out
					.println("####CheckAccountWidrawTest | Passed | 7/7 | Passed for ValidWithdraw Check#####");
			try {
				amg.withdraw(222, -3499);
				System.out
						.println("####CheckAccountWithdrawTest | Failed | 0/7 | Failed for Negative Amount withdraw Check#####");
			} catch (COJ_34_NegativeAmountException nae) {
				System.out
						.println("####CheckAccountDipositTest | Passsed | 7/7 | Passed for Negative Amount withdraw Check#####");
			}
			try {
				amg.withdraw(2222, 9000);
				System.out
						.println("####CheckAccountWithdrawTest | Failed | 0/7 | Failed for Withdraw in Unavailable Account#####");
			} catch (COJ_34_InvalidAccountException iae) {
				System.out
						.println("####CheckAccountWithdrawTest | Passsed | 7/7 | Passed for Withdraw in Unavailable Account#####");
			}
			try {
				amg.withdraw(222, 50000);
				System.out
						.println("####CheckAccountWithdrawTest | Failed | 0/7 | Failed for Withdraw from InSufficientBalance#####");

			}

			catch (COJ_34_InsufficientFundsException ae) {
				System.out
						.println("####CheckAccountDipositTest | Passed | 7/7 | Passed for withdraw From InsufficientBalance#####");
			}
		} catch (Exception e) {
			System.out
					.println("#####CheckAccountTest | Failed | 0/7 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");

		}
	}

	// Test cases for COJ_34_InsufficientFundsException

	@Test
	public void testCOJ_34_InsufficientFundsExceptionInherited() {
		try {
			assertTrue(new COJ_34_InsufficientFundsException().getClass()
					.getSuperclass().getName().equals("java.lang.Exception"));
			System.out
					.println("#####InheritanceTest | Passed | 3/3 | Passed COJ_34_InsufficientFundsException class inherited from Exception#####");
		} catch (AssertionError ar) {
			System.out
					.println("#####InheritanceTest | Failed | 0/3 | Failed COJ_34_InsufficientFundsException  NOT inherited from Exception#####");

		}
	}

	@Test
	public void testCOJ_34_InsufficientFundsExceptionParameterConstructor() {
		Constructor[] cons = new COJ_34_InsufficientFundsException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_34_InsufficientFundsException(java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####ParameterizedConstructorTest | Passed | 3/3 | Passed Parameterized Constructor Created#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/3 | Failed Parameterized Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####COJ_34_InsufficientFundsExceptionTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCOJ_34_InsufficientFundsException() {
		Constructor[] cons = new COJ_34_InsufficientFundsException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_34_InsufficientFundsException()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####CorrectConstructorTest | Passed | 3/3 | Passed Constructor Created#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/3 | Failed Default Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####COJ_34_InsufficientFundsExceptionTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// Test cases for COJ_34_InvalidAccountException

	@Test
	public void testCOJ_34_InvalidAccountExceptionInherited() {
		try {
			assertTrue(new COJ_34_InvalidAccountException().getClass().getSuperclass()
					.getName().equals("java.lang.Exception"));
			System.out
					.println("#####InheritanceTest | Passed | 3/3 | Passed COJ_34_InvalidAccountException class inherited from Exception#####");
		} catch (AssertionError ar) {
			System.out
					.println("#####InheritanceTest | Failed | 0/3 | Failed COJ_34_InvalidAccountException  NOT inherited from Exception#####");

		}
	}

	@Test
	public void testCOJ_34_InvalidAccountExceptionParameterConstructor() {
		Constructor[] cons = new COJ_34_InvalidAccountException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_34_InvalidAccountException(java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####ParameterizedConstructorTest | Passed | 3/3 | Passed Parameterized Constructor Created#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/3 | Failed Parameterized Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####COJ_34_InvalidAccountExceptionTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCOJ_34_InvalidAccountException() {
		Constructor[] cons = new COJ_34_InvalidAccountException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_34_InvalidAccountException()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####CorrectConstructorTest | Passed | 3/3 | Passed Constructor Created#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/3 | Failed Default Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####COJ_34_InvalidAccountExceptionTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// Test cases for COJ_34_NegativeAmountException
	@Test
	public void testCOJ_34_NegativeAmountExceptionInherited() {
		try {
			assertTrue(new COJ_34_NegativeAmountException().getClass().getSuperclass()
					.getName().equals("java.lang.Exception"));
			System.out
					.println("#####InheritanceTest | Passed | 3/3 | Passed COJ_34_NegativeAmountException class inherited from Exception#####");
		} catch (AssertionError ar) {
			System.out
					.println("#####InheritanceTest | Failed | 0/3 | Failed COJ_34_NegativeAmountException  NOT inherited from Exception#####");

		}
	}

	@Test
	public void testCOJ_34_NegativeAmountExceptionParameterConstructor() {
		Constructor[] cons = new COJ_34_NegativeAmountException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_34_NegativeAmountException(java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####ParameterizedConstructorTest | Passed | 3/3 | Passed Parameterized Constructor Created#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/3 | Failed Parameterized Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####COJ_34_NegativeAmountExceptionTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCOJ_34_NegativeAmountException() {
		Constructor[] cons = new COJ_34_NegativeAmountException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_34_NegativeAmountException()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out.println("#####COJ_34_NegativeAmountExceptionConstructorTest | Passed | 3/3 | Passed Constructor Created#####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/3 | Failed Default Constructors Not Defined#####");

		} catch (Exception e) {
			System.out
					.println("#####COJ_34_NegativeAmountExceptionTest | Failed | 0/3 | Failed Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}