import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class COJ_17_CustomerTest {

	@Test
	public void silverCardTest() {
		try {
			COJ_17_Customer cOJ_17_Customer=new COJ_17_Customer("Ramana",300);
			COJ_17_CardType ct=COJ_17_CardsOnOffer.getOfferedCard(cOJ_17_Customer);
			assertTrue(ct.toString().equalsIgnoreCase("The Customer 'Ramana' Is Eligible For 'Silver' Card"));
			System.out
					.println("#####SilverCardTest | Passed | 9 / 9 | Passed for SilverCardTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####SilverCardTest | Failed | 0 / 9 | Failed for SilverCardTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SilverCardTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####SilverCardTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void platinumCardTest() {
		try {
			COJ_17_Customer cOJ_17_Customer=new COJ_17_Customer("pinky",20000);
			COJ_17_CardType ct=COJ_17_CardsOnOffer.getOfferedCard(cOJ_17_Customer);
			assertTrue(ct.toString().equalsIgnoreCase("The Customer 'pinky' Is Eligible For 'platinum' Card"));
			System.out
					.println("#####PlatinumCardTest | Passed | 9 / 9 | Passed for PlatinumCardTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####PlatinumCardTest | Failed | 0 / 9 | Failed for PlatinumCardTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####PlatinumCardTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####PlatinumCardTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void goldCardTest() {
		try {
			COJ_17_Customer cOJ_17_Customer=new COJ_17_Customer("Geetha",1000);
			COJ_17_CardType ct=COJ_17_CardsOnOffer.getOfferedCard(cOJ_17_Customer);
			assertTrue(ct.toString().equalsIgnoreCase("The Customer 'Geetha' Is Eligible For 'GOLD' Card"));
			System.out
					.println("#####GoldCardTest | Passed | 9 / 9 | Passed for GoldCardTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####GoldCardTest | Failed | 0 / 9 | Failed for GoldCardTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####GoldCardTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####GoldCardTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	
	@Test
	public void emiCardTest() {
		try {
			COJ_17_Customer cOJ_17_Customer=new COJ_17_Customer("Rahul",40);
			COJ_17_CardType ct=COJ_17_CardsOnOffer.getOfferedCard(cOJ_17_Customer);
			assertTrue(ct.toString().equalsIgnoreCase("The Customer 'Rahul' Is Eligible For 'EMI' Card"));
			System.out
					.println("#####EmiCardTest | Passed | 9 / 9 | Passed for EmiCardTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####EmiCardTest | Failed | 0 / 9 | Failed for EmiCardTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####EmiCardTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####EmiCardTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void cardsOnOfferRequiredMethodsTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_17_CardsOnOffer").getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());
			
			
			assertTrue(methodsSet.contains("public static COJ_17_CardType COJ_17_CardsOnOffer.getOfferedCard(COJ_17_Customer)")||methodsSet.contains("static public COJ_17_CardType COJ_17_CardsOnOffer.getOfferedCard(COJ_17_Customer)"));
			System.out
					.println("#####CardsOnOfferRequiredMethodsTest | Passed | 10 / 10 | Passed for CardsOnOfferRequiredMethodsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CardsOnOfferRequiredMethodsTest | Failed | 0 / 10 | Failed for CardsOnOfferRequiredMethodsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CardsOnOfferRequiredMethodsTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CardsOnOfferRequiredMethodsTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}


	@Test
	public void cardTypeClassRequiredMethodsTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_17_CardType").getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());
			
			
			assertTrue(methodsSet.contains("public java.lang.String COJ_17_CardType.toString()"));
			System.out
					.println("#####CardTypeClassRequiredMethodsTest | Passed | 9 / 9 | Passed for CardTypeClassRequiredMethodsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CardTypeClassRequiredMethodsTest | Failed | 0 / 9 | Failed for CardTypeClassRequiredMethodsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CardTypeClassRequiredMethodsTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CardTypeClassRequiredMethodsTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	
	@Test
	public void customerClassRequiredMethodsTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_17_Customer").getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());
			
			
			assertTrue(methodsSet.contains("public int COJ_17_Customer.getCreditPoints()")
					&& (methodsSet.contains("public java.lang.String COJ_17_Customer.toString()")));
			System.out
					.println("#####CustomerClassRequiredMethodsTest | Passed | 9 / 9 | Passed for CustomerClassRequiredMethodsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CustomerClassRequiredMethodsTest | Failed | 0 / 9 | Failed for CustomerClassRequiredMethodsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CustomerClassRequiredMethodsTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CustomerClassRequiredMethodsTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	
	@Test
	public void cardTypeConstructorTest() {
		try {
			Constructor s[] = Class.forName("COJ_17_CardType")
					.getDeclaredConstructors();
			Set<String> cons = new TreeSet<String>();
			for (int i = 0; i < s.length; i++) {
				cons.add(s[i].toString());
			}
			assertTrue(cons
					.contains("public COJ_17_CardType(COJ_17_Customer,java.lang.String)"));
			System.out
					.println("#####CardTypeConstructorTest | Passed | 9 / 9 | Passed for CardTypeConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CardTypeConstructorTest | Failed | 0 / 9 | Failed for CardTypeConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CardTypeConstructorTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CardTypeConstructorTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	
	@Test
	public void customerConstructorTest() {
		try {
			Constructor s[] = Class.forName("COJ_17_Customer")
					.getDeclaredConstructors();
			Set<String> cons = new TreeSet<String>();
			for (int i = 0; i < s.length; i++) {
				cons.add(s[i].toString());
			}
			assertTrue(cons
					.contains("public COJ_17_Customer(java.lang.String,int)"));
			System.out
					.println("#####CustomerConstructorTest | Passed | 9 / 9 | Passed for CustomerConstructorTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CustomerConstructorTest | Failed | 0 / 9 | Failed for CustomerConstructorTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CustomerConstructorTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CustomerConstructorTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void customerRequiredFields() {
		try {
			Set<String> fieldsSet = new TreeSet<String>();
			Field fields[] = Class.forName("COJ_17_Customer").getDeclaredFields();
			for (Field field : fields)
				fieldsSet.add(field.toString());
			assertTrue(fieldsSet
					.contains("private java.lang.String COJ_17_Customer.customerName")
					&& fieldsSet.contains("private int COJ_17_Customer.creditPoints"));
			System.out
					.println("#####customerRequiredFields | Passed | 9 / 9 | Passed for customerRequiredFields#####");

		} catch (AssertionError e) {
			System.out
					.println("#####customerRequiredFields | Failed | 0 / 9 | Failed for customerRequiredFields#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####customerRequiredFields | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####customerRequiredFields | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void cardTypeRequiredFields() {
		try {
			Set<String> fieldsSet = new TreeSet<String>();
			Field fields[] = Class.forName("COJ_17_CardType").getDeclaredFields();
			for (Field field : fields)
				fieldsSet.add(field.toString());
			assertTrue(fieldsSet.contains("private COJ_17_Customer COJ_17_CardType.customer")
					&& fieldsSet
							.contains("private java.lang.String COJ_17_CardType.cardType"));
			System.out
					.println("#####cardTypeRequiredFields | Passed | 9 / 9 | Passed for cardTypeRequiredFields#####");

		} catch (AssertionError e) {
			System.out
					.println("#####cardTypeRequiredFields | Failed | 0 / 9 | Failed for cardTypeRequiredFields#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####cardTypeRequiredFields | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####cardTypeRequiredFields | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
