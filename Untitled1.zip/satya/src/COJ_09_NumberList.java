import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;
/*
 * Multiple markers at this line
	- Test getNumberList() with missing numbers in between as input. - Success
	- Test getNumberList() with number sequence containing dashes and repeated numbers in input. - 
	 Success
	- Test getNumberList() with number sequence containing dashes in input. - Success
	- Test getNumberList() with continious numbers as input ( no missing or repeats in between). - 
	 Success
 */
public class COJ_09_NumberList {

	
	public String getNumberList(String input) {
		 Set<Integer> iset=new TreeSet<Integer>();
	        String data=input;
	        StringTokenizer stk=new StringTokenizer(data,",");
	       
	        while(stk.hasMoreTokens())
	        {
	            String x=stk.nextToken();
	            if(x.contains("-"))
	            {
	                StringTokenizer sss=new StringTokenizer(x,"-");
	                int a=Integer.parseInt(sss.nextToken());
	                int b=Integer.parseInt(sss.nextToken());
	                while(a<=b)
	                {
	                    iset.add(a);
	                    a++;
	                }
	            }
	            else
	            {
	                int a=Integer.parseInt(x);
	                iset.add(a);
	            }
	        }
	        String fdata=iset.toString();
	        String newdata=fdata.substring(1,fdata.length()-1);
	        newdata=newdata.replace(" ","");
	        return newdata;
	}
	
	public static void main(String[] args) {
		COJ_09_NumberList nlist=new COJ_09_NumberList();
		System.out.println(nlist.getNumberList("1,2,3,10-20"));
	}

}