import java.util.ArrayList;
import java.util.List;

//Define a class COJ_34_InsufficientFundsException
class COJ_34_InsufficientFundsException extends Exception {

	public COJ_34_InsufficientFundsException(String msg) {
		super(msg);
	}
	public COJ_34_InsufficientFundsException(){}
}


//Define a class COJ_34_InvalidAccountException
class COJ_34_InvalidAccountException extends Exception {
	public COJ_34_InvalidAccountException() {

	}

	public COJ_34_InvalidAccountException(String msg) {
		super(msg);
	}

}

// Define a class COJ_34_NegativeAmountException

class COJ_34_NegativeAmountException extends Exception {
	public COJ_34_NegativeAmountException() {

	}

	public COJ_34_NegativeAmountException(String msg) {
		super(msg);
	}

}


//Define a class COJ_34_AccountManager
class AccountManager {

	public AccountManager() {
	}
	public boolean checkAccount(int accountNo) {
		AccountList acl = new AccountList();
		for (COJ_34_AccountException act : acl.getListOfAccounts())
			if (act.getAccountNumber() == accountNo)
				return true;
		return false;

	}
	public double deposit(int accountNo, double amount) throws COJ_34_NegativeAmountException, COJ_34_InvalidAccountException {
		double bal=0;
		if (amount < 0) {
			throw new COJ_34_NegativeAmountException();
		}
		if (checkAccount(accountNo)) {
			AccountList acl = new AccountList();
			for (COJ_34_AccountException act : acl.getListOfAccounts()) {
				if (act.getAccountNumber() == accountNo) {
					bal = act.getBalance() + amount;
				}
			}
		} else {
			throw new COJ_34_InvalidAccountException();
		}
		return bal;
	}
	public double withdraw(int accountNo, double amount) throws COJ_34_NegativeAmountException, COJ_34_InsufficientFundsException, COJ_34_InvalidAccountException {
		double bal=0;
		if (amount < 0) {
			throw new COJ_34_NegativeAmountException();
		}
		if (checkAccount(accountNo)) {
			AccountList acl = new AccountList();
			for (COJ_34_AccountException act : acl.getListOfAccounts()) {
				if (act.getAccountNumber() == accountNo) {
					bal = act.getBalance() - amount;
					if(bal<0)
						throw new COJ_34_InsufficientFundsException();
				}
			}
		} else {
			throw new COJ_34_InvalidAccountException();
		}
		return bal;
	}

}




// Don't change the content COJ_34_Account class
public class COJ_34_AccountException {

	private int accountNumber;
	private double balance;

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public COJ_34_AccountException() {
	}

	public COJ_34_AccountException(int accountNumber, double balance) {
		this.accountNumber = accountNumber;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", balance="
				+ balance + "]";
	}

}


// Don't change the content COJ_34_AccountList class
class AccountList {

	// DONOT DELETE THIS
	private List<COJ_34_AccountException> listOfAccounts;

	public List<COJ_34_AccountException> getListOfAccounts() {
		return listOfAccounts;
	}

	public void setListOfAccounts(List<COJ_34_AccountException> listOfAccounts) {
		this.listOfAccounts = listOfAccounts;
	}

	public AccountList() {
		this.listOfAccounts = new ArrayList<COJ_34_AccountException>();
		this.listOfAccounts.add(new COJ_34_AccountException(111, 5000.0));
		this.listOfAccounts.add(new COJ_34_AccountException(222, 25000.0));
		this.listOfAccounts.add(new COJ_34_AccountException(333, 8648.50));
		this.listOfAccounts.add(new COJ_34_AccountException(444, 9861.54));
		this.listOfAccounts.add(new COJ_34_AccountException(555, 3200.00));
		this.listOfAccounts.add(new COJ_34_AccountException(666, 8978.90));
		this.listOfAccounts.add(new COJ_34_AccountException(777, 6656.67));
		this.listOfAccounts.add(new COJ_34_AccountException(888, 9900.00));
	}

}
