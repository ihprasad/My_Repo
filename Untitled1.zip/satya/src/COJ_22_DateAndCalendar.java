import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class COJ_22_DateAndCalendar {
	
	
	
	public static Date changeDate(int day, int month, int year){
		GregorianCalendar gc=new GregorianCalendar();
		gc.add(Calendar.YEAR, year);
		gc.add(Calendar.MONTH, month);
		gc.add(Calendar.DATE, day);
		return gc.getTime();
	}
	public static void main(String[] args) {
		System.out.println(changeDate(1, 1, 1));
	}
}
