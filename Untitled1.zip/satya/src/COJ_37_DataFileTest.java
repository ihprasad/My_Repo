import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.io.File;
import java.io.RandomAccessFile;

import org.junit.Test;


public class COJ_37_DataFileTest {

	String path="/usercode";
	@Test
	public void testDataFile() {

		try {

			RandomAccessFile raf = new RandomAccessFile("/usercode/COJ_37.txt","r");
			String data = COJ_37_DataFile.getString(raf);
			raf.close();
			assertEquals("KingQueen", data);
			System.out
					.println("#####testDataFile|Passed|50/50|Passed for getString method in testDataFile#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDataFile|Failed|0/50|Failed for getString " + ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDataFile | Failed | 0/50 | Method getString not found "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDataFile|Failed|0/50|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
	@Test
	public void testDataFileEmpty() {

		try {

			File file=new File(path+"/EmptyFile");
			file.createNewFile();
			RandomAccessFile raf = new RandomAccessFile(file, "r");
			String data = COJ_37_DataFile.getString(raf);
			raf.close();
			file.delete();
			assertEquals("Empty", data);
			System.out
					.println("#####testDataFileEmpty|Passed|50/50|Passed for getString method returning Empty from testDataFileEmpty#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDataFileEmpty|Failed|0/50|Failed for getString method returning Empty from testDataFileEmpty" + ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDataFileEmpty | Failed | 0/50 | Method getString not found "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDataFileEmpty|Failed|0/50|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

}
