import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.StringTokenizer;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_36_FileReverseTest {

	@Test
	public void testGetReverseFile() {

		try {

			RandomAccessFile raf = new RandomAccessFile("/usercode/COJ_36.txt", "r");
			String data = COJ_36_FileReverse.getReverseFile(raf);
			raf.close();
			raf = new RandomAccessFile(
					"/usercode/COJ_36_FileReverse.java",
					"r");
			String str = "";
			while ((str = raf.readLine()) != null) {
				assertFalse(str.contains("reverse()")
						&& str.indexOf("//") == -1);
			}
			raf.close();
			assertEquals("amag ateb ahpla", data);
			System.out
					.println("#####testGetReverseFile|Passed|100/100|Passed for testGetReverseFile method in COJ_36_FileReverse#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetReverseFile|Failed|0/100|Failed for testGetReverseFile used reverse method"
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetReverseFile | Failed | 0/100 | Method getReverseFile not found "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetReverseFile|Failed|0/100|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
}
