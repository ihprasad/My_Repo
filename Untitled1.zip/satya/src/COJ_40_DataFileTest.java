import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.List;

import org.junit.Test;

public class COJ_40_DataFileTest {

	String path = "/usercode/";

	@Test
	public void testDataFile() {

		try {

			RandomAccessFile raf = new RandomAccessFile("/usercode/COJ_40.txt",
					"r");
			List<COJ_40_Student> studentDetails = COJ_40_DataFile
					.readStudents(raf);
			raf.close();
			assertEquals(
					"[COJ_40_Student [name=Hari, id=111, marks=[56, 58, 68]], COJ_40_Student [name=Rajanikanth, id=222, marks=[65, 56, 57]], COJ_40_Student [name=Girija, id=333, marks=[69, 45, 89]]]",
					studentDetails.toString());
			System.out
					.println("#####testDataFile|Passed|25/25|Passed for readStudents method in testDataFile#####");
			int count = 0;
			for (COJ_40_Student student : studentDetails) {

				if (student.getTotalMarks() == 182)
					count++;
				if (student.getTotalMarks() == 178)
					count++;
				if (student.getTotalMarks() == 203)
					count++;

			}
			try {
				assertEquals(count, 3);
				System.out
						.println("#####testDataFile|Passed|25/25|Passed for getTotalMarks of Records Separtely method in testDataFile#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testDataFile|Failed|0/25|Failed for readStudents "
								+ ae.getMessage() + "#####");
			}

		} catch (AssertionError ae) {
			System.out
					.println("#####testDataFile|Failed|0/25|Failed for readStudents "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDataFile | Failed | 0/50 | Method readStudents not found "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDataFile|Failed|0/50|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testDataFileEmpty() {

		try {

			File file = new File(path + "/EmptyFile");
			file.createNewFile();
			RandomAccessFile raf = new RandomAccessFile(file, "r");
			List<COJ_40_Student> studentDetails = COJ_40_DataFile
					.readStudents(raf);
			raf.close();
			file.delete();
			assertNull(studentDetails);
			System.out
					.println("#####testDataFileEmpty|Passed|50/50|Passed for readStudents method returning null from testDataFileEmpty#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDataFileEmpty|Failed|0/50|Failed for readStudents method returning null from testDataFileEmpty"
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDataFileEmpty | Failed | 0/50 | Method readStudents not found "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDataFileEmpty|Failed|0/50|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

}
