import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.util.GregorianCalendar;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_23_DateCompareTest {
	
	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_23_DateCompare cls = new COJ_23_DateCompare();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - " + mm);
					if (mm.toString()
							.equals("public static int COJ_23_DateCompare.compareDate(java.util.Date,java.util.Date)"))
						me = true;
				}

				assertTrue("No such method found: public int compareDate(java.util.Date,java.util.Date)",me);
			} catch (AssertionError ae) {
				System.out
						.println("#####DateCompareTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DateCompareTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####DateCompareTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
	
	
	@Test
	public void testCompareDateSame() {
		try {
			COJ_23_DateCompare object = new COJ_23_DateCompare();
			GregorianCalendar one=new GregorianCalendar();
			one.set(2014,3,1);
			GregorianCalendar two=new GregorianCalendar();
			two.set(2014,3,1);
			assertEquals(0, COJ_23_DateCompare.compareDate(one.getTime(), two.getTime()));
		
			System.out
					.println("#####DateCompareTest | Passed | 25 / 25 | Passed for Same Dates####");
		} catch (AssertionError e) {
			System.out
			.println("#####DateCompareTest | Failed | 0 / 25 | Failed for Same Dates####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testCompareBeforDate() {
		try {
			COJ_23_DateCompare object = new COJ_23_DateCompare();
			GregorianCalendar one=new GregorianCalendar();
			one.set(2014,2,28);
			GregorianCalendar two=new GregorianCalendar();
			two.set(2014,3,1);
			assertEquals(1, COJ_23_DateCompare.compareDate(one.getTime(), two.getTime()));
		
			System.out
					.println("#####DateCompareTest | Passed | 25 / 25 | Passed for First Date less than second####");
		} catch (AssertionError e) {
			System.out
			.println("#####DateCompareTest | Failed | 0 / 25 | Failed for First Date less than second####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testCompareAfterDate() {
		try {
			COJ_23_DateCompare object = new COJ_23_DateCompare();
			GregorianCalendar one=new GregorianCalendar();
			one.set(2014,2,28);
			GregorianCalendar two=new GregorianCalendar();
			two.set(2012,3,1);
			assertEquals(2, COJ_23_DateCompare.compareDate(one.getTime(), two.getTime()));
		
			System.out
					.println("#####DateCompareTest | Passed | 25 / 25 | Passed for First Date greater than second####");
		} catch (AssertionError e) {
			System.out
			.println("#####DateCompareTest | Failed | 0 / 25 | Failed for First greater less than second####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testCompareNullDate() {
		try {
			COJ_23_DateCompare object = new COJ_23_DateCompare();
			GregorianCalendar one=new GregorianCalendar();
			one.set(2014,2,28);
			assertEquals(-1, COJ_23_DateCompare.compareDate(one.getTime(), null));
			assertEquals(-1, COJ_23_DateCompare.compareDate( null,one.getTime()));
			assertEquals(-1, COJ_23_DateCompare.compareDate(null, null));
			
				
			System.out
					.println("#####DateCompareTest | Passed | 25 / 25 | Passed for Null inputs####");
		} catch (AssertionError e) {
			System.out
			.println("#####DateCompareTest | Failed | 0 / 25 | Failed for Null inputs####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####DateCompareTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
