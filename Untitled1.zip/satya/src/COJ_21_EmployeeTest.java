import static org.junit.Assert.*;

import java.util.Comparator;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_21_EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void ComparatorImplTest() {
		try {
			EmpComparator object = new EmpComparator();
			assertTrue(object instanceof Comparator<?>);
			System.out
					.println("#####ComparatorImplTest | Passed | 20 / 20 | Passed for EmpComparator implementing Comparator Interface####");

		} catch (AssertionError e) {
			System.out
					.println("#####ComparatorImplTest | Failed | 0 / 20 | Failed in EmpComparator implementing Comparator Interface####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ComparatorImplTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ComparatorImplTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void addEmployeeOnlySalaryDiffersTest() {
		try {
			COJ_21_Employee one = new COJ_21_Employee(1, "aamir", 12000, 30);
			COJ_21_Employee two = new COJ_21_Employee(2, "salman", 11000, 30);
			COJ_21_Employee three = new COJ_21_Employee(3, "sharukh", 15000, 30);
			EmployeeSet emps = new EmployeeSet();
			emps.addEmployee(one);
			emps.addEmployee(two);
			emps.addEmployee(three);
			assertEquals(
					"[Employee [employeeId=2, employeeName=salman, salary=11000.0, age=30], Employee [employeeId=1, employeeName=aamir, salary=12000.0, age=30], Employee [employeeId=3, employeeName=sharukh, salary=15000.0, age=30]]",
					emps.getEmpTreeSet().toString());

			System.out
					.println("#####OnlySalaryDiffersTest | Passed | 20 / 20 | Passed for Different salaries Test####");

		} catch (AssertionError e) {
			System.out
					.println("#####OnlySalaryDiffersTest | Failed | 0 / 20 | Failed for Different salaries Test####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####NameDiffersTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####NameDiffersTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void addEmployeeSameData() {
		try {
			COJ_21_Employee one = new COJ_21_Employee(1, "aamir", 12000, 30);
			COJ_21_Employee two = new COJ_21_Employee(1, "aamir", 12000, 30);
			COJ_21_Employee three = new COJ_21_Employee(1, "aamir", 12000, 30);
			EmployeeSet emps = new EmployeeSet();
			emps.addEmployee(one);
			emps.addEmployee(two);
			emps.addEmployee(three);
			assertEquals(
					"[Employee [employeeId=1, employeeName=aamir, salary=12000.0, age=30]]",
					emps.getEmpTreeSet().toString());

			System.out
					.println("#####AllEmployeesSameTest | Passed | 20 / 20 | Passed for same data test####");

		} catch (AssertionError e) {
			System.out
					.println("#####AllEmployeesSameTest | Failed | 0 / 20 | Failed for same data test####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AllEmployeesSameTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####AllEmployeesSameTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void addEmployeeSameSalaryDifferentNamesTest() {
		try {
			COJ_21_Employee one = new COJ_21_Employee(1, "aamir", 13000, 30);
			COJ_21_Employee two = new COJ_21_Employee(2, "salman", 12000, 30);
			COJ_21_Employee three = new COJ_21_Employee(3, "sharukh", 12000, 30);
			EmployeeSet emps = new EmployeeSet();
			emps.addEmployee(one);
			emps.addEmployee(two);
			emps.addEmployee(three);
			assertEquals(
					"[Employee [employeeId=2, employeeName=salman, salary=12000.0, age=30], Employee [employeeId=3, employeeName=sharukh, salary=12000.0, age=30], Employee [employeeId=1, employeeName=aamir, salary=13000.0, age=30]]",
					emps.getEmpTreeSet().toString());

			System.out
					.println("#####SameSalaryDifferentNamesTest | Passed | 20 / 20 | Passed for SameSalary Different Names Test####");

		} catch (AssertionError e) {
			System.out
					.println("#####SameSalaryDifferentNamesTest | Failed | 0 / 20 | Failed for SameSalary Different Names Test####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SameSalaryDifferentNamesTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####SameSalaryDifferentNamesTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void addEmployeeSameSalaryAndNameDifferentAgeTest() {
		try {
			COJ_21_Employee one = new COJ_21_Employee(1, "gowri", 13000, 20);
			COJ_21_Employee two = new COJ_21_Employee(2, "gowri", 13000, 30);
			COJ_21_Employee three = new COJ_21_Employee(3, "piyush", 12000, 30);
			EmployeeSet emps = new EmployeeSet();
			emps.addEmployee(one);
			emps.addEmployee(two);
			emps.addEmployee(three);
			assertEquals(
					"[Employee [employeeId=3, employeeName=piyush, salary=12000.0, age=30], Employee [employeeId=2, employeeName=gowri, salary=13000.0, age=30], Employee [employeeId=1, employeeName=gowri, salary=13000.0, age=20]]",
					emps.getEmpTreeSet().toString());

			System.out
					.println("#####SameSalaryAndNameDifferentAgeTest | Passed | 20 / 20 | Passed for Same Salary Same Name But Different Age Test####");

		} catch (AssertionError e) {
			System.out
					.println("#####SameSalaryAndNameDifferentAgeTest | Failed | 0 / 20 | Failed Passed for Same Salary Same Name But Different Age Test####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SameSalaryAndNameDifferentAgeTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####SameSalaryAndNameDifferentAgeTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
}
