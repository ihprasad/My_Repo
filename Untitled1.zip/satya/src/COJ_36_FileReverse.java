import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;

public class COJ_36_FileReverse {
	public static String getReverseFile(RandomAccessFile raf)
			throws IOException {
		String str = "";
		long size = raf.length();
		for (long i = size - 1; i >= 0; i--) {
			raf.seek(i);
			str += (char) raf.read();
		 //reverse();
		}

		return str;
	}

	public static void main(String[] args) throws IOException {
		RandomAccessFile raf = new RandomAccessFile("f:/hi/hi.txt", "r");

		System.out.println(getReverseFile(raf));
	}
}
