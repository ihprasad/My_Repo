import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_04_MonthPrinterTest {

	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_04_MonthPrinter cls = new COJ_04_MonthPrinter();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - " + mm);
					if (mm.toString()
							.equals("public java.lang.String COJ_04_MonthPrinter.getMonthCalendar(int,int)"))
						me = true;
				}

				assertTrue("No such method found: getMonthCalendar(int,int)",me);
			} catch (AssertionError ae) {
				System.out
						.println("#####MonthPrinterTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####MonthPrinterTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
	
	@Test
	public void testGetMonthCalendar() {
		try {
			COJ_04_MonthPrinter obj = new COJ_04_MonthPrinter();
			assertEquals("1:Sunday:31:Tuesday",obj.getMonthCalendar(3, 1998));
			assertEquals("1:Sunday:31:Tuesday",obj.getMonthCalendar(12, 2002));
			assertEquals("1:Saturday:28:Friday",obj.getMonthCalendar(2, 2003));
			assertEquals("1:Sunday:29:Sunday",obj.getMonthCalendar(2, 2004));
			assertEquals("1:Sunday:30:Monday",obj.getMonthCalendar(4, 2012));
					
			System.out
					.println("####MonthPrinterTest | Passed | 40 / 40 | Passed past month year####");
		} catch (AssertionError e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 40 | Failed past month year####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 40 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 40 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testGetMonthCalendarLeap() {
		try {
			COJ_04_MonthPrinter obj = new COJ_04_MonthPrinter();
			assertEquals("1:Sunday:29:Sunday",obj.getMonthCalendar(2, 2004));
				
			System.out
					.println("####MonthPrinterTest | Passed | 30 / 30 | Passed LeapyearTest ####");
		} catch (AssertionError e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 30 | Failed Leapyear Test####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 30 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testGetMonthCalendarInvalid() {
		try {
			COJ_04_MonthPrinter obj = new COJ_04_MonthPrinter();
			GregorianCalendar gc=new GregorianCalendar();
			SimpleDateFormat sdf = new SimpleDateFormat("EEEE");

			String fday = sdf.format(gc.getTime());
			gc.set(Calendar.DATE, gc.getActualMaximum(5));
			String lday = sdf.format(gc.getTime());

			String s = "1:" + fday + ":" + gc.getActualMaximum(5) + ":" + lday;
			assertEquals(s,obj.getMonthCalendar(2, 204));
			assertEquals(s,obj.getMonthCalendar(-2, 204));
			assertEquals(s,obj.getMonthCalendar(-2, 0));
			assertEquals(s,obj.getMonthCalendar(0, 0));

			
			System.out
					.println("####MonthPrinterTest | Passed | 30 / 30 | Passed for invalid inputs ####");
		} catch (AssertionError e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 30 | Failed for invalid inputs####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 30 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####MonthPrinterTest | Failed | 0 / 30 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
