import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_09_NumberListTest {

	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_09_NumberList cls = new COJ_09_NumberList();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - "+mm);
					if (mm.toString()
							.equals("public java.lang.String COJ_09_NumberList.getNumberList(java.lang.String)"))
						me = true;
				}
				assertTrue("No such method found: getNumberList(java.lang.String)",me);

			} catch (AssertionError ae) {
				System.out
						.println("#####NumberListTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####NumberListTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####NumberListTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testGetNumberList() {
		try {
			COJ_09_NumberList object = new COJ_09_NumberList();
			assertEquals("1,2,3,4,8,9,10,11,12",
					object.getNumberList("4,8-12,1-4"));
			assertEquals("1,2,3,4", object.getNumberList("1-2,2-3,3-4"));

			System.out
					.println("#####testGetNumberList | Passed | 50 / 50 | Passed for repeated values ####");
		} catch (AssertionError e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 50 | Failed for repeated values####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 50 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 50 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetNumberListAllDashes() {
		try {
			COJ_09_NumberList object = new COJ_09_NumberList();
			assertEquals("1,20,21,22,24,27,30,31,32,33",
					object.getNumberList("20-22,24,27,30-33,1"));
			System.out
					.println("#####testGetNumberList | Passed | 25 / 25 | Passed for non-repeated values ####");
		} catch (AssertionError e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 25 | Failed for non-repeated values####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetNumberListWithoutDash() {
		try {
			COJ_09_NumberList object = new COJ_09_NumberList();
			assertEquals("1,2,3,4,5", object.getNumberList("1,2,3,4,5"));
			System.out
					.println("#####testGetNumberList | Passed | 25 / 25 | Passed for without hyphens input values ####");
		} catch (AssertionError e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 25 | Failed for for without hyphens input values####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetNumberList | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
