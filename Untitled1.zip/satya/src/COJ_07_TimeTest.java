import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class COJ_07_TimeTest {

	@Test
	public void addingTimeTest() {
		try {
			final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
			final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
			PrintStream pw = System.out;
			PrintStream pe = System.err;

			System.setOut(new PrintStream(outContent));
			System.setErr(new PrintStream(errContent));

			COJ_07_Time x = new COJ_07_Time(2, 3, 5);
			COJ_07_Time y = new COJ_07_Time(0, 0, 1);
			COJ_07_Time m = new COJ_07_Time(2, 59, 59);
			COJ_07_Time z = COJ_07_Time.add(x, y);
			z.show();
			String outputOne = outContent.toString();
			z = COJ_07_Time.add(y, m);
			z.show();
			String outputTwo = outContent.toString().substring(
					outputOne.length());
			z = COJ_07_Time.add(x, m);
			z.show();
			String outputThree = outContent.toString().substring(
					outputOne.length() + outputTwo.length());
			z = COJ_07_Time.add(m, m);
			z.show();
			String outputFour = outContent.toString().substring(
					outputOne.length() + outputTwo.length()
							+ outputThree.length());
			System.setOut(pw);
			System.setErr(pe);
			assertTrue(outputOne.equals("2:3:6") && outputTwo.equals("3:0:0")
					&& outputThree.equals("5:3:4")
					&& outputFour.equals("5:59:58"));
			System.out
					.println("#####addingTimeTest | Passed | 25 / 25 | Passed for addingTimeTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####addingTimeTest | Failed | 0 / 25 | Failed for addingTimeTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####addingTimeTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####addingTimeTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void timeClassRequiredMethodsTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_07_Time")
					.getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());

			assertTrue(methodsSet.contains("public void COJ_07_Time.show()")
					&& (methodsSet
							.contains("static public COJ_07_Time COJ_07_Time.add(COJ_07_Time,COJ_07_Time)") || methodsSet
							.contains("public static COJ_07_Time COJ_07_Time.add(COJ_07_Time,COJ_07_Time)")));
			System.out
					.println("#####timeClassRequiredMethodsTest | Passed | 25 / 25 | Passed for timeClassRequiredMethodsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####timeClassRequiredMethodsTest | Failed | 0 / 25 | Failed for timeClassRequiredMethodsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####timeClassRequiredMethodsTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####timeClassRequiredMethodsTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void timeRequiredConstructorsTest() {
		try {
			Constructor s[] = Class.forName("COJ_07_Time")
					.getDeclaredConstructors();
			Set<String> cons = new TreeSet<String>();
			for (int i = 0; i < s.length; i++) {
				cons.add(s[i].toString());
			}
			assertTrue(cons.contains("public COJ_07_Time()")
					&& cons.contains("public COJ_07_Time(int,int,int)"));
			System.out
					.println("#####timeRequiredConstructorsTest | Passed | 25 / 25 | Passed for timeRequiredConstructorsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####timeRequiredConstructorsTest | Failed | 0 / 25 | Failed for timeRequiredConstructorsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####timeRequiredConstructorsTest | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####timeRequiredConstructorsTest | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void timeClassExactRequiredFields() {
		try {
			Set<String> fieldsSet = new TreeSet<String>();
			Field fields[] = Class.forName("COJ_07_Time").getDeclaredFields();
			for (Field field : fields)
				fieldsSet.add(field.toString());
			assertTrue(fieldsSet
					.toString()
					.equals("[private int COJ_07_Time.hh, private int COJ_07_Time.mm, private int COJ_07_Time.ss]"));
			System.out
					.println("#####timeClassExactRequiredFields | Passed | 25 / 25 | Passed for timeClassExactRequiredFields#####");

		} catch (AssertionError e) {
			System.out
					.println("#####timeClassExactRequiredFields | Failed | 0 / 25 | Failed for timeClassExactRequiredFields#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####timeClassExactRequiredFields | Failed | 0 / 25 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####timeClassExactRequiredFields | Failed | 0 / 25 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
