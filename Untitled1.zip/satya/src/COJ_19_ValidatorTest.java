import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class COJ_19_ValidatorTest {

	@Test
	public void capitalLettersTest() {

		try {
			boolean test = COJ_19_Validator.validatePassword("alpha@12345");

			System.out
					.println("#####capitalLettersTest | Failed | 0 / 10 | Failed for required Capital letters rule#####");

		} catch (COJ_19_WrongPasswordException e) {
			System.out
					.println("#####capitalLettersTest | Passed | 10 / 10 | Passed for Capital letters rule#####");

		}

		catch (NoSuchMethodError e) {
			System.out
					.println("#####capitalLettersTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####capitalLettersTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void capitalVsSmallLettersTest() {

		try {
			boolean test = COJ_19_Validator.validatePassword("AAAabc@123");

			System.out
					.println("#####capitalVsSmallLettersTest | Failed | 0 / 10 | Failed for smallLetters and Capital letters rule#####");

		} catch (COJ_19_WrongPasswordException e) {
			System.out
					.println("#####capitalVsSmallLettersTest | Passed | 10 / 10 | Passed for smallLetters and Capital letters rule#####");

		}

		catch (NoSuchMethodError e) {
			System.out
					.println("#####capitalVsSmallLettersTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####capitalVsSmallLettersTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void spacesInPasswordTest() {

		try {
			boolean test = COJ_19_Validator.validatePassword("Aab343@  22pqrst");

			System.out
					.println("#####spacesInPasswordTest | Failed | 0 / 10 | Failed for spacesTest#####");

		} catch (COJ_19_WrongPasswordException e) {
			System.out
					.println("#####spacesInPasswordTest | Passed | 10 / 10 | Passed for spaces in passwordTest#####");

		}

		catch (NoSuchMethodError e) {
			System.out
					.println("#####spacesInPasswordTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####spacesInPasswordTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void symbolsInPasswordTest() {

		try {
			boolean test = COJ_19_Validator.validatePassword("Aab34322pqrst");

			System.out
					.println("#####symbolsInPasswordTest | Failed | 0 / 10 | Failed for atleast RequiredSymbols#####");

		} catch (COJ_19_WrongPasswordException e) {
			System.out
					.println("#####symbolsInPasswordTest | Passed | 10 / 10 | Passed for atleast required symbols#####");

		}

		catch (NoSuchMethodError e) {
			System.out
					.println("#####symbolsInPasswordTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####symbolsInPasswordTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void digitsInPasswordTest() {

		try {
			boolean test = COJ_19_Validator.validatePassword("Aab@pqrst");

			System.out
					.println("#####digitsInPasswordTest | Failed | 0 / 10 | Failed for atleast RequiredDigits#####");

		} catch (COJ_19_WrongPasswordException e) {
			System.out
					.println("#####digitsInPasswordTest | Passed | 10 / 10 | Passed for atleast required digits#####");

		}

		catch (NoSuchMethodError e) {
			System.out
					.println("#####digitsInPasswordTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####digitsInPasswordTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void wrongPasswordLengthTest() {
		try {
			boolean test = COJ_19_Validator.validatePassword("a");
			System.out
					.println("#####wrongPasswordTest | Failed | 0 / 10 | Failed on Total length check#####");
		} catch (COJ_19_WrongPasswordException e) {
			System.out
					.println("#####wrongPasswordTest | Passed | 10 / 10 | Passed on Total length check#####");

		} catch (NoSuchMethodError e) {
			System.out
					.println("#####validPasswordTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####validPasswordTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void validPasswordTest() {
		try {
			boolean test = COJ_19_Validator.validatePassword("aAbc@1023");
			assertTrue(true);
			System.out
					.println("#####validPasswordTest | Passed | 10 / 10 | Passed for Correct PasswordTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####validPasswordTest | Failed | 0 / 10 | Passed for Correct PasswordTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####validPasswordTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####validPasswordTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void WrongPasswordConstructorsTest() {
		try {
			Constructor[] s = Class.forName("WrongPasswordException")
					.getDeclaredConstructors();
			Set<String> cons = new TreeSet<String>();
			for (int i = 0; i < s.length; i++) {
				cons.add(s[i].toString());
			}
			assertTrue(cons.contains("public WrongPasswordException()")
					&& cons.size() >= 2);

			System.out
					.println("#####WrongPasswordConstructorsTest | Passed | 10 / 10 | Passed for inheritatedExceptionTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####WrongPasswordConstructorsTest | Failed | 0 / 10 | Failed against atleast 2 constructors including a DefaultConstructor#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####WrongPasswordConstructorsTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####WrongPasswordConstructorsTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void inheritatedExceptionTest() {
		try {
			String data = Class.forName("WrongPasswordException")
					.getSuperclass().getName();
			assertTrue(data.equals("java.lang.RuntimeException"));
			System.out
					.println("#####inheritatedExceptionTest | Passed | 10 / 10 | Passed for inheritatedExceptionTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####inheritatedExceptionTest | Failed | 0 / 10 | Failed for not inheriting as Required#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####inheritatedExceptionTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####inheritatedExceptionTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void validateMethodSignatureTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_19_Validator").getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());
			assertTrue(methodsSet
					.contains("public static boolean COJ_19_Validator.validatePassword(java.lang.String)")
					|| methodsSet
							.contains("static public boolean COJ_19_Validator.validatePassword(java.lang.String)"));
			System.out
					.println("#####validateMethodSignatureTest | Passed | 10 / 10 | Passed for validateMethodSignatureTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####validateMethodSignatureTest | Failed | 0 / 10 | Failed for validateMethodSignatureTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####validateMethodSignatureTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####validateMethodSignatureTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
