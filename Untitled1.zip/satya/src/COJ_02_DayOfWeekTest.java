import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_02_DayOfWeekTest {

	@BeforeClass
	public static void setBeforeClass() {
		Field[] fld = COJ_02_DayOfWeek.class.getDeclaredFields();
		boolean var = false;
		int count = 0;
		for (int i = 0; i < fld.length; i++) {

			if ("dayName".equals(fld[i].getName())) {
				var = true;
			}
		}
		try {
			assertTrue("Required structure didn't match ", var); // assert 1

		} catch (AssertionError ae) {
			System.out
					.println("#####DayOfWeekTest | Failed | 0/100 | Checking for Default structure: "
							+ ae.getMessage() + "#####");
		}
		try {
			COJ_02_DayOfWeek cls = new COJ_02_DayOfWeek();
			Class c = cls.getClass();
			Method lMethod;

			try {

				lMethod = c.getMethod("getNextDay");
				// System.out.println("method = " + lMethod.toString());
				assertEquals(
						"public java.lang.String COJ_02_DayOfWeek.getNextDay()",
						lMethod.toString());
			} catch (AssertionError ae) {
				System.out
						.println("#####DayOfWeekTest | Failed | 0/20 | Checking for Default structure: "
								+ ae.getMessage() + "#####");

			}
			try {
				lMethod = c.getMethod("getPreviousDay");
				// System.out.println("method = " + lMethod.toString());
				assertEquals(
						"public java.lang.String COJ_02_DayOfWeek.getPreviousDay()",
						lMethod.toString());

			} catch (AssertionError ae) {
				System.out
						.println("#####DayOfWeekTest | Failed | 0/20 | Checking for Default structure: "
								+ ae.getMessage() + "#####");

			}
			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - "+mm);
					if (mm.toString()
							.equals("public java.lang.String COJ_02_DayOfWeek.addToCurrentDay(int)"))
						me = true;
				}
				assertTrue(me);

			} catch (AssertionError ae) {
				System.out
						.println("#####DayOfWeekTest | Failed | 0/20 | Checking for Default structure: "
								+ ae.getMessage() + "#####");

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DayOfWeekTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####DayOfWeekTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testSetDayName() {
		try {
			COJ_02_DayOfWeek obj = new COJ_02_DayOfWeek();
			obj.setDayName("Sunday");
			assertEquals("SUN", obj.getDayName());
			obj.setDayName("Monday");
			assertEquals("MON", obj.getDayName());
			obj.setDayName("TUE");
			assertEquals("TUE", obj.getDayName());

			System.out
					.println("#####SetDayNameTest | Passed | 20/20 | Passed ValidDay####");
		} catch (AssertionError e) {
			System.out
					.println("#####SetDayNameTest | Failed | 0/20 | Failed for MixedCase ValidDay####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SetDayNameTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####SetDayNameTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetInvalidDayName() {
		try {
			COJ_02_DayOfWeek obj = new COJ_02_DayOfWeek();
			obj.setDayName("ABCD");
			assertNull(obj.getDayName());
			obj.setDayName("roney");
			assertNull(obj.getDayName());

			System.out
					.println("#####SetDayNameTest | Passed | 20/20 | Passed for InValidDay####");
		} catch (AssertionError e) {
			System.out
					.println("#####SetDayNameTest | Failed | 0/20 | Failed for Invalid Dayname####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####SetDayNameTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetNextDay() {
		try {
			COJ_02_DayOfWeek obj = new COJ_02_DayOfWeek();
			obj.setDayName("sat");
			assertEquals("Sun", obj.getNextDay());
			obj.setDayName("sun");
			assertEquals("Mon", obj.getNextDay());
			obj.setDayName("tue");
			assertEquals("Wed", obj.getNextDay());
			obj.setDayName("FRI");
			assertEquals("Sat", obj.getNextDay());

			System.out
					.println("#####NextDayTest | Passed | 20/20 | Passed  Valid Next Day####");
		} catch (AssertionError e) {
			System.out
					.println("#####NextDayTest | Failed | 0/20 | Failed for NextDay####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####NextDayTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####NextDayTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetPreviousDay() {
		try {
			COJ_02_DayOfWeek obj = new COJ_02_DayOfWeek();
			obj.setDayName("sat");
			assertEquals("Fri", obj.getPreviousDay());
			obj.setDayName("sun");
			assertEquals("Sat", obj.getPreviousDay());
			obj.setDayName("tue");
			assertEquals("Mon", obj.getPreviousDay());
			obj.setDayName("MON");
			assertEquals("Sun", obj.getPreviousDay());

			System.out
					.println("#####PreviousDayTest | Passed | 20/20 | Passed  Valid Previous Day####");
		} catch (AssertionError e) {
			System.out
					.println("#####PreviousDayTest | Failed | 0/20 | Failed for Previous Day####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####PreviousDayTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####PreviousDayTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testAddToCurrentDay() {
		try {
			COJ_02_DayOfWeek obj = new COJ_02_DayOfWeek();
			obj.setDayName("sat");
			assertEquals("Tue", obj.addToCurrentDay(3));
			assertEquals("Tue", obj.addToCurrentDay(52));
			assertEquals("Sat", obj.addToCurrentDay(0));
			assertEquals("Fri", obj.addToCurrentDay(-1));
			assertEquals("Mon", obj.addToCurrentDay(-5));
			assertEquals("Fri", obj.addToCurrentDay(-8));
			assertEquals("Sun", obj.addToCurrentDay(1));
			assertEquals("Mon", obj.addToCurrentDay(2));
			obj.setDayName("wed");
			assertEquals("Thu", obj.addToCurrentDay(1));
			assertEquals("Sun", obj.addToCurrentDay(4));

			assertEquals("Tue", obj.addToCurrentDay(6));
			assertEquals("Mon", obj.addToCurrentDay(-2));
			assertEquals("Sun", obj.addToCurrentDay(-3));
			assertEquals("Sat", obj.addToCurrentDay(-4));

			System.out
					.println("#####AddToCurrentDayTest | Passed | 20/20 | Passed  AddToCurrentDay ####");
		} catch (AssertionError e) {
			System.out
					.println("#####AddToCurrentDayTest | Failed | 0/20 | Failed AddToCurrentDay####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####AddToCurrentDayTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####AddToCurrentDayTest | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
