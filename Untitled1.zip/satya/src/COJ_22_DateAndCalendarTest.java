import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_22_DateAndCalendarTest {

	private static Date getNewDate(int date, int mon, int year) {
		GregorianCalendar gc = new GregorianCalendar();
		gc.add(Calendar.YEAR, year);
		gc.add(Calendar.MONTH, mon);
		gc.add(Calendar.DATE, date);
		return gc.getTime();
	}

	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_22_DateAndCalendar cls = new COJ_22_DateAndCalendar();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - " + mm);
					if (mm.toString()
							.equals("public static java.util.Date COJ_22_DateAndCalendar.changeDate(int,int,int)"))
						me = true;
				}

				assertTrue(
						"No such method found: public static java.util.Date changeDate(int,int,int)",
						me);
			} catch (AssertionError ae) {
				System.out
						.println("#####DateAndCalendarTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####DateAndCalendarTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####DateAndCalendarTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testChangeDateBefore() {
		try {
			COJ_22_DateAndCalendar obj = new COJ_22_DateAndCalendar();
			assertEquals(getNewDate(1, 1, 1), obj.changeDate(1, 1, 1));
			assertEquals(getNewDate(9, 10, 12), obj.changeDate(9, 10, 12));

			System.out
					.println("####ChangeDateTest | Passed | 40 / 40 | Passed for positive inputs####");
		} catch (AssertionError e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 40 | Failed for positive inputs####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 40 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 40 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testChangeDate() {
		try {
			COJ_22_DateAndCalendar obj = new COJ_22_DateAndCalendar();
			assertEquals(getNewDate(-1, -11, -1), obj.changeDate(-1, -11, -1));

			System.out
					.println("####ChangeDateTest | Passed | 40 / 40 | Passed for Negative inputs####");
		} catch (AssertionError e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 40 | Failed for Negative inputs####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 40 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 40 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testChangeDateZero() {
		try {
			COJ_22_DateAndCalendar obj = new COJ_22_DateAndCalendar();
			assertEquals(getNewDate(0, 0, 0), obj.changeDate(0, 0, 0));

			System.out
					.println("####ChangeDateTest | Passed | 20 / 20 | Passed for Zero inputs####");
		} catch (AssertionError e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 20 | Failed for Zero inputs####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####ChangeDateTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
}
