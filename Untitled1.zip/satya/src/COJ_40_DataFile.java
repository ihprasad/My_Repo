import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

class COJ_40_Student {
	private String name;
	private int id;
	private int[] marks = new int[3];

	public COJ_40_Student(String name, int id, int[] marks) {
		super();
		this.name = name;
		this.id = id;
		this.marks = marks;
	}

	public COJ_40_Student() {
	}

	@Override
	public String toString() {
		return "COJ_40_Student [name=" + name + ", id=" + id + ", marks="
				+ Arrays.toString(marks) + "]";
	}

	public float getTotalMarks() {
		float totalMarks = 0;
		for (int x : marks) {
			totalMarks += x;
		}
		return totalMarks;

	}
}

public class COJ_40_DataFile {
	public static List<COJ_40_Student> readStudents(RandomAccessFile rFile)
			throws IOException {

		String line = "";
		List<COJ_40_Student> studentsList = new ArrayList<COJ_40_Student>();
		if (rFile.length() == 0)
			return null;
		do {

			line = rFile.readLine();
			if (line == null)
				break;
			else {
				StringTokenizer stk = new StringTokenizer(line, ":");
				if (stk.countTokens() >= 5) {
					String one = stk.nextToken();
					String two = stk.nextToken();
					String three = stk.nextToken();
					String four = stk.nextToken();
					String five = stk.nextToken();

					int[] arr = { Integer.parseInt(three),
							Integer.parseInt(four), Integer.parseInt(five) };
					COJ_40_Student newStudent = new COJ_40_Student(two,
							Integer.parseInt(one), arr);
					studentsList.add(newStudent);
				}
			}
		} while (line != null);
		return studentsList;
	}

	public static void main(String[] args) {
		try {
			
			// Modify the path of the file in below statement. 
			RandomAccessFile raf = new RandomAccessFile(
					"Path of the file", "r");
			System.out.println(readStudents(raf));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error");
		}
	}
}
