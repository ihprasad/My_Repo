import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_01_CalculateAgeTest {

	private static final int getCy() {
		return new GregorianCalendar().get(Calendar.YEAR);
	}

	private static final int getCm() {
		return new GregorianCalendar().get(Calendar.MONTH) + 1;
	}

	private static final int getPrevMonth() {
		return (getCm() - 1) == 0 ? 12 : getCm() - 1;
	}

	private static final int getNextMonth() {
		return (getCm() + 1) == 13 ? 1 : getCm() + 1;
	}

	@BeforeClass
	public static void setBeforeClass() {
		try {
			COJ_01_CalculateAge cls = new COJ_01_CalculateAge();
			Class c = cls.getClass();
			Method lMethod;

			try {

				Method[] m = c.getDeclaredMethods();
				boolean me = false;
				for (Method mm : m) {
					// System.out.println("mm - " + mm);
					if (mm.toString()
							.equals("public static double COJ_01_CalculateAge.calculateAge(int,int)"))
						me = true;
				}

				assertTrue("No such method found: calculateAge(int,int)",me);
			} catch (AssertionError ae) {
				System.out
						.println("#####CalculateAgeTest | Failed | 0/100 | Checking for Default structure: "
								+ ae.getMessage() + "#####");
				System.exit(0);

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####CalculateAgeTest | Failed | 0/100 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testCalculateAgeNextMonth() {
		try {
			COJ_01_CalculateAge object = new COJ_01_CalculateAge();
			// System.out.println(getNextMonth()+" "+getCy());
			assertEquals(-2.0, object.calculateAge(getNextMonth(), getCy()),
					0.01);
			System.out
					.println("#####CalculateAgeTest | Passed | 20 / 20 | Passed for Next Month ####");
		} catch (AssertionError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | Failed for Next Month####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCalculateAgePreviousMonth() {
		try {
			COJ_01_CalculateAge object = new COJ_01_CalculateAge();
			assertEquals(calAge(getPrevMonth(), getCy()),
					object.calculateAge(getPrevMonth(), getCy()), 0.1f);
			System.out
					.println("#####CalculateAgeTest | Passed | 20 / 20 | Passed for previus Month ####");
		} catch (AssertionError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | Failed for Previous Month####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCalculateAgeFutureDate() {
		try {
			COJ_01_CalculateAge object = new COJ_01_CalculateAge();
			assertEquals(-2.0, object.calculateAge(getCm(), getCy() + 1), 0.01);
			System.out
					.println("#####CalculateAgeTest | Passed | 20 / 20 | Passed for Future Date####");
		} catch (AssertionError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | Failed for Future Date####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCalculateAgeCurrentDate() {
		try {
			COJ_01_CalculateAge object = new COJ_01_CalculateAge();
			assertEquals(0.0, object.calculateAge(getCm(), getCy()), 0.1f);
			System.out
					.println("#####CalculateAgeTest | Passed | 20 / 20 | Passed for Current Date####");
		} catch (AssertionError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | Failed for Current Date####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCalculateAge() {
		try {
			COJ_01_CalculateAge object = new COJ_01_CalculateAge();
			assertEquals(calAge(3, 1992), object.calculateAge(3, 1992), 0.1);
			assertEquals(calAge(2, 1991), object.calculateAge(2, 1991), 0.1);
			assertEquals(calAge(1, 1990), object.calculateAge(1, 1990), 0.1);

			System.out
					.println("#####CalculateAgeTest | Passed | 20 / 20 | Passed for Past Dates####");
		} catch (AssertionError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | Failed for Past Dates####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####CalculateAgeTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	private static float calAge(int birthMonth, int birthYear) {
		GregorianCalendar gc = new GregorianCalendar();
		int cy = gc.get(Calendar.YEAR);
		int cm = gc.get(Calendar.MONTH) + 1;
		int nom = 0;
		if (cm >= birthMonth)
			nom = cm - birthMonth;
		else {
			nom = (cm + 12) - birthMonth;
			cy--;
		}
		int year = cy - birthYear;
		return Float.parseFloat(String
				.format("%.2f", year + ((float) nom / 12)));
	}
}
