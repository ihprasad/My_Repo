import java.util.Calendar;
import java.util.GregorianCalendar;

public class COJ_01_CalculateAge {

	public static double calculateAge(int birthMonth, int birthYear) {
	
		if(birthMonth<=0 || birthYear<=0)
		{
			return -1.0;
		}
		GregorianCalendar gc = new GregorianCalendar();
		int cy=gc.get(Calendar.YEAR);
		int cm=gc.get(Calendar.MONTH)+1;
		
		if((birthYear>cy) ||(birthYear==cy && birthMonth>cm)) 
			return -2.0;
		
		int nom=0;
		if(cm>=birthMonth)
			nom=cm-birthMonth;
		else
		{	
			nom=(cm+12)-birthMonth;
			cy--;
		}
		int year=cy-birthYear;
		return Double.parseDouble(String.format("%.2f",year+((double)nom/12)));
	}

	public static void main(String[] args) {
		System.out.println(calculateAge(5,1999));
		//System.out.println(new GregorianCalendar().get(Calendar.MONTH));
	}
}
