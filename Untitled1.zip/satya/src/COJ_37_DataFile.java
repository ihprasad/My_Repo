import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.StringTokenizer;

public class COJ_37_DataFile {
	public static String getString(RandomAccessFile rFile) throws IOException {
		String output = "";
		String line = "";
	
		if (rFile.length() == 0)
			return "Empty";
		do {

			line = rFile.readLine();
			if (line == null)
				break;
			else {
				StringTokenizer stk = new StringTokenizer(line, ":");
				if (stk.countTokens() >= 3) {
					String one = stk.nextToken();
					String two = stk.nextToken();
					String three = stk.nextToken();
					output += three;
				}
			}
		} while (line != null);
		return output;
	}

	public static void main(String[] args) {
		try {
			RandomAccessFile raf = new RandomAccessFile(
					"E:/TalentsprintTeamwork/RightCode/src/COJ_37.txt", "r");
			System.out.println(getString(raf));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error");
		}

	}
}
