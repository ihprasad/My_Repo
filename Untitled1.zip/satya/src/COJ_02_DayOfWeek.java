public class COJ_02_DayOfWeek {
	private String[] arr = { "Sun", "Mon", "Tue", "Wed",
			"Thu", "Fri", "Sat" };
	
	private String dayName = null;
	


	private int getIndex() {
		int i = 0;
		for (; i < arr.length; i++) {
			if (arr[i].substring(0, 3).equalsIgnoreCase(dayName)) {
				return i;
			}
		}
		return i;
	}

	public String getDayName() {
		return dayName;
	}

	public void setDayName(String dayName) {
		if (dayName.equalsIgnoreCase("SUN")
				|| dayName.equalsIgnoreCase("Sunday")) {
			this.dayName = "SUN";
		} else if (dayName.equalsIgnoreCase("MON")
				|| dayName.equalsIgnoreCase("Monday")) {
			this.dayName = "MON";
		} else if (dayName.equalsIgnoreCase("TUE")
				|| dayName.equalsIgnoreCase("Tuesday")) {
			this.dayName = "TUE";
		} else if (dayName.equalsIgnoreCase("WED")
				|| dayName.equalsIgnoreCase("Wednesday")) {
			this.dayName = "WED";
		} else if (dayName.equalsIgnoreCase("THU")
				|| dayName.equalsIgnoreCase("thursday")) {
			this.dayName = "THU";
		} else if (dayName.equalsIgnoreCase("FRI")
				|| dayName.equalsIgnoreCase("FRIDAY")) {
			this.dayName = "FRI";
		} else if (dayName.equalsIgnoreCase("SAT")
				|| dayName.equalsIgnoreCase("Saturday")) {
			this.dayName = "SAT";
		} else
			this.dayName = null;
	}
	public String getNextDay() {
		int newIndex = getIndex() + 1;
		if (newIndex == 7)
			return arr[0];
		else
			return arr[newIndex];

	}

	public String getPreviousDay() {
		int newIndex = getIndex() - 1;
		if (newIndex == -1)
			return arr[6];
		else
			return arr[newIndex];
		// throw new UnsupportedOperationException();
	}
	public String addToCurrentDay(int number) {
		int cIndex = getIndex();
		
		if (number < 0) {
			number = number % 7;
			number = Math.abs(number);
			cIndex = cIndex - number;
			if (cIndex < 0) {
				cIndex = 7 + cIndex;
			}
			return arr[cIndex];
		} else {
			cIndex = cIndex + number;
			if (cIndex > 6) {
				cIndex = cIndex % 7;
			}
			
			return arr[cIndex];
		}
	}
	public static void main(String[] args) {
		COJ_02_DayOfWeek dow = new COJ_02_DayOfWeek();
		dow.setDayName("Tuesday");
		System.out.println(dow.addToCurrentDay(6));
	}
}
