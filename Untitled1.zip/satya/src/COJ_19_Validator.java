public class COJ_19_Validator {
	public static boolean validatePassword(String password) {
		int capitalLetters = 0;
		int smallLetters = 0;
		int digits = 0;
		int symbols = 0;
		int spaces = 0;
		int total = 0;
		for (Character ch : password.toCharArray()) {
			if (Character.isUpperCase(ch))
				capitalLetters++;
			else if (Character.isLowerCase(ch))
				smallLetters++;
			else if (Character.isDigit(ch))
				digits++;
			else if (Character.isSpaceChar(ch))
				spaces++;
			else
				symbols++;
			total++;
		}
		if (total >= 8 && capitalLetters >= 1 && smallLetters >= 1
				&& digits >= 1 && smallLetters > capitalLetters && symbols >= 1
				&& spaces == 0)
			return true;
		else {
			throw new COJ_19_WrongPasswordException();
		}
	}
}

class COJ_19_WrongPasswordException extends RuntimeException {

	public COJ_19_WrongPasswordException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_19_WrongPasswordException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public COJ_19_WrongPasswordException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public COJ_19_WrongPasswordException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public COJ_19_WrongPasswordException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
