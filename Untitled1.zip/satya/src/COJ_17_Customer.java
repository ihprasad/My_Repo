public class COJ_17_Customer {
	
	private String customerName;
	private int creditPoints;
	
	public COJ_17_Customer(String customerName,int creditPoints) {
		this.customerName = customerName;
		this.creditPoints=creditPoints;
	}
	public int getCreditPoints()
	{
		return creditPoints;
	}

	@Override
	public String toString() {
		return customerName;
	}
}

class COJ_17_CardType {
	private COJ_17_Customer customer;
	private String cardType;

	public COJ_17_CardType(COJ_17_Customer customer, String cardType) {
		this.customer = customer;
		this.cardType = cardType;
	}
	@Override
	public String toString() {
		return "The Customer '" + customer.toString() + "' Is Eligible For '" + cardType + "' Card" ;

	}
}

class COJ_17_CardsOnOffer  {
	public static COJ_17_CardType getOfferedCard (COJ_17_Customer customer) {
		String type="";
		if (customer.getCreditPoints() >= 100 && customer.getCreditPoints() <= 500)
			type = "Silver";
		else if (customer.getCreditPoints() > 501 && customer.getCreditPoints()<=1000)
			type = "Gold";
		else if (customer.getCreditPoints() > 1000)
			type = "Platinum";
		else 
			type = "EMI";

		COJ_17_CardType result = new COJ_17_CardType(customer, type);
		return result;
	}
}

class Main {
	public static void main(String[] args) {
		COJ_17_Customer customer = new COJ_17_Customer("Satya",9099);
		COJ_17_CardType type = COJ_17_CardsOnOffer.getOfferedCard(customer);
		System.out.println(type);

	}
}