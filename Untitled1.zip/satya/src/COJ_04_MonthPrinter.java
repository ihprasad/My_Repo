import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class COJ_04_MonthPrinter {

	public String getMonthCalendar(int month, int year) {
		GregorianCalendar gc = new GregorianCalendar();
		if (month != 0 && year != 0 && year>=1000 &&  year<=9999 &&  month>0 && month<=12) {
			gc.set(Calendar.MONTH, month - 1);
			gc.set(Calendar.YEAR, year);
			gc.set(Calendar.DATE, 1);
		}
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
		String fday = sdf.format(gc.getTime());
		gc.set(Calendar.DATE, gc.getActualMaximum(5));
		String lday = sdf.format(gc.getTime());

		String s = "1:" + fday + ":" + gc.getActualMaximum(5) + ":" + lday;
		return s;
	}

	public static void main(String[] args) {
		System.out.println(new COJ_04_MonthPrinter().getMonthCalendar(0, 0));
		System.out.println(new COJ_04_MonthPrinter().getMonthCalendar(2, 2015));
		System.out.println(new COJ_04_MonthPrinter().getMonthCalendar(2, 215));
		System.out.println(new COJ_04_MonthPrinter().getMonthCalendar(2, -3));
	}

}
