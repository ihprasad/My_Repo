
// implement a class COJ_34_CountryNotValidException
class CountryNotValidException extends Exception {

	public CountryNotValidException() {
	}

	public CountryNotValidException(String msg) {
		super(msg);
	}

}


// implement a class COJ_34_NameNotValidException
class NameNotValidException extends Exception {
	public NameNotValidException() {
	}

	public NameNotValidException(String msg) {
		super(msg);
	}
}


// implement a class COJ_34_NotEligibleForTaxException
class NotEligibleForTaxException extends Exception{

	public NotEligibleForTaxException() {
	}
	public NotEligibleForTaxException(String msg)
	{
		super(msg);
	}

}



// implement a class COJ_34_TaxCalculator
class TaxCalculator {
	public TaxCalculator() {
	}

	public double calculateTax(COJ_35_Employee emp) throws CountryNotValidException, NameNotValidException, NotEligibleForTaxException {
		if (!emp.getNationality().equalsIgnoreCase("Indian")) {
			throw new CountryNotValidException(Messages.COUNTRYINVALID);
		}
		if (emp.getEmployeeName() == null ||emp.getEmployeeName().isEmpty()) {
			throw new NameNotValidException(Messages.NAMEINVALID);
		}
		double salary = emp.getSalary();
		if (salary >= 100000) {
			return salary * 0.08;
		} else if (salary >= 50000) {
			return salary * 0.06;
		} else if (salary >= 30000) {
			return salary * 0.05;
		} else if (salary >= 10000) {
			return salary * 0.04;
		} else {
			throw new NotEligibleForTaxException(Messages.TAXNOTELIGIBLE);
		}
	}

}

// implement a class COJ_34_TaxSimulator

class TaxSimulator {
	// DONOT DELETE THIS
	public TaxSimulator() {
	}

	public String findTaxOutput(COJ_35_Employee emp) {
		TaxCalculator tc = new TaxCalculator();
		double tax = 0;
		try {
			tax = tc.calculateTax(emp);
			return Messages.SUCCESS+" "+ (int)tax;
		} catch (CountryNotValidException cve) {
			return cve.getMessage();
		} catch (NameNotValidException nve) {
			return nve.getMessage();
		} catch (NotEligibleForTaxException nee) {
			return nee.getMessage();
		}
	}

}


// Read only file
// Don't edit the content of COJ_34_Employee
public class COJ_35_Employee {

	// DONOT CHANGE ITS CONTENTS
	
	private String employeeName;
	private String nationality;
	private double salary;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	public COJ_35_Employee() {
	}
	public COJ_35_Employee(String employeeName, String nationality, double salary) {
		this.employeeName = employeeName;
		this.nationality = nationality;
		this.salary = salary;
	}

}

// Read only file
// Don't edit the content of COJ_34_Messages
class Messages {

	public static final String COUNTRYINVALID = "The Employee must be a Indian Citizen for calculating tax";
	public static final String NAMEINVALID = "The Employee Name cannot be null or empty";
	public static final String TAXNOTELIGIBLE = "The Employee does not need to pay tax";
	public static final String SUCCESS = "Tax Calculated Successfully";

}
//Read only file
//Don't edit the content of COJ_34_ExceptionTester
class ExceptionTester {

	public static void main(String[] args) {
		//TEST YOUR CODE HERE
		COJ_35_Employee emp=new COJ_35_Employee("a","Indian",50000);
		TaxSimulator tsm=new TaxSimulator();
		System.out.println(tsm.findTaxOutput(emp));
	}

}