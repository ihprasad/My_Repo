public class COJ_07_Time {
	private int hh, mm, ss;

	public COJ_07_Time() {
		hh = mm = ss = 0;
	}

	public COJ_07_Time(int hh, int mm, int ss) {
		this.hh = hh;
		this.mm = mm;
		this.ss = ss;
	}
	public void show() {
		System.out.print(hh + ":" + mm + ":" + ss);
	}
	static public COJ_07_Time add(COJ_07_Time one, COJ_07_Time two) {
		COJ_07_Time ans = new COJ_07_Time();
		ans.ss = one.ss + two.ss;
		ans.mm = one.mm + two.mm;
		ans.hh = one.hh + two.hh;
		if (ans.ss >= 60) {
			ans.mm += ans.ss / 60;
			ans.ss %= 60;
		}
		if (ans.mm >= 60) {
			ans.hh += ans.mm / 60;
			ans.mm %= 60;
		}
		return ans;
	}
}
