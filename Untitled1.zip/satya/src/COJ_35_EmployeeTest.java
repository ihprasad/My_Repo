import static org.junit.Assert.*;

import java.lang.reflect.Constructor;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_35_EmployeeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	// Test cases for NameNotValidException
	@Test
	public void testNameValidException() {
		try {
			assertTrue(new NameNotValidException().getClass().getSuperclass()
					.getName().equals("java.lang.Exception"));
			System.out
					.println("#####InheritanceTest | Passed | 2/2 | NameNotValid Exception class inherited from Exception####");
		} catch (AssertionError ar) {
			System.out
					.println("#####InheritanceTest | Failed | 0/2 | NameNotValid Exception  NOT inherited from Exception####");

		}
	}

	@Test
	public void testNameNotValidExceptionParameterConstructor() {
		Constructor[] cons = new NameNotValidException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"NameNotValidException(java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####ParameterizedConstructorTest | Passed | 2/2 | Parameterized Constructor for NameNotValidException Created####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/2 | Parameterized Constructors for NameNotValidException Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####NameNotValideExceptionTest | Failed | 0/2 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNameNotValidException() {
		Constructor[] cons = new NameNotValidException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("NameNotValidException()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####CorrectConstructorTest | Passed | 2/2 | Constructor for NameNotValidException Created####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/2 | Default Constructors for NameNotValidException Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####NameNotValideExceptionTest | Failed | 0/2 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// Test cases for CountryNotValidException
	@Test
	public void testCountryNotValidExceptionInherited() {
		try {
			assertTrue(new CountryNotValidException().getClass()
					.getSuperclass().getName().equals("java.lang.Exception"));
			System.out
					.println("#####InheritanceTest | Passed | 2/2 | CountryNotValidException class inherited from Exception####");
		} catch (AssertionError ar) {
			System.out
					.println("#####InheritanceTest | Failed | 0/2 | CountryNotValidException  NOT inherited from Exception####");

		}
	}

	@Test
	public void testCountryNotValidExceptionParameterConstructor() {
		Constructor[] cons = new CountryNotValidException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"CountryNotValidException(java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####ParameterizedConstructorTest | Passed | 2/2 | Parameterized Constructor for CountryNotValidException Created####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/2 | Parameterized Constructors for CountryNotValidException Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####CountryNotValidExceptionTest | Failed | 0/2 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testCountryNotValidException() {
		Constructor[] cons = new CountryNotValidException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("CountryNotValidException()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####CorrectConstructorTest | Passed | 2/2 | Constructor for CountryNotValidException Created####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/2 | Default Constructors for CountryNotValidException Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####NotEligibleFor TaxExceptionTest | Failed | 0/2 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	// Test cases for NotEligibleForTaxException
	
	@Test
	public void testNotEligibleForTaxExceptionInherited() {
		try {
			assertTrue(new NotEligibleForTaxException().getClass().getSuperclass()
					.getName().equals("java.lang.Exception"));
			System.out
					.println("#####InheritanceTest | Passed | 2/2 | NotEligibleForTaxException class inherited from Exception####");
		} catch (AssertionError ar) {
			System.out
					.println("#####InheritanceTest | Failed | 0/2 | NotEligibleForTaxException  NOT inherited from Exception####");

		}
	}

	@Test
	public void testNotEligibleForTaxExceptionParameterConstructor() {
		Constructor[] cons = new NotEligibleForTaxException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"NotEligibleForTaxException(java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####ParameterizedConstructorTest | Passed | 2/2 | Parameterized Constructor for NotEligibleForTaxException Created####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/2 | Parameterized Constructors for NotEligibleForTaxException Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####NotEligibleForTaxExceptionTest | Failed | 0/2 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNotEligibleForTaxException() {
		Constructor[] cons = new NotEligibleForTaxException().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("NotEligibleForTaxException()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found && accessible);
			System.out
					.println("#####CorrectConstructorTest | Passed | 2/2 | Constructor for NotEligibleForTaxException Created####");
			
		} catch (AssertionError ae) {
			System.out
					.println("#####Constructor Test | Failed | 0/2 | Default Constructors for NotEligibleForTaxException Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####NotEligibleFor TaxExceptionTest | Failed | 0/2 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	
	// Test cases for TaxCalculate
	@Test
	public void TaxCalculateTest() {
		try {
			TaxSimulator ts = new TaxSimulator();
			COJ_35_Employee emp = new COJ_35_Employee("xyz", "abc", 394);
			assertEquals(Messages.COUNTRYINVALID, ts.findTaxOutput(emp));
			System.out
					.println("#####TaxCalculateTest | Passed | 12/12 | Passed for Indian Citizen Test####");

			try {
				emp = new COJ_35_Employee(null, "Indian", 3040);
				assertEquals(Messages.NAMEINVALID, ts.findTaxOutput(emp));
				System.out
						.println("#####TaxCalculateTest | Passed | 10/10 | Passed for Null Employee Name Test####");

				try {
					emp = new COJ_35_Employee("", "Indian", 3040);
					assertEquals(Messages.NAMEINVALID, ts.findTaxOutput(emp));
					System.out
							.println("#####TaxCalculateTest | Passed | 10/10 | Passed for Empty Employee Name Test####");

					try {
						emp = new COJ_35_Employee("Murali", "Indian", 150000);
						assertEquals(Messages.SUCCESS + " " + 12000,
								ts.findTaxOutput(emp));
						System.out
								.println("#####TaxCalculateTest | Passed | 10/10 | Passed for Amount exceeding 1 lac Test####");
						try {
							emp = new COJ_35_Employee("Murali", "Indian", 90000);
							assertEquals(Messages.SUCCESS + " " + 5400,
									ts.findTaxOutput(emp));
							System.out
									.println("#####TaxCalculateTest | Passed | 10/10 | Passed for Amount between 50k and  1 lac Test####");

							try {
								emp = new COJ_35_Employee("Murali", "Indian", 40000);
								assertEquals(Messages.SUCCESS + " " + 2000,
										ts.findTaxOutput(emp));
								System.out
										.println("#####TaxCalculateTest | Passed | 10/10 | Passed for Amount between 30k and  50k Test####");

								try {
									emp = new COJ_35_Employee("Murali", "Indian", 11000);
									assertEquals(Messages.SUCCESS + " " + 440,
											ts.findTaxOutput(emp));
									System.out
											.println("#####TaxCalculateTest | Passed | 10/10 | Passed for Amount between 10k and  30k Test####");

									try {
										emp = new COJ_35_Employee("Murali", "Indian", 1000);
										assertEquals(Messages.TAXNOTELIGIBLE,
												ts.findTaxOutput(emp));
										System.out
												.println("#####TaxCalculateTest | Passed | 10/10 | Passed for No Tax Exemption Test####");

										
									
									} catch (AssertionError ae) {
										System.out
												.println("#####TaxCalculateTest | Failed | 0/10 | Failed for No Tax Exemption Test####");

									}
									
								
								} catch (AssertionError ae) {
									System.out
											.println("#####TaxCalculateTest | Failed | 0/10 | Failed for Amount between 10k and 30k Test####");

								}

							
							} catch (AssertionError ae) {
								System.out
										.println("#####TaxCalculateTest | Failed | 0/10 | Failed for Amount between 30k and 50k Test####");

							}
						
						} catch (AssertionError ae) {
							System.out
									.println("#####TaxCalculateTest | Failed | 0/10 | Failed for Amount between 50k and 1 lac Test####");

						}

							
					
					} catch (AssertionError ae) {
						System.out
								.println("#####TaxCalculateTest | Failed | 0/10 | Failed for Amount exceeding 1 lac Test####");

					}
				} catch (AssertionError ae) {
					System.out
							.println("#####TaxCalculateTest | Failed | 0/10 | Failed for Empty Employee Name Test####");

				}
			} catch (AssertionError ae) {
				System.out

						.println("#####TaxCalculateTest | Failed | 0/10 | Failed for Null Employee Name Test####");
			}
		} catch (AssertionError ae) {
			System.out
					.println("#####TaxCalculateTest | Failed | 0/12 | Failed for Indian Citizen Test####");

		} catch (NoSuchMethodError ae) {
			System.out
					.println("#####TaxCalculateTest | Failed | 0/10 | Failed for required method not found####");

		} catch (Exception e) {
			System.out
					.println("#####TaxCalculateTest | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");

		}
	}
}
