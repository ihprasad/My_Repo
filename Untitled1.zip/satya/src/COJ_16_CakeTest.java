import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class COJ_16_CakeTest {

	@Test
	public void showCakeTest() {
		try {
			final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
			final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
			PrintStream pw = System.out;
			PrintStream pe = System.err;

			System.setOut(new PrintStream(outContent));
			System.setErr(new PrintStream(errContent));

			COJ_16_Cake oc = new COJ_16_OrderedCake();
			oc.showCake();

			String outputOne = outContent.toString();
			oc = new COJ_16_OrderedCake("Square", "Chocolate", 3);
			oc.showCake();
			String outputTwo = outContent.toString();
			oc = new COJ_16_OrderedCake("Oval", "ButterScotch", 8, "Happy Birthday");
			oc.showCake();
			String outputThree = outContent.toString();
			oc = new COJ_16_OrderedCake("Oval", "ButterScotch", 8, null);
			oc.showCake();
			String outputFour = outContent.toString();

			System.setOut(pw);
			System.setErr(pe);

			assertEquals("A Round Vanilla Cake Of 1 Kg/Kg's Ready @ Rs.400/-",
					outputOne);
			System.out
					.println("#####showCakeTest | Passed | 9 / 9 | Passed for Default display Test showCakeTest#####");

			try {
				// System.out.println(outputTwo);
				assertEquals(
						"A Round Vanilla Cake Of 1 Kg/Kg's Ready @ Rs.400/-A Square Chocolate Cake Of 3 Kg/Kg's Ready @ Rs.1200/-",
						outputTwo);
				System.out
						.println("#####showCakeTest | Passed | 9 / 9 | Passed for Custom Order display Test showCakeTest#####");

				try {
					assertEquals(
							"A Round Vanilla Cake Of 1 Kg/Kg's Ready @ Rs.400/-A Square Chocolate Cake Of 3 Kg/Kg's Ready @ Rs.1200/-A Oval ButterScotch Cake Of 8 Kg/Kg's Ready With Message Happy Birthday @ Rs.3200/-",
							outputThree);
					System.out
							.println("#####showCakeTest | Passed | 9 / 9 | Passed for Custom Order with message display Test showCakeTest#####");

					try {
						assertEquals(
								"A Round Vanilla Cake Of 1 Kg/Kg's Ready @ Rs.400/-A Square Chocolate Cake Of 3 Kg/Kg's Ready @ Rs.1200/-A Oval ButterScotch Cake Of 8 Kg/Kg's Ready With Message Happy Birthday @ Rs.3200/-A Oval ButterScotch Cake Of 8 Kg/Kg's Ready @ Rs.3200/-",
								outputFour);
						System.out
								.println("#####showCakeTest | Passed | 9 / 9 | Passed for Custom Order with null message display Test showCakeTest#####");

					} catch (AssertionError e) {
						System.out
								.println("#####showCakeTest | Failed | 0 / 9 | Failed for Custom order with null message display Test  showCakeTest#####");
					}

				} catch (AssertionError e) {
					System.out
							.println("#####showCakeTest | Failed | 0 / 9 | Failed for Custom order with message display Test  showCakeTest#####");
				}

			} catch (AssertionError e) {
				System.out
						.println("#####showCakeTest | Failed | 0 / 9 | Failed for Custom order  display Test  showCakeTest#####");
			}
		} catch (AssertionError e) {
			System.out
					.println("#####showCakeTest | Failed | 0 / 9 | Failed for Default display Test  showCakeTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####showCakeTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####showCakeTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void orderedCakeExactRequiredMethodsTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_16_OrderedCake")
					.getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());
			assertTrue(methodsSet.toString().equals(
					"[public void COJ_16_OrderedCake.showCake()]"));
			System.out
					.println("#####orderedCakeExactRequiredMethodsTest | Passed | 10 / 10 | Passed for COJ_16_CakeExactRequiredMethodsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####orderedCakeExactRequiredMethodsTest | Failed | 0 / 10 | Failed for orderedCakeExactRequiredMethodsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####orderedCakeExactRequiredMethodsTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####orderedCakeExactRequiredMethodsTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_16_CakeExactRequiredMethodsTest() {
		try {
			Set<String> methodsSet = new TreeSet<String>();
			Method methods[] = Class.forName("COJ_16_Cake").getDeclaredMethods();
			for (Method method : methods)
				methodsSet.add(method.toString());
			assertTrue(methodsSet
					.toString()
					.equals("[protected float COJ_16_Cake.getPrice(), protected int COJ_16_Cake.getQty(), protected java.lang.String COJ_16_Cake.getFlavour(), protected java.lang.String COJ_16_Cake.getShape(), protected void COJ_16_Cake.setFlavour(java.lang.String), protected void COJ_16_Cake.setPrice(float), protected void COJ_16_Cake.setQty(int), protected void COJ_16_Cake.setShape(java.lang.String), protected void COJ_16_Cake.showCake()]"));
			System.out
					.println("#####cakeExactRequiredMethodsTest | Passed | 9 / 9 | Passed for COJ_16_CakeExactRequiredMethodsTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####cakeExactRequiredMethodsTest | Failed | 0 / 9 | Failed for COJ_16_CakeExactRequiredMethodsTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####cakeExactRequiredMethodsTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####cakeExactRequiredMethodsTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void orderedCakeExactRequiredFields() {
		try {
			Set<String> fieldsSet = new TreeSet<String>();
			Field fields[] = Class.forName("COJ_16_OrderedCake").getDeclaredFields();
			for (Field field : fields)
				fieldsSet.add(field.toString());
			assertTrue(fieldsSet.toString().equals(
					"[private java.lang.String COJ_16_OrderedCake.message]"));
			System.out
					.println("#####orderedCakeExactRequiredFields | Passed | 9 / 9 | Passed for orderedCakeExactRequiredFields#####");

		} catch (AssertionError e) {
			System.out
					.println("#####orderedCakeExactRequiredFields | Failed | 0 / 9 | Failed for orderedCakeExactRequiredFields#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####orderedCakeExactRequiredFields | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####orderedCakeExactRequiredFields | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_16_CakeExactRequiredFields() {
		try {
			Set<String> fieldsSet = new TreeSet<String>();
			Field fields[] = Class.forName("COJ_16_Cake").getDeclaredFields();
			for (Field field : fields)
				fieldsSet.add(field.toString());
			assertTrue(fieldsSet
					.toString()
					.equals("[private float COJ_16_Cake.price, private int COJ_16_Cake.qty, private java.lang.String COJ_16_Cake.flavour, private java.lang.String COJ_16_Cake.shape]"));
			System.out
					.println("#####cakeExactRequiredFields | Passed | 9 / 9 | Passed for COJ_16_CakeExactRequiredFields#####");

		} catch (AssertionError e) {
			System.out
					.println("#####cakeExactRequiredFields | Failed | 0 / 9 | Failed for COJ_16_CakeExactRequiredFields#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####cakeExactRequiredFields | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####cakeExactRequiredFields | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_16_CakeAsAbstractClassTest() {
		try {
			int modifier = Class.forName("COJ_16_Cake").getModifiers();
			assertTrue(modifier == java.lang.reflect.Modifier.PUBLIC
					+ java.lang.reflect.Modifier.ABSTRACT);
			System.out
					.println("#####cakeAsAbstractClassTest | Passed | 9 / 9 | Passed for COJ_16_CakeAsAbstractClassTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####cakeAsAbstractClassTest | Failed | 0 / 9 | Failed for COJ_16_CakeAsAbstractClassTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####cakeAsAbstractClassTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####cakeAsAbstractClassTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void COJ_16_CakeRequiredConstructorsOnlyTest() {
		try {
			Constructor s[] = Class.forName("COJ_16_Cake").getDeclaredConstructors();
			Set<String> cons = new TreeSet<String>();
			for (int i = 0; i < s.length; i++) {
				cons.add(s[i].toString());
			}
			assertTrue(cons.toString().equals(
					"[protected COJ_16_Cake(java.lang.String,java.lang.String,int)]"));
			System.out
					.println("#####cakeRequiredConstructorsOnlyTest | Passed | 9 / 9 | Passed for COJ_16_CakeRequiredConstructorsOnlyTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####cakeRequiredConstructorsOnlyTest | Failed | 0 / 9 | Failed for COJ_16_CakeRequiredConstructorsOnlyTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####cakeAsAbstractClassTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####cakeAsAbstractClassTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void orderedCakeRequiredConstructorsOnlyTest() {
		try {
			Constructor s[] = Class.forName("COJ_16_OrderedCake")
					.getDeclaredConstructors();
			Set<String> cons = new TreeSet<String>();
			for (int i = 0; i < s.length; i++) {
				cons.add(s[i].toString());
			}
			assertTrue(cons
					.toString()
					.equals("[public COJ_16_OrderedCake(), public COJ_16_OrderedCake(java.lang.String,java.lang.String,int), public COJ_16_OrderedCake(java.lang.String,java.lang.String,int,java.lang.String)]"));
			System.out
					.println("#####orderedCakeRequiredConstructorsOnlyTest | Passed | 9 / 9 | Passed for orderedCakeRequiredConstructorsOnlyTest#####");

		} catch (AssertionError e) {
			System.out
					.println("#####orderedCakeRequiredConstructorsOnlyTest | Failed | 0 / 9 | Failed for orderedCakeRequiredConstructorsOnlyTest#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####orderedCakeRequiredConstructorsOnlyTest | Failed | 0 / 9 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####orderedCakeRequiredConstructorsOnlyTest | Failed | 0 / 9 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
}
