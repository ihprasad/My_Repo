import java.util.Comparator;
import java.util.TreeSet;

// DO NOT DELETE THIS CLASS OR ANY OF ITS CONTENTS.
public class COJ_21_Employee {

	private int employeeId;
	private String employeeName;
	private double salary;
	private int age;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public COJ_21_Employee() {
	}

	public COJ_21_Employee(int employeeId, String employeeName, double salary, int age) {
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", salary=" + salary + ", age=" + age + "]";
	}

}

// class COJ_21_EmpComparator

class EmpComparator implements Comparator<COJ_21_Employee> {
	@Override
	public int compare(COJ_21_Employee arg0, COJ_21_Employee arg1) {
		if (arg0.getSalary() > arg1.getSalary()) {
			return 1;
		} else if (arg0.getSalary() < arg1.getSalary()) {
			return -1;
		} else {
			if (arg0.getEmployeeName().compareTo(arg1.getEmployeeName()) > 0)
				return 1;
			else if (arg0.getEmployeeName().compareTo(arg1.getEmployeeName()) < 0)
				return -1;
			else {
				if (arg0.getAge() > arg1.getAge())
					return -1;
				else if (arg0.getAge() < arg1.getAge())
					return 1;
				else
					return 0;

			}

		}

	}

}

// class EmployeeSet

class EmployeeSet {

	private TreeSet<COJ_21_Employee> empTreeSet;

	public TreeSet<COJ_21_Employee> getEmpTreeSet() {
		return empTreeSet;
	}

	public void setEmpTreeSet(TreeSet<COJ_21_Employee> empTreeSet) {
		this.empTreeSet = empTreeSet;
	}

	public EmployeeSet() {
		empTreeSet = new TreeSet<COJ_21_Employee>(new EmpComparator());
	}
	
	
	public int addEmployee(COJ_21_Employee emp) {
		if(emp==null)
			return 1;
		boolean bo = empTreeSet.add(emp);
		if (bo == false)
			return 1;
		else
			return 0;
	}

}

