abstract public class COJ_16_Cake {
	private String shape;
	private String flavour;
	private int qty;
	private float price;


	protected COJ_16_Cake(String shape,String flavour,int qty){
		this.shape=shape;
		this.flavour=flavour;
		this.qty=qty;
	}
	protected String getShape() {
		return shape;
	}
	protected void setShape(String shape) {
		this.shape = shape;
	}
	protected String getFlavour() {
		return flavour;
	}
	protected void setFlavour(String flavour) {
		this.flavour = flavour;
	}
	protected int getQty() {
		return qty;
	}
	protected void setQty(int qty) {
		this.qty = qty;
	}
	protected float getPrice() {
		return price;
	}
	protected void setPrice(float price) {
		this.price = price;
	}
	protected void showCake()
	{
		System.out.print("A "+shape+" "+flavour+" Cake Of "+qty+" Kg/Kg's Ready @ Rs."+(int)price+"/-");
	}
}

class COJ_16_OrderedCake extends COJ_16_Cake {

	private String message;
	public COJ_16_OrderedCake(String shape, String flavour, int qty) {
		super(shape, flavour, qty);
		super.setPrice(qty * 400);
	}

	public COJ_16_OrderedCake()
	{
		this("Round","Vanilla",1);
	}

	public COJ_16_OrderedCake(String shape, String flavour, int qty, String message) {
		super(shape, flavour, qty);
		this.message = message;
		super.setPrice(qty * 400);
	}

	@Override
	public void showCake() {
		if (message != null && !message.isEmpty()) {
			System.out.print("A " + getShape() + " " + getFlavour()
					+ " Cake Of " + getQty() + " Kg/Kg's Ready With Message "
					+ message + " @ Rs." +(int) getPrice()+"/-");
		}
		else
		{
			super.showCake();
		}
	}

}
