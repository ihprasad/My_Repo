

public class COJ_11_Student {

	protected String name;
	protected int studentId;
	protected double examFee;
	
	public static void main(String[] args) {
		COJ_11_Student s = new COJ_11_Student("TalentSprint",101,5000);
		System.out.println(s.displayDetails());
		System.out.println(s);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public double getExamFee() {
		return examFee;
	}

	public void setExamFee(double examFee) {
		this.examFee = examFee;
	}

	/**
	 * Default constructor
	 */
	public COJ_11_Student() {
		this.name = null;
		this.studentId = 0;
		this.examFee = 0;
	}

	/**
	 * All-fields constructor
	 * 
	 * @param name
	 * @param studentId
	 * @param examFee
	 */
	public COJ_11_Student(String name, int studentId, double examFee) {
		this.name = name;
		this.studentId = studentId;
		this.examFee = examFee;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", studentId=" + studentId
				+ ", examFee=" + examFee + "]";
	}

	/**
	 * Display details of the student in the form Student [name=John Smith,
	 * studentId=123, examFee=100.0] *
	 * 
	 * @return
	 */
	public String displayDetails() {
		return this.toString();
	}

	/**
	 * Method that takes an amount and returns the remaining fees to be paid The
	 * remaining fees could be positive, negative(in case excess is paid) or
	 * zero
	 * 
	 * @param amount
	 * @return
	 */
	public double payFee(double amount) {
		double toPay = this.examFee - amount;
		return toPay;
	}

}


class COJ_11_DayScholar extends COJ_11_Student {

	double transportFee;
	 public COJ_11_DayScholar()
	 {
		 this.transportFee = 0;
	 }
	 
	 public COJ_11_DayScholar(String name, int studentId, double examFee,double tfee)
	 {
		 super(name,studentId,examFee);
		 this.transportFee = tfee;
	 }
	 public String toString() {
			return "DayScholar [transportFee="+transportFee+", name=" + name + ", studentId=" + studentId
					+ ", examFee=" + examFee  + "]";
		}
	 
	 public String displayDetails() {
			return this.toString();
		}

	public double payFee(double amount) {
			double toPay = (this.examFee + this.transportFee) - amount;
			return toPay;
		}

	public double getTransportFee() {
		return transportFee;
	}

	public void setTransportFee(double transportFee) {
		this.transportFee = transportFee;
	}
}




class COJ_11_Hosteller extends COJ_11_Student {
	double hostelFee;
	
	public COJ_11_Hosteller()
	{
		this.hostelFee = 0;
	}
	
	public COJ_11_Hosteller(String name, int studentId, double examFee,double hFee)
	{
		super(name,studentId,examFee);
		this.hostelFee = hFee;
	}
	public String toString() {
		return "Hosteller [hostelFee="+hostelFee+", name=" + name + ", studentId=" + studentId
				+ ", examFee=" + examFee  +  "]";
	}

	
	public String displayDetails() {
		return this.toString();
	}

	public double payFee(double amount) {
		double toPay = (this.examFee + this.hostelFee) - amount;
		return toPay;
	}

	public double getHostelFee() {
		return hostelFee;
	}

	public void setHostelFee(double hostelFee) {
		this.hostelFee = hostelFee;
	}
}



