
public class Employee {

	protected String name;
	protected int employeeId;
	protected double salary;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int empId) {
		this.employeeId = empId;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	/**
	 * Default constructor
	 */
	public Employee() {
		this.name = null;
		this.employeeId = 0;
		this.salary = 0;
	}

	/**
	 * All-field constructor
	 * 
	 * @param name
	 * @param empId
	 * @param salary
	 */
	public Employee(String name, int empId, double salary) {
		this.name = name;
		this.employeeId = empId;
		this.salary = salary;
	}

}

// Enum ManagerType

enum ManagerType {
	NONE, HR_MANAGER, SALES_MANAGER
};


// Class Manager

class Manager extends Employee {
	
	 ManagerType type;
	
	
	public Manager()
	{
		this.type = type.NONE;
	}
	
	public Manager(String name, int employeeid,double salary,ManagerType type)
	{
		super(name,employeeid,salary);
		this.type = type;
	}
	double setSalary()
	{
		if(type == type.HR_MANAGER)
		{
			salary = salary + 10000;
		}
		if(type == type.SALES_MANAGER)
		{
			salary = salary + 5000;
		}
		return salary;
		
	}
	public ManagerType getType() {
		return type;
	}
	public void setType(ManagerType type) {
		this.type = type;
	}

}


// Class Clerk

class Clerk extends Employee {

	
	int speed;
	int accuracy;
	
	public Clerk()
	{
		this.speed = 0;
		this.accuracy = 0;
		
	}
	public Clerk(String name, int employeeid, double salary, int speed, int accuracy)
	{
		
	super(name,employeeid,salary);
	this.speed = speed;
	this.accuracy = accuracy;
	
	}
	double setSalary()
	{
		if(speed > 70 & accuracy > 80)
		{
			salary = salary + 1000;
		}
		return salary;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAccuracy() {
		return accuracy;
	}
	public void setAccuracy(int accuracy) {
		this.accuracy = accuracy;
	}
}



