import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_11_StudentTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {

			Class c = Class.forName("COJ_11_Student");
			// test for student existence
			assertTrue("Class 'COJ_11_Student' not defined",
					c.isInstance(new COJ_11_Student()));

			c = Class.forName("COJ_11_Hosteller");
			// test for COJ_11_Hosteller existence
			assertTrue("Class 'COJ_11_DayScholar' not defined",
					c.isInstance(new COJ_11_Hosteller()));
			// test for super class
			assertTrue("COJ_11_Hosteller is not a subclass of COJ_11_Student", c
					.getSuperclass().toString().equals("class COJ_11_Student"));

			c = Class.forName("COJ_11_DayScholar");
			// test for COJ_11_DayScholar existence
			assertTrue("Class 'COJ_11_DayScholar' not defined",
					c.isInstance(new COJ_11_DayScholar()));
			// test for super class
			assertTrue("COJ_11_DayScholar is not a subclass of COJ_11_Student", c
					.getSuperclass().toString().equals("class COJ_11_Student"));

		} catch (AssertionError ae) {
			System.out.println("#####testStudent | Failed | 0/100 |"
					+ ae.getMessage() + ".#####");
			System.exit(0);
		}

		catch (ClassNotFoundException ce) {
			System.out
					.println("#####testStudent | Failed | 0/100 |"+ ce.getMessage() + " #####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testStudent | Failed | 0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testStudent() throws Exception {
		Constructor[] cons = new COJ_11_Student().getClass().getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_11_Student()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);

			assertTrue(accessible);

			System.out
					.println("#####testStudent | Passed | 4/4 | Checking for default constructor of Student.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testStudent | Failed | 0/4 | Checking for default constructor of Student.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testCOJ_11_Hosteller() throws Exception {
		Constructor[] cons = new COJ_11_Hosteller().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_11_Hosteller()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);
			System.out
					.println("#####testCOJ_11_Hosteller | Passed | 4/4 | Checking for default constructor of COJ_11_Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testCOJ_11_Hosteller | Failed | 0/4 | Checking for default constructor of COJ_11_Hosteller.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testCOJ_11_Hosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testCOJ_11_Hosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testCOJ_11_DayScholar() throws Exception {
		Constructor[] cons = new COJ_11_DayScholar().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_11_DayScholar()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);
			System.out
					.println("#####testCOJ_11_DayScholar | Passed | 4/4 | Checking for default constructor of COJ_11_DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testCOJ_11_DayScholar | Failed | 0/4 | Checking for default constructor of COJ_11_DayScholar.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testCOJ_11_DayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testCOJ_11_DayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetName() {
		try {

			COJ_11_Student pojo = new COJ_11_Student();
			// then
			final Field field = pojo.getClass().getDeclaredField("name");
			field.setAccessible(true);
			field.set(pojo, "Talentsprint");

			// when
			final String result = pojo.getName();

			// then
			assertEquals("field wasn't retrieved properly", result,
					"Talentsprint");
			System.out
					.println("#####testGetName | Passed | 4/4 | Checking for getter method: getName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetName | Failed | 0/4 | Checking for getter method: getName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetName | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSetName() {
		try {

			COJ_11_Student pojo = new COJ_11_Student();
			pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("name");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), "Talentsprint");
			System.out
					.println("#####testSetName | Passed | 4/4 | Checking for setter method: setName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetName | Failed | 0/4 | Checking for setter method: setName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetName | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetStudentId() {
		try {

			COJ_11_Student pojo = new COJ_11_Student();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("studentId");
			field.setAccessible(true);
			field.set(pojo, 123);

			// when
			final int result = pojo.getStudentId();

			// then
			assertEquals("field wasn't retrieved properly", result, 123);
			System.out
					.println("#####testGetStudentId | Passed | 4/4 | Checking for getter method: getStudentId().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetStudentId | Failed | 0/4 | Checking for getter method: getStudentId().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetStudentId | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
		;
	}

	@Test
	public void testSetStudentId() {
		try {

			COJ_11_Student pojo = new COJ_11_Student();
			pojo.setStudentId(111);

			// then
			final Field field = pojo.getClass().getDeclaredField("studentId");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 111);
			System.out
					.println("#####testSetStudentId | Passed | 4/4 | Checking for setter method: setStudentId().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetStudentId | Failed | 0/4 | Checking for setter method: setStudentId().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetStudentId | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetStudentId | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetExamFee() {
		try {

			COJ_11_Student pojo = new COJ_11_Student();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("examFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getExamFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetExamFee | Passed | 4/4 | Checking for getter method: getExamFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetExamFee | Failed | 0/4 | Checking for getter method: getExamFee().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetExamFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetExamFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetExamFee() {
		try {

			COJ_11_Student pojo = new COJ_11_Student();
			pojo.setExamFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("examFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetExamFee | Passed | 4/4 | Checking for setter method: setExamFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetExamFee | Failed | 0/4 | Checking for setter method: setExamFee().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetExamFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testStudentStringIntDouble() {

		Constructor[] cons = new COJ_11_Student().getClass().getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("COJ_11_Student(java.lang.String,int,double)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);

			System.out
					.println("#####Parameterized Constructor Accesibility Test | Passed | 4/4 | Parameterized Constructor Accessible for Student####");

		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/4 | Parameterized Constructors Not Defined for student####");

		} catch (Exception e) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDisplayDetailsStudent() {
		try {

			assertEquals("Student [name=null, studentId=0, examFee=0.0]",
					new COJ_11_Student().displayDetails());
			assertEquals(
					"Student [name=TalentSprint, studentId=101, examFee=5000.0]",
					new COJ_11_Student("TalentSprint", 101, 5000).displayDetails());

			System.out
					.println("#####testDisplayDetailsStudent | Passed | 4/4 | Checking for displayDetails().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDisplayDetailsStudent | Failed | 0/4 | "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testPayFeeStudent() {
		try {

			COJ_11_Student pojo;
			pojo = new COJ_11_Student();
			pojo.setExamFee(5000.0);

			assertEquals("Failed for payFee() in Student, ", 2000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in Student, ", 7000, new COJ_11_Student(
					"Talentsprint", 101, 10000.0).payFee(3000), 0);

			System.out
					.println("#####testPayFeeStudent | Passed | 4/4 | Checking for payFee() in Student.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeStudent | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testToStringStudent() {
		try {

			assertEquals("Student [name=null, studentId=0, examFee=0.0]",
					new COJ_11_Student().toString());
			assertEquals(
					"Student [name=TalentSprint, studentId=101, examFee=5000.0]",
					new COJ_11_Student("TalentSprint", 101, 5000).toString());

			System.out
					.println("#####testToStringStudent | Passed | 4/4 | Checking for toString() in Student.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringStudent | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// COJ_11_Hosteller Testcases

	@Test
	public void testToStringCOJ_11_Hosteller() {
		try {

			assertEquals(
					"Hosteller [hostelFee=0.0, name=null, studentId=0, examFee=0.0]",
					new COJ_11_Hosteller().toString());
			assertEquals(
					"Hosteller [hostelFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new COJ_11_Hosteller("TalentSprint", 101, 5000, 10000).toString());

			System.out
					.println("#####testToStringCOJ_11_Hosteller | Passed | 4/4 | Checking for toString() in COJ_11_Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringCOJ_11_Hosteller | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringCOJ_11_Hosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringCOJ_11_Hosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsCOJ_11_Hosteller() {
		try {

			assertEquals(
					"Hosteller [hostelFee=0.0, name=null, studentId=0, examFee=0.0]",
					new COJ_11_Hosteller().displayDetails());
			assertEquals(
					"Hosteller [hostelFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new COJ_11_Hosteller("TalentSprint", 101, 5000, 10000)
							.displayDetails());

			System.out
					.println("#####testDisplayDetailsCOJ_11_Hosteller | Passed | 4/4 | Checking for displayDetails() in COJ_11_Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDisplayDetailsCOJ_11_Hosteller | Failed | 0/4 | "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsCOJ_11_Hosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsCOJ_11_Hosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testPayFeeCOJ_11_Hosteller() {
		try {

			COJ_11_Hosteller pojo;
			pojo = new COJ_11_Hosteller();
			pojo.setExamFee(5000.0);
			pojo.setHostelFee(10000);

			assertEquals("Failed for payFee() in COJ_11_Hosteller, ", 12000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in COJ_11_Hosteller, ", 15000,
					new COJ_11_Hosteller("Talentsprint", 101, 10000.0, 15000)
							.payFee(10000), 0);

			System.out
					.println("#####testPayFeeCOJ_11_Hosteller | Passed | 4/4 | Checking for payFee() in COJ_11_Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeCOJ_11_Hosteller | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeCOJ_11_Hosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeCOJ_11_Hosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testCOJ_11_HostellerStringIntDoubleDouble() {
		Constructor[] cons = new COJ_11_Hosteller().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_11_Hosteller(java.lang.String,int,double,double)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}

		}

		try {
			assertTrue(found);
			assertTrue(accessible);
			System.out
					.println("#####testCOJ_11_HostellerStringIntDoubleDouble | Passed | 4/4 | Checking for parameterized constructor of COJ_11_Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testCOJ_11_HostellerStringIntDoubleDouble | Failed | 0/4 | Checking for parameterized constructor of COJ_11_Hosteller.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testCOJ_11_HostellerStringIntDoubleDouble | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testCOJ_11_HostellerStringIntDoubleDouble | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetHostelFee() {
		try {

			COJ_11_Hosteller pojo = new COJ_11_Hosteller();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("hostelFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getHostelFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetHostelFee | Passed | 4/4 | Checking for getter method: getHostelFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetHostelFee | Failed | 0/4 | Checking for getter method: getHostelFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetHostelFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetHostelFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetHostelFee() {
		try {

			COJ_11_Hosteller pojo = new COJ_11_Hosteller();
			pojo.setHostelFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("hostelFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetExamFee | Passed | 4/4 | Checking for setter method: setHostelFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetExamFee | Failed | 0/4 | Checking for setter method: setHostelFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetExamFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// COJ_11_DayScholar Test cases

	@Test
	public void testToStringCOJ_11_DayScholar() {
		try {

			assertEquals(
					"DayScholar [transportFee=0.0, name=null, studentId=0, examFee=0.0]",
					new COJ_11_DayScholar().toString());
			assertEquals(
					"DayScholar [transportFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new COJ_11_DayScholar("TalentSprint", 101, 5000, 10000).toString());

			System.out
					.println("#####testToStringCOJ_11_DayScholar | Passed | 4/4 | Checking for toString() in COJ_11_DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringCOJ_11_DayScholar | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringCOJ_11_DayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringCOJ_11_DayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsCOJ_11_DayScholar() {
		try {

			assertEquals(
					"DayScholar [transportFee=0.0, name=null, studentId=0, examFee=0.0]",
					new COJ_11_DayScholar().displayDetails());
			assertEquals(
					"DayScholar [transportFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new COJ_11_DayScholar("TalentSprint", 101, 5000, 10000)
							.displayDetails());

			System.out
					.println("#####testDisplayDetailsCOJ_11_DayScholar | Passed | 4/4 | Checking for displayDetails() in COJ_11_DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDisplayDetailsCOJ_11_DayScholar | Failed | 0/4 | "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsCOJ_11_DayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsCOJ_11_DayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testPayFeeCOJ_11_DayScholar() {
		try {

			COJ_11_DayScholar pojo;
			pojo = new COJ_11_DayScholar();
			pojo.setExamFee(5000.0);
			pojo.setTransportFee(10000);

			assertEquals("Failed for payFee() in COJ_11_DayScholar, ", 12000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in COJ_11_DayScholar, ", 15000,
					new COJ_11_DayScholar("Talentsprint", 101, 10000.0, 15000)
							.payFee(10000), 0);

			System.out
					.println("#####testPayFeeCOJ_11_DayScholar | Passed | 4/4 | Checking for payFee() in COJ_11_DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeCOJ_11_DayScholar | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeCOJ_11_DayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeCOJ_11_DayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testCOJ_11_DayScholarStringIntDoubleDouble() {
		Constructor[] cons = new COJ_11_DayScholar().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"DayScholar(java.lang.String,int,double,double)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}

		}

		try {
			assertTrue(found);
			assertTrue(accessible);

			System.out
					.println("#####testCOJ_11_DayScholarStringIntDoubleDouble | Passed | 4/4 | Checking for parameterized constructor of COJ_11_DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testCOJ_11_DayScholarStringIntDoubleDouble | Failed | 0/4 | Checking for parameterized constructor of COJ_11_DayScholar.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testCOJ_11_DayScholarStringIntDoubleDouble | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testCOJ_11_DayScholarStringIntDoubleDouble | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetTransportFee() {
		try {

			COJ_11_DayScholar pojo = new COJ_11_DayScholar();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass()
					.getDeclaredField("transportFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getTransportFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetTransportFee | Passed | 4/4 | Checking for getter method: getTransportFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetTransportFee | Failed | 0/4 | Checking for getter method: getTransportFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetTransportFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetTransportFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetTransportFee() {
		try {

			COJ_11_DayScholar pojo = new COJ_11_DayScholar();
			pojo.setTransportFee(5000.0);

			// then
			final Field field = pojo.getClass()
					.getDeclaredField("transportFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetTransportFee | Passed | 4/4 | Checking for setter method: setTransportFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetTransportFee | Failed | 0/4 | Checking for setter method: setTransportFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetTransportFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetTransportFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
}
