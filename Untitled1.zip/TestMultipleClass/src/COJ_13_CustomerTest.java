import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import org.junit.BeforeClass;
import org.junit.Test;


public class COJ_13_CustomerTest {
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {

			Class c = Class.forName("COJ_13_Customer");
			// test for student existence
			assertTrue("Class 'COJ_13_Customer' not defined",
					c.isInstance(new COJ_13_Customer())); 

			c = Class.forName("COJ_13_Account");
			// test for Hosteller existence
			assertTrue("Class 'COJ_13_Account' not defined",
					c.isInstance(new COJ_13_Account())); 
			

		} catch (AssertionError ae) {
			System.out.println("#####testCustomer | Failed | 0/100 |"
					+ ae.getMessage() + ".#####");
			System.exit(0);
		}

		catch (ClassNotFoundException ce) {
			System.out
					.println("#####testStudent | Failed | 0/100 |" + ce.getMessage() + " #####");
			System.exit(0);

		}catch (Exception e) {
			System.out
			.println("#####testStudent | Failed | 0/7 |Runtime Exception:"
					+ e.getMessage() + "#####");
}

	}


	@Test
	public void testCustomer() throws Exception {
		Constructor[] cons = new COJ_13_Customer().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_13_Customer()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);

			System.out
					.println("#####testCustomer | Passed | 5/5 | Checking for default constructor of Customer.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testCustomer | Failed | 0/5 | Checking for default constructor of Customer.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testCustomer | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testCustomer | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testGetFirstName() {
		try {

			COJ_13_Customer pojo = new COJ_13_Customer();
			// then
			final Field field = pojo.getClass().getDeclaredField("firstName");
			field.setAccessible(true);
			field.set(pojo, "Talent");

			// when
			final String result = pojo.getFirstName();

			// then
			assertEquals("field wasn't retrieved properly", result, "Talent");
			System.out
					.println("#####testGetFirstName | Passed | 5/5 | Checking for getter method: getFirstName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetFirstName | Failed | 0/5 | Checking for getter method: getFirstName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetFirstName | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetFirstName | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSetFirstName() {
		try {

			COJ_13_Customer pojo = new COJ_13_Customer();
			pojo.setFirstName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("firstName");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), "Talentsprint");
			System.out
					.println("#####testSetFirstName | Passed | 5/5 | Checking for setter method: setFirstName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetFirstName | Failed | 0/5 | Checking for setter method: setFirstName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetFirstName | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetFirstName | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetLastName() {
		try {

			COJ_13_Customer pojo = new COJ_13_Customer();
			// then
			final Field field = pojo.getClass().getDeclaredField("lastName");
			field.setAccessible(true);
			field.set(pojo, "sprint");

			// when
			final String result = pojo.getLastName();

			// then
			assertEquals("field wasn't retrieved properly", result, "sprint");
			System.out
					.println("#####testGetLastName | Passed | 5/5 | Checking for getter method: getLastName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetLastName | Failed | 0/5 | Checking for getter method: getLastName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetLastName | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetLastName | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSetLastName() {
		try {

			COJ_13_Customer pojo = new COJ_13_Customer();
			pojo.setLastName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("lastName");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), "Talentsprint");
			System.out
					.println("#####testSetLastName | Passed | 5/5 | Checking for setter method: setLastName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetLastName | Failed | 0/5 | Checking for setter method: setLastName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetLastName | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetLastName | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testCustomerStringString() {
		Constructor[] cons = new COJ_13_Customer().getClass()
				.getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_13_Customer(java.lang.String,java.lang.String)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);

			System.out
					.println("#####Parameterized Constructor Accesibility Test | Passed | 5/5 | Parameterized Constructor Accessible####");

		} catch (AssertionError ae) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/20 | Parameterized Constructors Not Defined####");

		} catch (Exception e) {
			System.out
					.println("#####Parameterized Constructor Test | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	// Account class testcases
	
	@Test
	public void testGetCustomer() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			// then
			final Field field = pojo.getClass().getDeclaredField("customer");
			field.setAccessible(true);
			COJ_13_Customer c = new COJ_13_Customer("Talent", "Sprint");
			field.set(pojo, c);

			// when
			final COJ_13_Customer result = pojo.getCustomer();

			// then
			assertEquals("field wasn't retrieved properly", result, c);

			System.out
					.println("#####testGetCustomer | Passed | 5/5 | Checking for getter method: getCustomer().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetCustomer | Failed | 0/5 | Checking for getter method: getCustomer().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetCustomer | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetCustomer | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetCustomer() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			COJ_13_Customer c = new COJ_13_Customer();
			pojo.setCustomer(c);

			// then
			final Field field = pojo.getClass().getDeclaredField("customer");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), c);

			COJ_13_Customer c1 = new COJ_13_Customer("Talent", "Sprint");
			pojo.setCustomer(c1);

			assertEquals("Fields didn't match", field.get(pojo), c1);
			System.out
					.println("#####testSetCustomer | Passed | 5/5 | Checking for setter method: setCustomer().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetCustomer | Failed | 0/5 | Checking for setter method: setCustomer().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetCustomer | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetCustomer | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetBalance() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			// then
			final Field field = pojo.getClass().getDeclaredField("balance");
			field.setAccessible(true);
			field.set(pojo, 5000.0);

			// when
			final double result = pojo.getBalance();

			// then
			assertEquals("field wasn't retrieved properly", result, 5000.0, 0);
			System.out
					.println("#####testGetBalance | Passed | 5/5 | Checking for getter method: getBalance().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetBalance | Failed | 0/5 | Checking for getter method: getBalance().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetBalance | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetBalance | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetBalance() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			pojo.setBalance(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("balance");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);

			System.out
					.println("#####testSetBalance | Passed | 5/5 | Checking for setter method: setBalance().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetBalance | Failed | 0/5 | Checking for setter method: setBalance().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetBalance | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetBalance | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetAccountNo() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			// then
			final Field field = pojo.getClass().getDeclaredField("accountNo");
			field.setAccessible(true);
			field.set(pojo, 5);

			// when
			final int result = pojo.getAccountNo();

			// then
			assertEquals("field wasn't retrieved properly", result, 5);

			System.out
					.println("#####testGetAccountNo | Passed | 5/5 | Checking for getter method: getAccountNo().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetAccountNo | Failed | 0/5 | Checking for getter method: getAccountNo().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetAccountNo | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetAccountNo | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetAccountNo() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			pojo.setAccountNo(500);

			// then
			final Field field = pojo.getClass().getDeclaredField("accountNo");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 500);

			System.out
					.println("#####testSetAccountNo | Passed | 5/5 | Checking for setter method: getAccountNo().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetAccountNo | Failed | 0/5 | Checking for setter method: getAccountNo().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetAccountNo | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetAccountNo | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetInterestRate() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			// then
			final Field field = pojo.getClass()
					.getDeclaredField("interestRate");
			field.setAccessible(true);
			field.set(pojo, 5f);

			// when
			final float result = pojo.getInterestRate();

			// then
			assertEquals("field wasn't retrieved properly", result, 5f, 0);
			System.out
					.println("#####testGetInterestRate | Passed | 5/5 | Checking for getter method: getInterestRate().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetInterestRate | Failed | 0/5 | Checking for getter method: getInterestRate().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetInterestRate | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetInterestRate | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetInterestRate() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			pojo.setInterestRate(5f);

			// then
			final Field field = pojo.getClass()
					.getDeclaredField("interestRate");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5f);

			System.out
					.println("#####testSetInterestRate | Passed | 5/5 | Checking for setter method: getInterestRate().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetInterestRate | Failed | 0/5 | Checking for setter method: getInterestRate().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetInterestRate | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetInterestRate | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testAccount() {
		Constructor[] cons = new COJ_13_Account().getClass().getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains("Account()")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				// break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);

			System.out
					.println("#####testAccount | Passed | 5/5 | Checking for default constructor of Account.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testAccount | Failed | 0/5 | Checking for default constructor of Account.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testAccount | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testAccount | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testAccountIntCustomerDoubleFloat() {
		Constructor[] cons = new COJ_13_Account().getClass().getDeclaredConstructors();
		boolean found = false;
		boolean accessible = false;
		for (Constructor con : cons) {
			if (con.toString().contains(
					"COJ_13_Account(int,COJ_13_Customer,double,float)")) {
				found = true;

				if (con.getModifiers() == java.lang.reflect.Modifier.PUBLIC)
					accessible = true;
				break;
			}
		}

		try {
			assertTrue(found);
			assertTrue(accessible);

			System.out
					.println("#####testAccount | Passed | 5/5 | Checking for parameterized constructor of Account.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testAccount | Failed | 0/5 | Checking for parameterized constructor of Account.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testAccount | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testAccount | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDeposit() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			assertEquals("Fields didn't match", 0, pojo.getBalance(), 0);
			pojo.deposit(5000);

			assertEquals("Fields didn't match", 5000, pojo.getBalance(), 0);

			pojo.setBalance(5000.0);
			pojo.deposit(5000);

			assertEquals("Fields didn't match", 10000, pojo.getBalance(), 0);
			COJ_13_Customer c = new COJ_13_Customer();

			pojo = new COJ_13_Account(1, c, 5000, 1);
			assertEquals("Fields didn't match", 5000, pojo.getBalance(), 0);
			pojo.deposit(5000);

			assertEquals("Fields didn't match", 10000, pojo.getBalance(), 0);

			System.out
					.println("#####testDeposit | Passed | 10/10 | Checking for method: deposit().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDeposit | Failed | 0/10 | Checking for method: deposit().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDeposit | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDeposit | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testWithdraw() {
		try {

			COJ_13_Account pojo = new COJ_13_Account();
			// assertEquals("Fields didn't match", 0, pojo.getBalance(),0);
			pojo.withdraw(5000);
			assertEquals("Fields didn't match", 0, pojo.getBalance(), 0);
			pojo = new COJ_13_Account();
			
			pojo.setBalance(5000.0);
			pojo.withdraw(5000);
			
			assertEquals("Fields didn't match", 0, pojo.getBalance(), 0);
			
			pojo.setBalance(5000.0);
			pojo.withdraw(2000);

			assertEquals("Fields didn't match", 3000, pojo.getBalance(), 0);
			pojo.setBalance(5000.0);
			pojo.withdraw(7000);

			assertEquals("Fields didn't match", 5000, pojo.getBalance(), 0);

			COJ_13_Customer c = new COJ_13_Customer();

			pojo = new COJ_13_Account(1, c, 5000, 1);
			// assertEquals("Fields didn't match", 5000, pojo.getBalance(),0);
			pojo.withdraw(5000);
			
			assertEquals("Fields didn't match", 0, pojo.getBalance(), 0);
			
			pojo = new COJ_13_Account(1, c, 5000, 1);
			pojo.withdraw(2000);
			assertEquals("Fields didn't match", 3000, pojo.getBalance(), 0);

			pojo = new COJ_13_Account(1, c, 5000, 1);
			pojo.withdraw(12000);
			assertEquals("Fields didn't match", 5000, pojo.getBalance(), 0);

			System.out
					.println("#####testWithdraw | Passed | 10/10 | Checking for method: withdraw().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testWithdraw | Failed | 0/10 | Checking for method: withdraw().#####" + ae.getMessage());
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testWithdraw | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testWithdraw | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}


}
