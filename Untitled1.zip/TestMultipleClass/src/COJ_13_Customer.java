

public class COJ_13_Customer {

	private String firstName;
	private String lastName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Default constructor
	 */
	
	
	public COJ_13_Customer() {
		this.firstName = null;
		this.lastName = null;
	}

	/**
	 * All-fields constructor
	 * 
	 * @param firstName
	 * @param lastName
	 */
	public COJ_13_Customer(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

}


// Class Account



class COJ_13_Account {
	COJ_13_Customer customer;
	double balance;
	int accountNo;
	float interestRate;
	
	public COJ_13_Customer getCustomer() {
		return customer;
	}

	public void setCustomer(COJ_13_Customer customer) {
		this.customer = customer;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}

	
	//TODO Add fields
	//customer: Customer, balance: double, accountNo: int, interestRate: float
	
	// TODO add getters and setters for fields

	/**
	 * Default constructor - DO NOT DELETE
	 */
	public COJ_13_Account()
	{
		this.balance = 0;
		this.accountNo = 0;
		this.interestRate = 0f;
		this.customer = null;
	}

	/**
	 * @param accountNo
	 * @param cOJ_13_Customer
	 * @param balance
	 * @param interestRate
	 */
	public COJ_13_Account(int accountNo, COJ_13_Customer customer, double balance,
			float interestRate) {
		this.balance = balance;
		this.accountNo = accountNo;
		this.interestRate = interestRate;
		this.customer = customer;
	}

	/**
	 * deposit a given amount add to balance
	 * 
	 * @param amount
	 */
	public void deposit(double amount) {
		balance = balance + amount;
	}

	/**
	 * withdraw a given amount if the amount is lesser than balance
	 * 
	 * @param amount
	 */
	public void withdraw(double amount) {
		if(amount<=balance)
		{
			balance = balance - amount;
		}
	}
}
