package com.ts;
/**
 * This class implements a simple program that
 * will compute the amount of interest that is
 * earned on $17,000 invested at an interest
 * rate of 0.027 for one year.  The interest and
 * the value of the investment after one year are
 * printed to standard output.
 */
 
public class Interest {
	double principal;     // The value of the investment.
//    double rate;          // The annual interest rate.
    double interest;      // Interest earned in one year.
   
   public static void main(String[] args) {
   
   } // end of main()
   
   double calculateInterest(double principal, double rate){
//	   principal = 17000;
//       rate = 0.027;
	   if(principal <= 0 || rate <= 0)
		   return 0;
       return interest = principal * rate;        
      
   }
   
   double calculatePrincipalAfterYear(){
	   return principal + interest;
   }


      
} // end of class Interest