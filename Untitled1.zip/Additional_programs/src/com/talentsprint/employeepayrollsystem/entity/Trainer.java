package com.talentsprint.employeepayrollsystem.entity;

public class Trainer extends Employee {

	public int batchCount;
	public double perkPerBatch;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer
				+ ((double) batchCount * perkPerBatch);
	}

	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Trainer(int id, String name, double basicSalary, double hRAPer,
			double dAPer, int batchCount, double perkPerBatch) {
		super(id, name, basicSalary, hRAPer, dAPer);
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

}
