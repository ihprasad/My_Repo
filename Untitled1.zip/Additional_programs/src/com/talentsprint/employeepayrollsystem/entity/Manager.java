package com.talentsprint.employeepayrollsystem.entity;

public class Manager extends Employee {

	public double projectAllowance;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Manager(int id, String name, double basicSalary, double hRAPer,
			double dAPer, double projectAllowance) {
		super(id, name, basicSalary, hRAPer, dAPer);		
		this.projectAllowance = projectAllowance;
	}

	@Override
	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer + projectAllowance;
	}

}
