package com.talentsprint.employeepayrollsystem.entity;

public class Sourcing extends Employee {

	public int enrollmentTarget;
	public int enrollmentReached;
	public double perkPerEnrollment;

	public double calculateGrossSalary() {
		return basicSalary
				+ HRAPer
				+ DAPer
				+ ((((double) enrollmentReached / (double) enrollmentTarget) * 100) * perkPerEnrollment);
	}

	public Sourcing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sourcing(int id, String name, double basicSalary, double hRAPer,
			double dAPer, int enrollmentTarget, int enrollmentReached,
			double perkPerEnrollment) {
		super(id, name, basicSalary, hRAPer, dAPer);
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}

}
