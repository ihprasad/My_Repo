import static org.junit.Assert.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_14_ClassObjectTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		try {
			Class.forName("COJ_14_Employee");
			Class.forName("COJ_14_Manager");
			Class.forName("COJ_14_Trainer");
			Class.forName("COJ_14_Sourcing");
			Class.forName("COJ_14_TaxUtil");
		} catch (ClassNotFoundException ce) {
			System.out
					.println("#####testClassesDefinition | Failed | 0/50 |Class definition not found: "
							+ ce.getMessage() + " #####");
			System.exit(0);
		} catch (Exception e) {
			System.out
					.println("#####testClassesDefinetion | Failed | 0/50 |Runtime Exception: "
							+ e.getMessage() + " #####");
			System.exit(0);
		}
	}

	// Employee

	@Test
	public final void testEmployeeFields() {
		// fail("");
		
//		COJ_14_Employee e = new COJ_14_Employee();
		
		Field[] fld = COJ_14_Employee.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())) {
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Employee class not defined properly", fc == 5);
			System.out
					.println("#####testEmployeeFields | Passed | 4/4 | Checking for fields in COJ_14_Employee. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testEmployeeFields | Failed | 0/4 | Checking for fields in COJ_14_Employee: "
							+ ae.getMessage() + "#####");
		} catch (Exception ex) {
			System.out
					.println("#####testEmployeeFields | Failed | 0/4 |Runtime Exception:"
							+ ex.getMessage() + "#####");
		}
	}

	@Test
	public final void testEmployeeMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;

			COJ_14_Employee emp = new COJ_14_Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			double expected = bs + hra + da;
			double actual = emp.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testEmployeeMethod | Passed | 5/5 | Checking for COJ_14_Employee calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testEmployeeMethod | Failed | 0/5 | Checking for COJ_14_Employee calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testEmployeeMethod | Failed | 0/5| No such method found in COJ_14_Employee: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testEmployeeMethod | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// Manager
	@Test
	public final void testManagerFields() {
		// fail("");

		Field[] fld = COJ_14_Manager.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						| "projectAllowance".equals(f.getName())) {
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("projectAllowance".equals(f.getName())) {
						assertTrue("Field 'projectAllowance' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Manager class not defined properly", fc == 6);
			System.out
					.println("#####testManagerFields | Passed | 4/4 | Checking for fields in COJ_14_Manager. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testManagerFields | Failed | 0/4 | Checking for fields in COJ_14_Manager: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testManagerFields | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testManagerMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			double pa = 5000;

			COJ_14_Manager mgr = new COJ_14_Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			double expected = bs + hra + da + pa;
			double actual = mgr.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testManagerMethod | Passed | 5/5 | Checking for COJ_14_Manager calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testManagerMethod | Failed | 0/5 | Checking for COJ_14_Manager calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testManagerMethod | Failed | 0/5| No such method found in COJ_14_Manager: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testManagerMethod | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// Trainer
	@Test
	public final void testTrainerFields() {
		// fail("");

		Field[] fld = COJ_14_Trainer.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						|| "perkPerBatch".equals(f.getName())
						|| "batchCount".equals(f.getName())) {
					// System.out.println(f.getType().getName());
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("perkPerBatch".equals(f.getName())) {
						assertTrue("Field 'perkPerBatch' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("batchCount".equals(f.getName())) {
						assertTrue("Field 'batchCount' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Trainer class not defined properly", fc == 7);
			System.out
					.println("#####testTrainerFields | Passed | 4/4 | Checking for fields in COJ_14_Trainer. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testTrainerFields | Failed | 0/4 | Checking for fields in COJ_14_Trainer: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testTrainerFields | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testTrainerMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			int bc = 10;
			double ppb = 50.5;

			COJ_14_Trainer tr = new COJ_14_Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			double expected = bs + hra + da + (ppb * bc);
			double actual = tr.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testTrainerMethod | Passed | 5/5 | Checking for COJ_14_Trainer calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testTrainerMethod | Failed | 0/5 | Checking for COJ_14_Trainer calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTrainerMethod | Failed | 0/5| No such method found in COJ_14_Trainer: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTrainerMethod | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// Sourcing

	@Test
	public final void testSourcingFields() {
		// fail("");

		Field[] fld = COJ_14_Sourcing.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						|| "enrollmentTarget".equals(f.getName())
						|| "enrollmentReached".equals(f.getName())
						|| "perkPerEnrollment".equals(f.getName())) {
					// System.out.println(f.getType().getName());
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}

					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("enrollmentTarget".equals(f.getName())) {
						assertTrue("Field 'enrollmentTarget' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("enrollmentReached".equals(f.getName())) {
						assertTrue("Field 'enrollmentReached' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}
					if ("perkPerEnrollment".equals(f.getName())) {
						assertTrue("Field 'perkPerEnrollment' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Sourcing class not defined properly", fc == 8);
			System.out
					.println("#####testSourcingFields | Passed | 4/4 | Checking for fields in COJ_14_Sourcing. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSourcingFields | Failed | 0/4 | Checking for fields in COJ_14_Sourcing: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testSourcingFields | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testSourcingMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			COJ_14_Sourcing src = new COJ_14_Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			double expected = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			double actual = src.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testSourcingMethod | Passed | 5/5 | Checking for COJ_14_Sourcing calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSourcingMethod | Failed | 0/5 | Checking for COJ_14_Sourcing calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSourcingMethod | Failed | 0/5| No such method found in COJ_14_Sourcing: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSourcingMethod | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// taxutil
	@Test
	public final void testTaxUtilMethod() {
		try {
			Method[] method = new COJ_14_TaxUtil().getClass()
					.getDeclaredMethods();
			boolean taxMethods = false;
			int count = 0;

			for (Method m : method) {
				if (m.getName().equals("calculateTax"))
					if (m.getParameterTypes()[0].toString().equals(
							"class COJ_14_Employee"))
						count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class COJ_14_Manager"))
					count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class COJ_14_Trainer"))
					count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class COJ_14_Sourcing"))
					count++;
			}
			if (count > 0 && count <= 4) {
				int marks = count * 6;
				System.out
						.println("#####testTaxUtilMethod | Passed | "
								+ marks
								+ "/24 | Checking for calculateTax in COJ_14_TaxUtil. #####");
			}
			if (count == 4)
				taxMethods = true;

			assertTrue("calculateTax() method in COJ_14_TaxUtil not defined",
					taxMethods);

		} catch (AssertionError ae) {
			System.out
					.println("#####testTaxUtilMethod | Failed | 0/24 | Checking for calculateTax in COJ_14_TaxUtil: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTaxUtilMethod | Failed | 0/24| No such method found in COJ_14_TaxUtil: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTaxUtilMethod | Failed | 0/24 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public final void testCalculateTaxLess() {
		try {

			double bs = 15000;
			double hra = 2000;
			double da = 1000;
			double expectedGS = bs + hra + da;
			double totalTax = 0.0;

			COJ_14_TaxUtil tu = new COJ_14_TaxUtil();

			COJ_14_Employee emp = new COJ_14_Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			// Employee

			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(emp));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Employee calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Employee calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");
			}

			// Manager
			double pa = 5000;

			COJ_14_Manager mgr = new COJ_14_Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			expectedGS = bs + hra + da + pa;
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(mgr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Manager calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Manager calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");
			}

			// Trainer

			int bc = 100;
			double ppb = 50.5;

			COJ_14_Trainer tr = new COJ_14_Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			expectedGS = bs + hra + da + (ppb * bc);
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(tr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Trainer calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Trainer calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");
			}

			// Sourcing
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			COJ_14_Sourcing src = new COJ_14_Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			expectedGS = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(src));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Sourcing calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Sourcing calculateTax in COJ_14_TaxUtil for Gross Salary less than 30000. #####");
			}

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20| No such method found in COJ_14_Sourcing: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public final void testCalculateTaxGreater() {
		try {

			double bs = 35000;
			double hra = 2000;
			double da = 1000;
			double expectedGS = bs + hra + da;
			double totalTax = 0.0;

			COJ_14_TaxUtil tu = new COJ_14_TaxUtil();

			COJ_14_Employee emp = new COJ_14_Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			// Employee

			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(emp));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Employee calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Employee calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");
			}

			// Manager
			double pa = 5000;

			COJ_14_Manager mgr = new COJ_14_Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			expectedGS = bs + hra + da + pa;
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(mgr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Manager calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Manager calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");
			}

			// Trainer

			int bc = 100;
			double ppb = 50.5;

			COJ_14_Trainer tr = new COJ_14_Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			expectedGS = bs + hra + da + (ppb * bc);
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(tr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Trainer calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Trainer calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");
			}

			// Sourcing
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			COJ_14_Sourcing src = new COJ_14_Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			expectedGS = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(src));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 5/5 | Checking for Sourcing calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/5 | Failed for Sourcing calculateTax in COJ_14_TaxUtil for Gross Salary greater than 30000. #####");
			}

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20| No such method found in COJ_14_Sourcing: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}