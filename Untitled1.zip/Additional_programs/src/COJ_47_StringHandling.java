public class COJ_47_StringHandling {
	public static void main(String[] args) {
		COJ_47_Organization o = new COJ_47_Organization();

		COJ_47_Employee emp1, emp2, emp3, emp4, emp5, emp6, emp7, emp8, emp9, emp10, emp11, emp12, emp13;

		emp1 = new COJ_47_Employee(101, "Srinu", 10000, 5000, 2000);
		emp2 = new COJ_47_Employee(102, "Prasad", 10000, 5000, 2000);
		emp3 = new COJ_47_Employee(102, "Priyanka", 10000, 5000, 2000);
		emp4 = new COJ_47_Employee(103, "Shruti", 10000, 5000, 2000);
		emp5 = new COJ_47_Employee(108, "Hari priya", 10000, 5000, 2000);
		emp6 = new COJ_47_Employee(105, "Hari", 10000, 5000, 2000);
		emp7 = new COJ_47_Employee(106, "Rajanikanth", 10000, 5000, 2000);
		emp8 = new COJ_47_Employee(107, "Sneha", 10000, 5000, 2000);
		emp9 = new COJ_47_Employee(109, "Ravi", 10000, 5000, 2000);
		emp10 = new COJ_47_Employee(110, "Ram kumar", 10000, 5000, 2000);
		emp11 = new COJ_47_Employee(111, "Srinivas", 10000, 5000, 2000);
		emp12 = new COJ_47_Employee(112, "Ramana", 10000, 5000, 2000);
		emp13 = new COJ_47_Employee(112, "Ramana rao", 10000, 5000, 2000);

		System.out.println("Emp add --> " + o.addEmployee(emp1));

		System.out.println("Emp add --> " + o.addEmployee(emp2));

		System.out.println("Emp add --> " + o.addEmployee(emp3));

		System.out.println("Emp add --> " + o.addEmployee(emp4));

		System.out.println("Emp add --> " + o.addEmployee(emp5));

		System.out.println("Emp add --> " + o.addEmployee(emp6));

		System.out.println("Emp add --> " + o.addEmployee(emp7));

		System.out.println("Emp add --> " + o.addEmployee(emp8));

		System.out.println("Emp add --> " + o.addEmployee(emp9));

		System.out.println("Emp add --> " + o.addEmployee(emp10));

		System.out.println("Emp add --> " + o.addEmployee(emp11));

		System.out.println("Emp add --> " + o.addEmployee(emp12));

		System.out.println("Emp add --> " + o.addEmployee(emp13));

		System.out.println(o.noOfEmployees);

		o.printAllEmployees();
		
		

		// del

		System.out.println("Deleted: " + o.deleteEmployee(103));

		System.out.println(o.noOfEmployees + " Employees after deletion");

		o.printAllEmployees();
		// if (o.searchEmployeeByName("Ramana") != null)
		// System.out.println((o.searchEmployeeByName("Ramana")).getClass()
		// .getName());
		// else
		// System.out.println("null");
		
//		System.out.println("******** " + (o.searchEmployeeByName("HAri")).getClass().getName() + "-----------" + new COJ_47_Employee().getClass().getName());

	}

}

class COJ_47_Organization {

	String name;
	COJ_47_Employee[] employeeList;
	int noOfEmployees;

	public COJ_47_Organization() {
		super();
		// TODO Auto-generated constructor stub
		this.noOfEmployees = 0;
		this.employeeList = new COJ_47_Employee[10];
	}

	public int addEmployee(COJ_47_Employee e) {
		if (noOfEmployees == 10)
			return -1;

		int eid = e.id;
		if (noOfEmployees > 0)
			for (COJ_47_Employee emp : employeeList)
				if (emp != null && emp.id == eid)
					return -2;
		
		

		employeeList[noOfEmployees] = e;
		noOfEmployees++;

		return 0;
	}

	public COJ_47_Employee searchEmployeeByName(String name) {

		name = name.toLowerCase();
		for (COJ_47_Employee emp : employeeList)
			if (emp != null && ((emp.name).toLowerCase()).equals(name))
				return emp;

		return null;
	}

	public COJ_47_Employee getEmployeeById(int id) {

		// for (int i = 0; i < noOfEmployees; i++)
		// if (employeeList[i].id == id)
		// return employeeList[i];

		for (COJ_47_Employee emp : employeeList)
			if (emp != null && emp.id == id)
				return emp;

		return null;
	}

	public boolean deleteEmployee(int id) {
		for (int i = 0; i < noOfEmployees; i++)
			if (employeeList[i].id == id) {
				employeeList[i] = null;
				noOfEmployees--;
				int j = -1;
				for (j = i; j < noOfEmployees; j++) {
					employeeList[j] = employeeList[j + 1];
				}
				employeeList[j] = null;

				return true;
			}

		return false;

	}

	public void printAllEmployees() {
		System.out.println("id, name, basicSalary, HRAPer, DAPer");
		for (COJ_47_Employee emp : employeeList)
			if (emp != null)
				System.out.println(emp.id + ", " + emp.name + ", "
						+ emp.basicSalary + ", " + emp.HRAPer + ", "
						+ emp.DAPer);

	}
}

class COJ_47_Employee {

	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;

	public COJ_47_Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_47_Employee(int id, String name, double basicSalary,
			double hRAPer, double dAPer) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
	}

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer;
	}

}

// Class Manager
class COJ_47_Manager {

	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	double projectAllowance;

	public COJ_47_Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_47_Manager(int id, String name, double basicSalary,
			double hRAPer, double dAPer, double projectAllowance) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.projectAllowance = projectAllowance;
	}

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer + projectAllowance;
	}

}

// Trainer
class COJ_47_Trainer {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int batchCount;
	double perkPerBatch;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer
				+ ((double) batchCount * perkPerBatch);
	}

	public COJ_47_Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_47_Trainer(int id, String name, double basicSalary,
			double hRAPer, double dAPer, int batchCount, double perkPerBatch) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

}

// Sourcing

class COJ_47_Sourcing {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;

	public double calculateGrossSalary() {
		return basicSalary
				+ HRAPer
				+ DAPer
				+ ((((double) enrollmentReached / (double) enrollmentTarget) * 100) * perkPerEnrollment);
	}

	public COJ_47_Sourcing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_47_Sourcing(int id, String name, double basicSalary,
			double hRAPer, double dAPer, int enrollmentTarget,
			int enrollmentReached, double perkPerEnrollment) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}

}

// Class TaxUtil

class COJ_47_TaxUtil {

	double calculateTax(COJ_47_Employee emp) {
		if (emp.calculateGrossSalary() > 30000)
			return emp.calculateGrossSalary() * 0.2;
		else
			return emp.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_47_Manager mgr) {
		if (mgr.calculateGrossSalary() > 30000)
			return mgr.calculateGrossSalary() * 0.2;
		else
			return mgr.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_47_Trainer tr) {
		if (tr.calculateGrossSalary() > 30000)
			return tr.calculateGrossSalary() * 0.2;
		else
			return tr.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_47_Sourcing scr) {
		if (scr.calculateGrossSalary() > 30000)
			return scr.calculateGrossSalary() * 0.2;
		else
			return scr.calculateGrossSalary() * 0.05;
	}

}
