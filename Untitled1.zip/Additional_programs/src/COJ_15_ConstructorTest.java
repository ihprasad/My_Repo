import static org.junit.Assert.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
//import java.lang.reflect.Parameter;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_15_ConstructorTest {

	// @BeforeClass
	// public static void setUpBeforeClass() throws Exception {
	// System.out.println("Test---");
	// }

	@Test
	public void testConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for employee

			cons = new COJ_15_Employee().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public COJ_15_Employee(int,java.lang.String,double,double,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue("COJ_15_Employee(int, String, double, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				System.out
						.println("#####testConstructors | Failed | 0/4 | Constructor definition not found: "
								+ ae.getMessage() + ". #####");
			}

			// constructor for manager
			cons = new COJ_15_Manager().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public COJ_15_Manager(int,java.lang.String,double,double,double,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue(
						"COJ_15_Manager(int, String, double, double, double, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				System.out
						.println("#####testConstructors | Failed | 0/4 | Constructor definition not found: "
								+ ae.getMessage() + ". #####");
			}

			// constructor for Trainer
			cons = new COJ_15_Trainer().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public COJ_15_Trainer(int,java.lang.String,double,double,double,int,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue(
						"COJ_15_Trainer(int, String, double, double, double,int, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				System.out
						.println("#####testConstructors | Failed | 0/4 | Constructor definition not found: "
								+ ae.getMessage() + ". #####");
			}
			// constructor for Sourcing
			cons = new COJ_15_Sourcing().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public COJ_15_Sourcing(int,java.lang.String,double,double,double,int,int,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue(
						"COJ_15_Sourcing(int, String, double, double, double,int, int, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				System.out
						.println("#####testConstructors | Failed | 0/4 | Constructor definition not found: "
								+ ae.getMessage() + ". #####");
			}

			// Passed for constructor
			marks = count * 10;
			System.out.println("#####testConstructors | Passed | " + marks
					+ "/40 | Checking for constructor.#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testConstructors | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testConstructors | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// Employee

	@Test
	public final void testEmployeeFields() {
		// fail("");

		Field[] fld = COJ_15_Employee.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())) {
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Employee class not defined properly", fc == 5);
			System.out
					.println("#####testEmployeeFields | Passed | 3/3 | Checking for fields in COJ_15_Employee. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testEmployeeFields | Failed | 0/3 | Modified default structure for fields in COJ_15_Employee: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testEmployeeFields | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testEmployeeMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;

			COJ_15_Employee emp = new COJ_15_Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			double expected = bs + hra + da;
			double actual = emp.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testEmployeeMethod | Passed | 3/3 | Checking for COJ_15_Employee calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testEmployeeMethod | Failed | 0/3 | Modified default structure for COJ_15_Employee calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testEmployeeMethod | Failed | 0/3| No such method found in COJ_15_Employee: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testEmployeeMethod | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// Manager
	@Test
	public final void testManagerFields() {
		// fail("");

		Field[] fld = COJ_15_Manager.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						| "projectAllowance".equals(f.getName())) {
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("projectAllowance".equals(f.getName())) {
						assertTrue("Field 'projectAllowance' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Manager class not defined properly", fc == 6);
			System.out
					.println("#####testManagerFields | Passed | 3/3 | Checking for fields in COJ_15_Manager. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testManagerFields | Failed | 0/3 | Modified default structure for fields in COJ_15_Manager: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testManagerFields | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testManagerMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			double pa = 5000;

			COJ_15_Manager mgr = new COJ_15_Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			double expected = bs + hra + da + pa;
			double actual = mgr.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testManagerMethod | Passed | 3/3 | Checking for COJ_15_Manager calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testManagerMethod | Failed | 0/3 | Modified default structure for COJ_15_Manager calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testManagerMethod | Failed | 0/3| No such method found in COJ_15_Manager: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testManagerMethod | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// Trainer
	@Test
	public final void testTrainerFields() {
		// fail("");

		Field[] fld = COJ_15_Trainer.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						|| "perkPerBatch".equals(f.getName())
						|| "batchCount".equals(f.getName())) {
					// System.out.println(f.getType().getName());
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("perkPerBatch".equals(f.getName())) {
						assertTrue("Field 'perkPerBatch' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("batchCount".equals(f.getName())) {
						assertTrue("Field 'batchCount' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Trainer class not defined properly", fc == 7);
			System.out
					.println("#####testTrainerFields | Passed | 3/3 | Checking for fields in COJ_15_Trainer. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testTrainerFields | Failed | 0/3 | Modified default structure for fields in COJ_15_Trainer: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testTrainerFields | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testTrainerMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			int bc = 10;
			double ppb = 50.5;

			COJ_15_Trainer tr = new COJ_15_Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			double expected = bs + hra + da + (ppb * bc);
			double actual = tr.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testTrainerMethod | Passed | 3/3 | Checking for COJ_15_Trainer calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testTrainerMethod | Failed | 0/3 | Modified default structure for COJ_15_Trainer calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTrainerMethod | Failed | 0/3| No such method found in COJ_15_Trainer: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTrainerMethod | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// Sourcing

	@Test
	public final void testSourcingFields() {
		// fail("");

		Field[] fld = COJ_15_Sourcing.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getType().getName());
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						|| "enrollmentTarget".equals(f.getName())
						|| "enrollmentReached".equals(f.getName())
						|| "perkPerEnrollment".equals(f.getName())) {
					// System.out.println(f.getType().getName());
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getType().getName()
										.equals("java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}

					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
					if ("enrollmentTarget".equals(f.getName())) {
						assertTrue("Field 'enrollmentTarget' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}

					if ("enrollmentReached".equals(f.getName())) {
						assertTrue("Field 'enrollmentReached' not defined ", f
								.getType().getName().equals("int"));
						fc++;
					}
					if ("perkPerEnrollment".equals(f.getName())) {
						assertTrue("Field 'perkPerEnrollment' not defined ", f
								.getType().getName()
								.equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Sourcing class not defined properly", fc == 8);
			System.out
					.println("#####testSourcingFields | Passed | 3/3 | Checking for fields in COJ_15_Sourcing. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSourcingFields | Failed | 0/3 | Modified default structure for fields in COJ_15_Sourcing: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			System.out
					.println("#####testSourcingFields | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public final void testSourcingMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			COJ_15_Sourcing src = new COJ_15_Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			double expected = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			double actual = src.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

			System.out
					.println("#####testSourcingMethod | Passed | 3/3 | Checking for COJ_15_Sourcing calculateGrossSalary. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSourcingMethod | Failed | 0/3 | Modified default structure for COJ_15_Sourcing calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSourcingMethod | Failed | 0/3| No such method found in COJ_15_Sourcing: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSourcingMethod | Failed | 0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	// taxutil
	@Test
	public final void testTaxUtilMethod() {
		// fail("");
		try {
			Method[] method = new COJ_15_TaxUtil().getClass()
					.getDeclaredMethods();
			boolean taxMethods = false;
			int count = 0;

			for (Method m : method) {
				if (m.getName().equals("calculateTax"))
					if (m.getParameterTypes()[0].toString().equals(
							"class COJ_15_Employee"))
						count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class COJ_15_Manager"))
					count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class COJ_15_Trainer"))
					count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class COJ_15_Sourcing"))
					count++;
			}
			if (count > 0 && count <= 4) {
				int marks = count * 3;
				System.out
						.println("#####testTaxUtilMethod | Passed | "
								+ marks
								+ "/12 | Checking for calculateTax in COJ_15_TaxUtil. #####");
			}
			if (count == 4)
				taxMethods = true;

			assertTrue("calculateTax() method in COJ_15_TaxUtil not defined",
					taxMethods);

		} catch (AssertionError ae) {
			System.out
					.println("#####testTaxUtilMethod | Failed | 0/12 | Checking for calculateTax in COJ_15_TaxUtil: "
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTaxUtilMethod | Failed | 0/12| No such method found in COJ_15_TaxUtil: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTaxUtilMethod | Failed | 0/12 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public final void testCalculateTaxLess() {
		// fail("");
		try {

			double bs = 15000;
			double hra = 2000;
			double da = 1000;
			double expectedGS = bs + hra + da;
			double totalTax = 0.0;

			COJ_15_TaxUtil tu = new COJ_15_TaxUtil();

			COJ_15_Employee emp = new COJ_15_Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			// Employee

			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(emp));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Employee calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Employee calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");
			}

			// Manager
			double pa = 5000;

			COJ_15_Manager mgr = new COJ_15_Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			expectedGS = bs + hra + da + pa;
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(mgr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Manager calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Manager calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");
			}

			// Trainer

			int bc = 100;
			double ppb = 50.5;

			COJ_15_Trainer tr = new COJ_15_Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			expectedGS = bs + hra + da + (ppb * bc);
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(tr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Trainer calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Trainer calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");
			}

			// Sourcing
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			COJ_15_Sourcing src = new COJ_15_Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			expectedGS = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(src));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Sourcing calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Sourcing calculateTax in COJ_15_TaxUtil for Gross Salary less than 30000. #####");
			}

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20| No such method found in COJ_15_Sourcing: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public final void testCalculateTaxGreater() {
		// fail("");
		try {

			double bs = 35000;
			double hra = 2000;
			double da = 1000;
			double expectedGS = bs + hra + da;
			double totalTax = 0.0;

			COJ_15_TaxUtil tu = new COJ_15_TaxUtil();

			COJ_15_Employee emp = new COJ_15_Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			// Employee

			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(emp));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Employee calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Employee calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");
			}

			// Manager
			double pa = 5000;

			COJ_15_Manager mgr = new COJ_15_Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			expectedGS = bs + hra + da + pa;
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(mgr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Manager calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Manager calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");
			}

			// Trainer

			int bc = 100;
			double ppb = 50.5;

			COJ_15_Trainer tr = new COJ_15_Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			expectedGS = bs + hra + da + (ppb * bc);
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(tr));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Trainer calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Trainer calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");
			}

			// Sourcing
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			COJ_15_Sourcing src = new COJ_15_Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			expectedGS = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(src));

				System.out
						.println("#####testTaxUtilCalculateTax | Passed | 3/3 | Checking for Sourcing calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");

			} catch (AssertionError ae) {
				System.out
						.println("#####testTaxUtilCalculateTax | Failed | 0/3 | Failed for Sourcing calculateTax in COJ_15_TaxUtil for Gross Salary greater than 30000. #####");
			}

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20| No such method found in COJ_15_Sourcing: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testTaxUtilCalculateTax | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
