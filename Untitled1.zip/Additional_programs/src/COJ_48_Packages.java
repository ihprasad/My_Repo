
public class COJ_48_Packages {
	public static void main(String[] args) {
		
	}

}
