
public class COJ_15_Constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}

//Class Employee

class COJ_15_Employee {

	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	
	public COJ_15_Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_15_Employee(int id, String name, double basicSalary,
			double hRAPer, double dAPer) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
	}

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer;
	}

}


//Class Manager
class COJ_15_Manager {
	
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	double projectAllowance;

	public COJ_15_Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_15_Manager(int id, String name, double basicSalary,
			double hRAPer, double dAPer, double projectAllowance) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.projectAllowance = projectAllowance;
	}

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer + projectAllowance;
	}

}


//Trainer
class COJ_15_Trainer {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int batchCount;
	double perkPerBatch;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer
				+ ((double) batchCount * perkPerBatch);
	}

	public COJ_15_Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_15_Trainer(int id, String name, double basicSalary,
			double hRAPer, double dAPer, int batchCount, double perkPerBatch) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.batchCount = batchCount;
		this.perkPerBatch = perkPerBatch;
	}

}

//Sourcing

class COJ_15_Sourcing {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;

	public double calculateGrossSalary() {
		return basicSalary
				+ HRAPer
				+ DAPer
				+ ((((double) enrollmentReached / (double) enrollmentTarget) * 100) * perkPerEnrollment);
	}

	public COJ_15_Sourcing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public COJ_15_Sourcing(int id, String name, double basicSalary,
			double hRAPer, double dAPer, int enrollmentTarget,
			int enrollmentReached, double perkPerEnrollment) {
		super();
		this.id = id;
		this.name = name;
		this.basicSalary = basicSalary;
		HRAPer = hRAPer;
		DAPer = dAPer;
		this.enrollmentTarget = enrollmentTarget;
		this.enrollmentReached = enrollmentReached;
		this.perkPerEnrollment = perkPerEnrollment;
	}

}

//Class TaxUtil

class COJ_15_TaxUtil {

	double calculateTax(COJ_15_Employee emp) {
		if (emp.calculateGrossSalary() > 30000)
			return emp.calculateGrossSalary() * 0.2;
		else
			return emp.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_15_Manager mgr) {
		if (mgr.calculateGrossSalary() > 30000)
			return mgr.calculateGrossSalary() * 0.2;
		else
			return mgr.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_15_Trainer tr) {
		if (tr.calculateGrossSalary() > 30000)
			return tr.calculateGrossSalary() * 0.2;
		else
			return tr.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_15_Sourcing scr) {
		if (scr.calculateGrossSalary() > 30000)
			return scr.calculateGrossSalary() * 0.2;
		else
			return scr.calculateGrossSalary() * 0.05;
	}

}

