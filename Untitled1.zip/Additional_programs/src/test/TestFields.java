package test;

import java.lang.reflect.Field;

import com.talentsprint.employeepayrollsystem.client.Organization;

import static org.junit.Assert.*;


public class TestFields {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testOrganizationFields();
	}
	
	public static void testOrganizationFields() {
		Field[] fld = new Organization().getClass().getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// System.out.println(f.getGenericType().toString() + " " +
				// f.getName());
				// System.out.println(f.getType().getName());
				assertTrue(
						f.getName(),
						("noOfEmployees".equals(f.getName())
								|| "name".equals(f.getName()) || "employeeList"
								.equals(f.getName())));
				if ("noOfEmployees".equals(f.getName())) {
					assertTrue("Field 'noOfEmployees' not defined ", f
							.getGenericType().toString().equals("int"));
					fc++;
				}

				if ("name".equals(f.getName())) {
					assertTrue("Field 'name' not defined ", f.getGenericType()
							.toString().equals("class java.lang.String"));
					fc++;
				}
				System.out.println("field --- " + f.getGenericType().toString());

				if ("employeeList".equals(f.getName())) {
					assertTrue(
							"Field 'employeeList' not defined ",
							f.getGenericType().toString()
									.equals("class [LEmployee;"));
					fc++;
				}

			}

			System.out.println("#####testOrganizationFields|Passed|" + fc
					+ "/3|Checking for fields in Organization. #####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testOrganizationFields|Failed|0/3| Field not defined in Organization: "
							+ ae.getMessage() + " #####");
		} catch (Exception e) {
			System.out
					.println("#####testOrganizationFields|Failed|0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
