package test;
public class COJ_14_CO_Employee {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer;
	}

}

class COJ_14_CO_Manager {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	double projectAllowance;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer + projectAllowance;
	}

}

class COJ_14_CO_Trainer {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int batchCount;
	double perkPerBatch;

	public double calculateGrossSalary() {
		return basicSalary + HRAPer + DAPer
				+ ((double) batchCount * perkPerBatch);
	}

}

class COJ_14_CO_Sourcing {
	int id;
	String name;
	double basicSalary;
	double HRAPer;
	double DAPer;
	int enrollmentTarget;
	int enrollmentReached;
	double perkPerEnrollment;

	public double calculateGrossSalary() {
		return basicSalary
				+ HRAPer
				+ DAPer
				+ ((((double) enrollmentReached / (double) enrollmentTarget) * 100) * perkPerEnrollment);
	}

}

class COJ_14_CO_TaxUtil {

	double calculateTax(COJ_14_CO_Employee emp) {
		if (emp.calculateGrossSalary() > 30000)
			return emp.calculateGrossSalary() * 0.2;
		else
			return emp.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_14_CO_Manager mgr) {
		if (mgr.calculateGrossSalary() > 30000)
			return mgr.calculateGrossSalary() * 0.2;
		else
			return mgr.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_14_CO_Trainer tr) {
		if (tr.calculateGrossSalary() > 30000)
			return tr.calculateGrossSalary() * 0.2;
		else
			return tr.calculateGrossSalary() * 0.05;
	}

	double calculateTax(COJ_14_CO_Sourcing scr) {
		if (scr.calculateGrossSalary() > 30000)
			return scr.calculateGrossSalary() * 0.2;
		else
			return scr.calculateGrossSalary() * 0.05;
	}

}
