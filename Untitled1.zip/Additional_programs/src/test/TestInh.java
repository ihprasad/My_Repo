package test;

public class TestInh {
	
	public static void main(String[] args) {
		SuperClass sb = new subClass();
		sb.test();
	}

}

class SuperClass {
	public void test() {
		System.out.println("Super Test");
	}
}

class subClass extends SuperClass {
	
	public void test() {
		System.out.println("Sub Test");
	}

}
