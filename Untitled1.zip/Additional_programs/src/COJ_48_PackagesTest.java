import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.talentsprint.employeepayrollsystem.client.Organization;
import com.talentsprint.employeepayrollsystem.entity.Employee;
import com.talentsprint.employeepayrollsystem.entity.Manager;
import com.talentsprint.employeepayrollsystem.entity.Sourcing;
import com.talentsprint.employeepayrollsystem.entity.Trainer;
import com.talentsprint.employeepayrollsystem.util.TaxUtil;


public class COJ_48_PackagesTest extends TestCase{

	static {
		try {
			Class.forName("com.talentsprint.employeepayrollsystem.entity.Employee");
			Class.forName("com.talentsprint.employeepayrollsystem.entity.Trainer");
			Class.forName("com.talentsprint.employeepayrollsystem.entity.Sourcing");
			Class.forName("com.talentsprint.employeepayrollsystem.entity.Manager");
			Class.forName("com.talentsprint.employeepayrollsystem.util.TaxUtil");
			Class.forName("com.talentsprint.employeepayrollsystem.client.Organization");
		} catch (ClassNotFoundException ce) {
			System.out
					.println("#####testClassDefinitions|Failed|0/100|Class not found: "
							+ ce.getMessage() + ".#####");
			System.exit(0);
		}

		COJ_48_PackagesTest s = new COJ_48_PackagesTest();

		s.testConstructors();
		s.testEmployeeFields();
		s.testEmployeeMethod();
		s.testManagerFields();
		s.testManagerMethod();
		s.testTrainerFields();
		s.testTrainerMethod();
		s.testSourcingFields();
		s.testSourcingMethod();
		s.testTaxUtilMethod();
		s.testCalculateTaxGreater();
		s.testCalculateTaxLess();

	}

	static Organization obj = new Organization();

	static Employee emp1, emp2, emp3, emp4, emp5, emp6, emp7, emp8,
			emp9, emp10, emp11, emp12, emp18;

	int result;

	static int c = 0;

	PrintStream originalOut = System.out;
	OutputStream os = new ByteArrayOutputStream();
	PrintStream ps = new PrintStream(os);

	static Organization obj1 = new Organization();
	static Employee emp19 = new Employee(412, "Ramana rao",
			10000, 5000, 2000);

	@BeforeClass
	protected void setUp() throws Exception {
		super.setUp();
		obj = new Organization();
		System.setOut(ps);

	}

	@After
	public void cleanUpStreams() {
		// Restore normal operation
		System.setOut(originalOut);

		System.setOut(null);
		System.setErr(null);

	}

	// @Test
	public void testConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for employee

			cons = new Employee().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public com.talentsprint.employeepayrollsystem.entity.Employee(int,java.lang.String,double,double,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue("Employee(int, String, double, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
				System.exit(0);

			}

			// constructor for manager
			cons = new Manager().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public com.talentsprint.employeepayrollsystem.entity.Manager(int,java.lang.String,double,double,double,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue(
						"Manager(int, String, double, double, double, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}

			// constructor for Trainer
			cons = new Trainer().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public com.talentsprint.employeepayrollsystem.entity.Trainer(int,java.lang.String,double,double,double,int,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue(
						"Trainer(int, String, double, double, double,int, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}
			// constructor for Sourcing
			cons = new Sourcing().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString()
						.equals("public com.talentsprint.employeepayrollsystem.entity.Sourcing(int,java.lang.String,double,double,double,int,int,double)")) {
					found = true;
					break;
				}
			}
			try {
				assertTrue(
						"Sourcing(int, String, double, double, double,int, int, double) ",
						found);
				count++;
				found = false;

			} catch (AssertionError ae) {
				originalOut
						.println("#####testConstructors|Failed|0/100|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
				System.exit(0);
			}

			// Passed for constructor
			marks = count * 10;

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testConstructors|Failed|0/100|No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testConstructors|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	// Employee

	// @Test
	public final void testEmployeeFields() {
		// fail("");

		Field[] fld = Employee.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// originalOut.println(f.getGenericType().toString());
				// originalOut.println(f.getName());
				// originalOut.println(fc);
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())) {

					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ====",
								f.getGenericType().toString()
										.equals("class java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
				}
			}

			assertTrue("Fields in Employee class not defined properly", fc == 5);
			// originalOut
			// .println("#####testEmployeeFields|Passed|3/3|Checking for fields in Employee. #####");
			// System.exit(0);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testEmployeeFields|Failed|0/100|Modified default structure for fields in Employee: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (Exception e) {
			originalOut
					.println("#####testEmployeeFields|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	// @Test
	public final void testEmployeeMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;

			Employee emp = new Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			double expected = bs + hra + da;
			double actual = emp.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testEmployeeMethod|Failed|0/100|Modified default structure for Employee calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testEmployeeMethod|Failed|0/100| No such method found in Employee: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testEmployeeMethod|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	// Manager
	// @Test
	public final void testManagerFields() {
		// fail("");

		Field[] fld = Manager.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						| "projectAllowance".equals(f.getName())) {
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getGenericType().toString()
										.equals("class java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("projectAllowance".equals(f.getName())) {
						assertTrue("Field 'projectAllowance' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Manager class not defined properly", fc == 6);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testManagerFields|Failed|0/100|Modified default structure for fields in Manager: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (Exception e) {
			originalOut
					.println("#####testManagerFields|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	// @Test
	public final void testManagerMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			double pa = 5000;

			Manager mgr = new Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			double expected = bs + hra + da + pa;
			double actual = mgr.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testManagerMethod|Failed|0/100|Modified default structure for Manager calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testManagerMethod|Failed|0/100| No such method found in Manager: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testManagerMethod|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	// Trainer
	// @Test
	public final void testTrainerFields() {
		// fail("");

		Field[] fld = Trainer.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						|| "perkPerBatch".equals(f.getName())
						|| "batchCount".equals(f.getName())) {
					// originalOut.println(f.getGenericType());
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getGenericType().toString()
										.equals("class java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("perkPerBatch".equals(f.getName())) {
						assertTrue("Field 'perkPerBatch' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("batchCount".equals(f.getName())) {
						assertTrue("Field 'batchCount' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Trainer class not defined properly", fc == 7);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testTrainerFields|Failed|0/100|Modified default structure for fields in Trainer: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (Exception e) {
			originalOut
					.println("#####testTrainerFields|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	// @Test
	public final void testTrainerMethod() {
		// fail("");
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			int bc = 10;
			double ppb = 50.5;

			Trainer tr = new Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			double expected = bs + hra + da + (ppb * bc);
			double actual = tr.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testTrainerMethod|Failed|0/100|Modified default structure for Trainer calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testTrainerMethod|Failed|0/100| No such method found in Trainer: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testTrainerMethod|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	// Sourcing

	// @Test
	public final void testSourcingFields() {
		Field[] fld = Sourcing.class.getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				if ("id".equals(f.getName()) || "name".equals(f.getName())
						|| "basicSalary".equals(f.getName())
						|| "HRAPer".equals(f.getName())
						|| "DAPer".equals(f.getName())
						|| "enrollmentTarget".equals(f.getName())
						|| "enrollmentReached".equals(f.getName())
						|| "perkPerEnrollment".equals(f.getName())) {
					if ("id".equals(f.getName())) {
						assertTrue("Field 'id' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}

					if ("name".equals(f.getName())) {
						assertTrue(
								"Field 'name' not defined ",
								f.getGenericType().toString()
										.equals("class java.lang.String"));
						fc++;
					}

					if ("basicSalary".equals(f.getName())) {
						assertTrue("Field 'basicSalary' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}

					if ("HRAPer".equals(f.getName())) {
						assertTrue("Field 'HRAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("DAPer".equals(f.getName())) {
						assertTrue("Field 'DAPer' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
					if ("enrollmentTarget".equals(f.getName())) {
						assertTrue("Field 'enrollmentTarget' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}

					if ("enrollmentReached".equals(f.getName())) {
						assertTrue("Field 'enrollmentReached' not defined ", f
								.getGenericType().toString().equals("int"));
						fc++;
					}
					if ("perkPerEnrollment".equals(f.getName())) {
						assertTrue("Field 'perkPerEnrollment' not defined ", f
								.getGenericType().toString().equals("double"));
						fc++;
					}
				}
			}
			assertTrue("Fields in Sourcing class not defined properly", fc == 8);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testSourcingFields|Failed|0/100|Modified default structure for fields in Sourcing: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (Exception e) {
			originalOut
					.println("#####testSourcingFields|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	// @Test
	public final void testSourcingMethod() {
		try {

			double bs = 25000;
			double hra = 2000;
			double da = 1000;
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			Sourcing src = new Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			double expected = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			double actual = src.calculateGrossSalary();

			assertTrue("Incorrect output.", expected == actual);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testSourcingMethod|Failed|0/100|Modified default structure for Sourcing calculateGrossSalary Method: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testSourcingMethod|Failed|0/100| No such method found in Sourcing: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testSourcingMethod|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	// taxutil
	// @Test
	public final void testTaxUtilMethod() {
		// fail("");
		try {
			Method[] method = new TaxUtil().getClass()
					.getDeclaredMethods();
			boolean taxMethods = false;
			int count = 0;

			for (Method m : method) {
				if (m.getName().equals("calculateTax"))
					if (m.getParameterTypes()[0].toString().equals(
							"class com.talentsprint.employeepayrollsystem.entity.Employee"))
						count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class com.talentsprint.employeepayrollsystem.entity.Manager"))
					count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class com.talentsprint.employeepayrollsystem.entity.Trainer"))
					count++;
				if (m.getParameterTypes()[0].toString().equals(
						"class com.talentsprint.employeepayrollsystem.entity.Sourcing"))
					count++;
			}

			if (count == 4)
				taxMethods = true;

			assertTrue("calculateTax() method in TaxUtil not defined",
					taxMethods);

		} catch (AssertionError ae) {
			originalOut
					.println("#####testTaxUtilMethod|Failed|0/100|Checking for calculateTax in TaxUtil: "
							+ ae.getMessage() + "#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testTaxUtilMethod|Failed|0/100| No such method found in TaxUtil: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testTaxUtilMethod|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	// @Test
	public final void testCalculateTaxLess() {
		// fail("");
		try {

			double bs = 15000;
			double hra = 2000;
			double da = 1000;
			double expectedGS = bs + hra + da;
			double totalTax = 0.0;

			TaxUtil tu = new TaxUtil();

			Employee emp = new Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			// Employee

			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(emp));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Employee calculateTax in TaxUtil for Gross Salary less than 30000. #####");
				System.exit(0);
			}

			// Manager
			double pa = 5000;

			Manager mgr = new Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			expectedGS = bs + hra + da + pa;
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(mgr));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Manager calculateTax in TaxUtil for Gross Salary less than 30000. #####");
				System.exit(0);
			}

			// Trainer

			int bc = 100;
			double ppb = 50.5;

			Trainer tr = new Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			expectedGS = bs + hra + da + (ppb * bc);
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(tr));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Trainer calculateTax in TaxUtil for Gross Salary less than 30000. #####");
				System.exit(0);
			}

			// Sourcing
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			Sourcing src = new Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			expectedGS = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			totalTax = expectedGS * 0.05;
			try {
				assertTrue(totalTax == tu.calculateTax(src));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Sourcing calculateTax in TaxUtil for Gross Salary less than 30000. #####");
				System.exit(0);
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testTaxUtilCalculateTax|Failed|0/100| No such method found in Sourcing: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testTaxUtilCalculateTax|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	// @Test
	public final void testCalculateTaxGreater() {
		// fail("");
		try {

			double bs = 35000;
			double hra = 2000;
			double da = 1000;
			double expectedGS = bs + hra + da;
			double totalTax = 0.0;

			TaxUtil tu = new TaxUtil();

			Employee emp = new Employee();
			emp.basicSalary = bs;
			emp.HRAPer = hra;
			emp.DAPer = da;

			// Employee

			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(emp));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Employee calculateTax in TaxUtil for Gross Salary greater than 30000. #####");
				System.exit(0);
			}

			// Manager
			double pa = 5000;

			Manager mgr = new Manager();
			mgr.basicSalary = bs;
			mgr.HRAPer = hra;
			mgr.DAPer = da;
			mgr.projectAllowance = pa;

			expectedGS = bs + hra + da + pa;
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(mgr));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Manager calculateTax in TaxUtil for Gross Salary greater than 30000. #####");
				System.exit(0);
			}

			// Trainer

			int bc = 100;
			double ppb = 50.5;

			Trainer tr = new Trainer();
			tr.basicSalary = bs;
			tr.HRAPer = hra;
			tr.DAPer = da;
			tr.perkPerBatch = ppb;
			tr.batchCount = bc;

			expectedGS = bs + hra + da + (ppb * bc);
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(tr));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Trainer calculateTax in TaxUtil for Gross Salary greater than 30000. #####");
				System.exit(0);
			}

			// Sourcing
			int er = 10;
			int et = 20;
			double ppe = 50.5;

			Sourcing src = new Sourcing();
			src.basicSalary = bs;
			src.HRAPer = hra;
			src.DAPer = da;
			src.perkPerEnrollment = ppe;
			src.enrollmentReached = er;
			src.enrollmentTarget = et;

			expectedGS = bs + hra + da
					+ ((((double) er / (double) et) * 100) * ppe);
			totalTax = expectedGS * 0.2;
			try {
				assertTrue(totalTax == tu.calculateTax(src));

			} catch (AssertionError ae) {
				originalOut
						.println("#####testTaxUtilCalculateTax|Failed|0/100|Failed for Sourcing calculateTax in TaxUtil for Gross Salary greater than 30000. #####");
				System.exit(0);
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testTaxUtilCalculateTax|Failed|0/100| No such method found in Sourcing: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			originalOut
					.println("#####testTaxUtilCalculateTax|Failed|0/100 |Runtime Exception:"
							+ e.getMessage() + "#####");
			System.exit(0);
		}

	}

	// @Test
	public void testPrintEmployees() {

		try {
			obj1.addEmployee(emp19);
			Employee emp20 = new Employee(1121, "Ramana rao",
					10000, 5000, 2000);
			obj1.addEmployee(emp20);
			obj1.printAllEmployees();
			// originalOut.println("*********"+os.toString());
			assertEquals(
					"id, name, basicSalary, HRAPer, DAPer\n412, Ramana rao, 10000.0, 5000.0, 2000.0\n1121, Ramana rao, 10000.0, 5000.0, 2000.0\n",
					os.toString());
			originalOut
					.println("#####testPrintEmployees|Passed|10/10|Passed for printing employee details. #####");
			// originalOut.println("null++");
		} catch (AssertionError e) {
			System.out
					.println("#####testPrintEmployees|Failed|0/10|Failed for printing employee details: "
							+ e.getMessage() + ". #####");
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testOrgConstructor|Failed|0/10|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testOrgConstructor|Failed|0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// @Test
	public void testOrgConstructor() {
		// constructor for Organization

		Constructor[] cons;
		boolean found = false;
		// boolean accessible = false;

		try {
			Organization org1 = new Organization();
			cons = org1.getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals("public com.talentsprint.employeepayrollsystem.client.Organization()")) {
					if (org1.employeeList != null
							&& org1.employeeList.length == 10
							&& org1.noOfEmployees == 0) {
						found = true;
					}

					break;
				}
			}
			// obj.noOfEmployees = 0;
			try {
				assertTrue("Organization() ", found);
				originalOut
						.println("#####testOrgConstructor|Passed|7/7|Checking for constructor.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testOrgConstructor|Failed|0/7|Constructor definition not found: "
								+ ae.getMessage() + ". #####");
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testOrgConstructor|Failed|0/7|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testOrgConstructor|Failed|0/7 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	void addEmp() {
		setObj();

		obj.addEmployee(emp1);

		obj.addEmployee(emp2);

		obj.addEmployee(emp3);

		obj.addEmployee(emp4);

		obj.addEmployee(emp5);

		obj.addEmployee(emp6);

		obj.addEmployee(emp7);

		obj.addEmployee(emp8);

		obj.addEmployee(emp9);

		obj.addEmployee(emp10);

		obj.addEmployee(emp11);

		obj.addEmployee(emp12);

	}

	// @Test
	public void testSearchEmployeeByName() {
		try {
			addEmp();
			try {
				assertNull(obj.searchEmployeeByName("ee"));

				originalOut
						.println("#####testSearchEmployeeByName|Passed|5/5|Passed for searchEmployeeByName method with employee not exist. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testSearchEmployeeByName|Failed|0/5|Failed for searchEmployeeByName method employee not exist: "
								+ ae.getMessage() + "#####");
			}

			try {
				assertEquals(new Employee().getClass().getName(),
						(obj.searchEmployeeByName("HAri")).getClass().getName());

				originalOut
						.println("#####testSearchEmployeeByName|Passed|5/5|Passed for searchEmployeeByName method with employee exist. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testSearchEmployeeByName|Failed|0/5|Failed for searchEmployeeByName method with employee exist: "
								+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testSearchEmployeeByName|Failed|0/10| No such method found in Organization: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testSearchEmployeeByName|Failed|0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// @Test
	public void testSearchEmployeeById() {
		try {
			addEmp();
			try {
				assertNull(obj.getEmployeeById(555));

				originalOut
						.println("#####testSearchEmployeeById|Passed|5/5|Passed for getEmployeeById method with employee not exist. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testSearchEmployeeById|Failed|0/5|Failed for getEmployeeById method employee not exist: "
								+ ae.getMessage() + "#####");
			}

			try {
				assertEquals(new Employee().getClass().getName(),
						(obj.getEmployeeById(108)).getClass().getName());

				originalOut
						.println("#####testSearchEmployeeById|Passed|5/5|Passed for getEmployeeById method with employee exist. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testSearchEmployeeById|Failed|0/5|Failed for getEmployeeById method with employee exist: "
								+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testSearchEmployeeById|Failed|0/10| No such method found in Organization: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testSearchEmployeeById|Failed|0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	// @Test
	public void testOrganizationFields() {
		Field[] fld = new Organization().getClass().getDeclaredFields();
		int fc = 0;
		try {
			for (Field f : fld) {
				// originalOut.println(f.getGenericType().toString() + " " +
				// f.getName());
				// originalOut.println(f.getType().getName());
				assertTrue(
						f.getName(),
						("noOfEmployees".equals(f.getName())
								|| "name".equals(f.getName()) || "employeeList"
								.equals(f.getName())));
				if ("noOfEmployees".equals(f.getName())) {
					assertTrue("Field 'noOfEmployees' not defined ", f
							.getGenericType().toString().equals("int"));
					fc++;
				}

				if ("name".equals(f.getName())) {
					assertTrue("Field 'name' not defined ", f.getGenericType()
							.toString().equals("class java.lang.String"));
					fc++;
				}
				System.out.println(f.getGenericType().toString());

				if ("employeeList".equals(f.getName())) {
					assertTrue(
							"Field 'employeeList' not defined ",
							f.getGenericType().toString()
									.equals("class [Lcom.talentsprint.employeepayrollsystem.entity.Employee;"));
					fc++;
				}

			}

			originalOut.println("#####testOrganizationFields|Passed|" + fc
					+ "/3|Checking for fields in Organization. #####");

		} catch (AssertionError ae) {
			originalOut
					.println("#####testOrganizationFields|Failed|0/3| Field not defined in Organization: "
							+ ae.getMessage() + " #####");
		} catch (Exception e) {
			originalOut
					.println("#####testOrganizationFields|Failed|0/3 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	public void setObj() {
		emp1 = new Employee(101, "Srinu", 10000, 5000, 2000);
		emp2 = new Employee(102, "Prasad", 10000, 5000, 2000);
		emp3 = new Employee(102, "Priyanka", 10000, 5000, 2000);
		emp4 = new Employee(103, "Shruti", 10000, 5000, 2000);
		emp5 = new Employee(108, "Hari priya", 10000, 5000, 2000);
		emp6 = new Employee(105, "Hari", 10000, 5000, 2000);
		emp7 = new Employee(106, "Rajanikanth", 10000, 5000, 2000);
		emp8 = new Employee(107, "Sneha", 10000, 5000, 2000);
		emp9 = new Employee(109, "Ravi", 10000, 5000, 2000);
		emp10 = new Employee(110, "Ram kumar", 10000, 5000, 2000);
		emp11 = new Employee(111, "Srinivas", 10000, 5000, 2000);
		emp12 = new Employee(112, "Ramana", 10000, 5000, 2000);
	}

	// @Test
	public void testAddEmployee() {

		obj.noOfEmployees = 0;
		setObj();

		try {

			// Adding first employee.
			try {

				result = obj.addEmployee(emp1);

				assertTrue(
						"Failed to add first employee with addEmployee method in Organization",
						result == 0);

				originalOut
						.println("#####testAddEmployee|Passed|10/10|Passed to add first employee with addEmployee method in Organization. #####");

			} catch (AssertionError ae) {
				originalOut.println("#####testAddEmployee|Failed|0/10 |"
						+ ae.getMessage() + "#####");
			}

			// Adding multiple employees less than 10
			try {
				assertTrue(obj.addEmployee(emp2) == 0);

				originalOut
						.println("#####testAddEmployee|Passed|10/10|Passed to add multiple employees with addEmployee method in Organization. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testAddEmployee|Failed|0/10|Failed to add multiple employees with addEmployee method in Organization: "
								+ ae.getMessage() + "#####");
			}

			// Adding duplicate employees
			try {

				assertTrue(obj.addEmployee(emp3) == -2);

				originalOut
						.println("#####testAddEmployee|Passed|10/10|Passed to add duplicate employees with addEmployee method in Organization. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testAddEmployee|Failed|0/10|Failed to add duplicate employees with addEmployee method in Organization: "
								+ ae.getMessage() + "#####");
			}
			// Adding multiple employees greater than 10
			try {

				assertTrue(obj.addEmployee(emp4) == 0);

				assertTrue(obj.addEmployee(emp5) == 0);

				assertTrue(obj.addEmployee(emp6) == 0);

				assertTrue(obj.addEmployee(emp7) == 0);

				assertTrue(obj.addEmployee(emp8) == 0);

				assertTrue(obj.addEmployee(emp9) == 0);

				assertTrue(obj.addEmployee(emp10) == 0);

				assertTrue(obj.addEmployee(emp11) == 0);

				assertTrue(obj.addEmployee(emp12) == -1);

				originalOut
						.println("#####testAddEmployee|Passed|10/10|Passed to add multiple employees more than 10 with addEmployee method in Organization. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testAddEmployee|Failed|0/10|Failed to add multiple employees more than 10 with addEmployee method in Organization: "
								+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testAddEmployee|Failed|0/40| No such method found in Organization: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testAddEmployee|Failed|0/40 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDeleteEmployee() {
		try {
			addEmp();
			try {
				assertTrue(obj.deleteEmployee(103));
				originalOut
						.println("#####testDeleteEmployee|Passed|5/5|Passed for delete an exist employee. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testDeleteEmployee|Failed|0/5|Failed to delete an exist employee.#####");
			}
			try {
				assertFalse(obj.deleteEmployee(1003));
				originalOut
						.println("#####testDeleteEmployee|Passed|5/5|Passed for delete a non-exist employee. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testDeleteEmployee|Failed|0/5|Failed to delete a non-exist employee.#####");
			}
			String afterDelete = "id, name, basicSalary, HRAPer, DAPer\n101, Srinu, 10000.0, 5000.0, 2000.0\n102, Prasad, 10000.0, 5000.0, 2000.0\n108, Hari priya, 10000.0, 5000.0, 2000.0\n105, Hari, 10000.0, 5000.0, 2000.0\n106, Rajanikanth, 10000.0, 5000.0, 2000.0\n107, Sneha, 10000.0, 5000.0, 2000.0\n109, Ravi, 10000.0, 5000.0, 2000.0\n110, Ram kumar, 10000.0, 5000.0, 2000.0\n111, Srinivas, 10000.0, 5000.0, 2000.0\n";
			
			try {
				obj.printAllEmployees();
				assertEquals(afterDelete, os.toString());
				originalOut
						.println("#####testDeleteEmployee|Passed|10/10|Passed for re-arranging employeeList. #####");

			} catch (AssertionError ae) {
				originalOut
						.println("#####testDeleteEmployee|Failed|0/10|Failed to re-arranging employeeList.#####");
			}
		
		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testDeleteEmployee|Failed|0/20| No such method found in Organization: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			originalOut
					.println("#####testDeleteEmployee|Failed|0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

}
