class ECC_39_OccurrenceCounter {

	public static void main(String[] arg) {
		System.out.println(getCount(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 },
				7));
		System.out.println(getCount(null, 7));
		System.out
				.println(getCount(new int[] { 1, 3, 4, 5, 6, 7, 8, 9, 0 }, 2));
		System.out.println(getCount(new int[] { 8, 8, 8, 8, 8 }, 8));
	}

	public static int getCount(int[] inputArray, int number) {
		int count = 0;
		if (inputArray == null)
			return -1;

		for (int indx = 0; indx < inputArray.length; indx++) {
			if (inputArray[indx] == number)
				count++;

		}

		return count;
	}
}