import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_45_GenerateOddPalindromeTest {

	@Test
	public void getPalindromeTest() {
		try
		{
			assertEquals("101,111,121,131,141,151,161,171,181,191",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(100,200));
			System.out.println("#####GenerateOddPalindromeTest | Passed | 40/40 | Passed for GenerateOddPalindrome test#####");

		} catch (AssertionError e) {
			System.out
			.println("#####GenerateOddPalindromeTest | Failed | 0/40 | Failed for GenerateOddPalindrome test#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####GenerateOddPalindromeTest | Failed | 0/40 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####GenerateOddPalindromeTest | Failed | 0/40 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void getPalindromeNegativeTest() {
		try
		{
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(-125,250));
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(125,-250));
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(-125,-250));
			System.out.println("#####GenerateOddPalindromeNegativeTest | Passed | 10/10 | Passed for Negative input#####");

		} catch (AssertionError e) {
			System.out
			.println("#####GenerateOddPalindromeNegativeTest | Failed | 0/10 | Failed for negative input#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####GenerateOddPalindromeNegativeTest | Failed | 0/10 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####GenerateOddPalindromeNegativeTest | Failed | 0/10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}
	
	@Test
	public void getPalindromeZeroTest() {
		try
		{
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(0,125));
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(0,0));
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(125,0));
			System.out.println("#####GenerateOddPalindromeZeroTest | Passed | 30/30 | Passed for GenerateOddPalindromeZero input#####");

		} catch (AssertionError e) {
			System.out
			.println("#####GenerateOddPalindromeZeroTest | Failed | 0/30 | Failed for GenerateOddPalindromeZero input#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####GenerateOddPalindromeZeroTest | Failed | 0/30 | No such method found#####");

		} catch (Exception e) {
			System.out
			.println("#####GenerateOddPalindromeZeroTest | Failed | 0/10 |Runtime Exception:"+ e.getMessage()+"#####");
		}
}

	@Test
	public void getPalindromeInputRangeTest() {
		try
		{
			assertEquals("Error",new ECC_45_GenerateOddPalindrome().getOddPalindromeList(200,100));
			System.out.println("#####GenerateOddPalindromeInputRangeTest | Passed | 20/20 | Passed for GenerateOddPalindromeInputRangeTest#####");

		} catch (AssertionError e) {
			System.out
			.println("#####GenerateOddPalindromeInputRangeTest | Failed | 0/20 | Failed for GenerateOddPalindromeInputRangeTest#####");
		} catch (NoSuchMethodError e) {
			System.out
			.println("#####GenerateOddPalindromeInputRangeTest | Failed | 0/20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####GenerateOddPalindromeInputRangeTest | Failed | 0/20 |Runtime Exception:"+ e.getMessage()+"#####");
		}
	}

}
