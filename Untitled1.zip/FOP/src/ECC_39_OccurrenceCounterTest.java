import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_39_OccurrenceCounterTest {

	@Test
	public void testGetCount(){
		try{
			assertEquals(1, ECC_39_OccurrenceCounter.getCount(new int[]{1,2,3,4,5,6,7,8,9,0}, 7));
			assertEquals(2, ECC_39_OccurrenceCounter.getCount(new int[]{1,2,3,4,5,6,7,7,9,0}, 7));
			assertEquals(5, ECC_39_OccurrenceCounter.getCount(new int[]{8,8,8,8,8}, 8));
			
			System.out.println("#####ECC_39_OccurrenceCounterTest | Passed | 40 / 40 | Passed for 1 or more occrrences #####");

		} catch (AssertionError e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 40 | Failed for 1 or more occrrences#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 40 | Failed could not find method getCount(int[], int)#####");
		} catch (Exception e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 40 | Failed RuntimeError#####" + e.getMessage());
		} 
				
	}

	@Test
	public void testNull(){
		try{
			assertEquals(-1, ECC_39_OccurrenceCounter.getCount(null, 7));
			
			
			System.out.println("#####ECC_39_OccurrenceCounterTest | Passed | 30 / 30 | Passed for null input#####");

		} catch (AssertionError e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 30 | Failed for null input#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 30 | Failed could not find method getCount(int[], int)#####");
		} catch (Exception e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 30 | Failed RuntimeError#####" + e.getMessage());
		} 
				
	}

	@Test
	public void testZeroOutput(){
		try{
			assertEquals(0, ECC_39_OccurrenceCounter.getCount(new int[]{1,3,4,5,6,7,8,9,0}, 2));
			
			System.out.println("#####ECC_39_OccurrenceCounterTest | Passed | 30 / 30 | Passed for zero occurrence#####");

		} catch (AssertionError e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 30 | Failed for zero occurrence#####");
		} catch (NoSuchMethodError e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 30 | Failed could not find method getCount(int[], int)#####");
		} catch (Exception e) {
			System.out.println("#####ECC_39_OccurrenceCounterTest | Failed | 0 / 30 | Failed RuntimeError#####" + e.getMessage());
		} 
				
	}
}
