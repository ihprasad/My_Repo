public class ECC_50_CricketScores {

	public static String getDisplayDetails(int runs, float overs) {
		int balls = 0, temp = 0;
		String res = "";
		temp = (int) (overs * 10);
		balls = ((temp / 10) * 6) + (temp % 10);
		float avg = (float) runs / balls;
		if (runs <= 100 || balls <= 100) {
			// avg = ((float)((int) (avg * 100))) / 100;
			String aavgg = String.format("%4.2f", avg);
			res = runs + " runs in " + balls + " balls @ " + aavgg
					+ " runs per ball";
			return res;
		} else if (balls > 100 && runs > 100) {
			avg = avg * 6;
			// avg = ((float)((int) (avg * 100))) / 100;
			String aavgg = String.format("%4.2f", avg);
			res = runs + " runs in " + overs + " overs @ " + aavgg
					+ " runs per over";
			return res;
		}
		return res;
	}

	public static void main(String[] args) {
		System.out.println(new ECC_50_CricketScores().getDisplayDetails(30,
				2.1f));
	}
}
