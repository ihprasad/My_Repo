public class ECC_45_GenerateOddPalindrome {

	/**
	 * @param args
	 */

	public static String getOddPalindromeList(int startNum, int endNum) {

		String s = "";
		int j, k, rev, rem;
		if (startNum < 100 || startNum >= 999 || endNum < 100 || endNum >= 999
				|| startNum > endNum) {
			return "Error";
		} else {
			for (int i = startNum, x = 1; i <= endNum; i++, x++) {
				// System.out.println("x="+x);
				// System.out.println(x+"==="+startNum+",  "+endNum);
				k = j = i;
				rev = 0;
				rem = 0;
				while (j > 0) {
					rem = j % 10;
					rev = rev * 10 + rem;
					j = j / 10;
				}
				if (rev == k && rev % 2 == 1) {
					if (s.equals(""))
						s = k + "";
					else
						s = s + "," + k;
				}

				// if(x==3)
				// break;
			}

			return s;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int startNumber = Integer.parseInt(args[0]);
		int endNumber = Integer.parseInt(args[1]);
		ECC_45_GenerateOddPalindrome op = new ECC_45_GenerateOddPalindrome();
		System.out.print(op.getOddPalindromeList(startNumber, endNumber));

	}
}