public class ECC_38_FillMultiples {

	public static int[] getMultiplesArray(int number) {
		int a[] = new int[10];

		if (number <= 0) {
			return null;

		}
		for (int i = 1, j = 0; i <= 10; i++, j++) {
			a[j] = i * number;
		}

		return a;
	}

}
