import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_50_CricketScoresTest {

	@Test
	public void testGetDisplayDetails() {
		try {
			assertEquals("20 runs in 7 balls @ 2.86 runs per ball",
					ECC_50_CricketScores.getDisplayDetails(20, 1.1f));
			assertEquals("20 runs in 13 balls @ 1.54 runs per ball",
					ECC_50_CricketScores.getDisplayDetails(20, 2.1f));
			assertEquals("30 runs in 13 balls @ 2.31 runs per ball",
					ECC_50_CricketScores.getDisplayDetails(30, 2.1f));

			System.out
					.println("#####ECC_41_CricketScoresTest | Passed | 100 / 100 | Passed for valid output#####");

		} catch (AssertionError e) {
			System.out
					.println("#####ECC_41_CricketScoresTest | Failed | 0 / 100 | Failed for valid output#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####ECC_41_CricketScoresTest | Failed | 0 / 100 | Failed could not find method getCount(int[], int)#####");
		} catch (Exception e) {
			System.out
					.println("#####ECC_41_CricketScoresTest | Failed | 0 / 100 | Failed RuntimeError#####"
							+ e.getMessage());
		}

	}
}
