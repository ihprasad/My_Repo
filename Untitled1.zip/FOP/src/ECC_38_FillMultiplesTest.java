import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_38_FillMultiplesTest {

	@Test
	public void testGetMultiplesArray(){
		try{
			int[] mt1 = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
			int indx = 0;
			for(int i : ECC_38_FillMultiples.getMultiplesArray(2)){
				assertEquals(mt1[indx], i);
				indx ++;
			}
			
			int[] mt2 = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
			int indx1 = 0;
			for(int j : ECC_38_FillMultiples.getMultiplesArray(10)){
				assertEquals(mt2[indx1], j);
				indx1 ++;
			}
			
			
			
			System.out.println("#####FillMultiplesTest | Passed | 70/70 | Passed for filling multples 10 multiples of input#####");

		} catch (AssertionError e) {
			System.err.println("#####FillMultiplesTest | Failed | 0/70 | Failed for filling multples 10 multiples of input#####");
		} catch (NoSuchMethodError e) {
			System.err.println("#####FillMultiplesTest | Failed | 0/70 | Failed could not find method getMultiplesArray(int)#####");
		} catch (Exception e) {
			System.err.println("#####FillMultiplesTest | Failed | 0/70 | Failed RuntimeError#####" + e.getMessage());
		} 
		
		
		
		
	}
	
	@Test
	public void testNull(){
		try{
			
			assertEquals(null, ECC_38_FillMultiples.getMultiplesArray(-1));
			assertEquals(null, ECC_38_FillMultiples.getMultiplesArray(0));
			
			
			System.out.println("#####FillMultiplesTest | Passed | 30/30 | Passed for return null for invalid input#####");

		} catch (AssertionError e) {
			System.err
					.println("#####FillMultiplesTest | Failed | 0/30 | Failed for return null for invalid input#####");
		} 
		
	}
	
	
	

}
