import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_44_GeneratePalindromeTest {

		@Test
			public void getPalindromeTest() {
				try
				{
					assertEquals("165,561,726,627,1353,3531,4884",ECC_44_GeneratePalindrome.getPalindromeList(165));
					System.out.println("#####GeneratePalindromeTest | Passed | 40/40 | Passed for GeneratePalindrome test#####");

				} catch (AssertionError e) {
					System.out
					.println("#####GeneratePalindromeTest | Failed | 0/40 | Failed for GeneratePalindrome test#####");
				} catch (NoSuchMethodError e) {
					System.out
					.println("#####GeneratePalindromeTest | Failed | 0/40 | No such method found#####");

				} catch (Exception e) {
					System.out
					.println("#####GeneratePalindromeTest | Failed | 0/40 |Runtime Exception:"
							+ e.getMessage()+"#####");
				}
			}
			
			@Test
			public void getPalindromeNegativeTest() {
				try
				{
					assertEquals("Error",ECC_44_GeneratePalindrome.getPalindromeList(-5));
					System.out.println("#####GeneratePalindromeNegativeTest | Passed | 10/10 | Passed for Negative input#####");

				} catch (AssertionError e) {
					System.out
					.println("#####GeneratePalindromeNegativeTest | Failed | 0/10 | Failed for negative input#####");
				} catch (NoSuchMethodError e) {
					System.out
					.println("#####GeneratePalindromeNegativeTest | Failed | 0/10 | No such method found#####");

				} catch (Exception e) {
					System.out
					.println("#####GeneratePalindromeNegativeTest | Failed | 0/10 |Runtime Exception:"+ e.getMessage()+"#####");
				}
			}
			
			@Test
			public void getPalindromeZeroTest() {
				try
				{
					assertEquals("Error",ECC_44_GeneratePalindrome.getPalindromeList(0));
					System.out.println("#####GeneratePalindromeZeroTest | Passed | 10/10 | Passed for GeneratePalindromeZero input#####");

				} catch (AssertionError e) {
					System.out
					.println("#####GeneratePalindromeZeroTest | Failed | 0/10 | Failed for GeneratePalindromeZero input#####");
				} catch (NoSuchMethodError e) {
					System.out
					.println("#####GeneratePalindromeZeroTest | Failed | 0/10 | No such method found#####");

				} catch (Exception e) {
					System.out
					.println("#####TwinPrimesZeroTest | Failed | 0/10 |Runtime Exception:"+ e.getMessage()+"#####");
				}
		}
			@Test
			public void getPalindrome3DigitTest() {
				try
				{
					assertEquals("Error",ECC_44_GeneratePalindrome.getPalindromeList(99));
					assertEquals("Error",ECC_44_GeneratePalindrome.getPalindromeList(1000));
					System.out.println("#####GeneratePalindrome3DigitTest | Passed | 20/20 | Passed for GeneratePalindromeZero input#####");

				} catch (AssertionError e) {
					System.out
					.println("#####GeneratePalindrome3DigitTest | Failed | 0/20 | Failed for GeneratePalindromeZero input#####");
				} catch (NoSuchMethodError e) {
					System.out
					.println("#####GeneratePalindrome3DigitTest | Failed | 0/20 | No such method found#####");

				} catch (Exception e) {
					System.out
					.println("#####TwinPrimes3DigitTest | Failed | 0/20 |Runtime Exception:"+ e.getMessage()+"#####");
				}
			}
			@Test
			public void getPalindromeConvergeTest() {
				try
				{
					assertEquals("761,167,928,829,1757,7571,9328,8239,17567,76571,94138,83149,177287,782771,960058,850069,1810127,7210181,9020308,8030209",ECC_44_GeneratePalindrome.getPalindromeList(761));
					System.out.println("#####GeneratePalindromeConvergeTest | Passed | 20/20 | Passed for GeneratePalindromeConvergeTest input#####");

				} catch (AssertionError e) {
					System.out
					.println("#####GeneratePalindromeConvergeTest | Failed | 0/20 | Failed for GeneratePalindromeConvergeTest input#####");
				} catch (NoSuchMethodError e) {
					System.out
					.println("#####GeneratePalindromeConvergeTest | Failed | 0/20 | No such method found#####");

				} catch (Exception e) {
					System.out
					.println("#####GeneratePalindromeConvergeTest | Failed | 0/20 |Runtime Exception:"+ e.getMessage()+"#####");
				}
			}
	}