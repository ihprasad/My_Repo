public class ECC_43_TwinPrimes{
	
	public static void main(String[] args) {
		
		ECC_43_TwinPrimes ob = new ECC_43_TwinPrimes();
		
		System.out.println(ob.getTwinPrimes(3, 40));
		
	}
	
	 boolean isPrime(int n)  {
         int count=0;
         for(int i=1; i<=n; i++)
             {
                 if(n%i == 0)
                     count++;
             }
         if(count == 2)
             return true;
          else
             return false;
     }
	 
	static String getTwinPrimes(int a, int b){
		 
		 ECC_43_TwinPrimes ob = new ECC_43_TwinPrimes();
		 String tprimes = "";

         int p = a;
         int q = b;
          
         if(p>q || p < 1 || q > 99)
             return "Error";
         else
         {
             for(int i=p; i<=(q-2); i++)
             {
                 if(ob.isPrime(i) == true && ob.isPrime(i+2) == true)
                 {
                	 tprimes += i + "," + (i+2) + ";";
                 }
             }
             if(tprimes.length() == 0)
            	 tprimes += "No Twin Primes Found";
         }                 
		 return tprimes;
	 }

}