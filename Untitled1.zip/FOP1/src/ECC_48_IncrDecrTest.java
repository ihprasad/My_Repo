import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_48_IncrDecrTest {

	@Test
	public void testGetIncreaseDecreaseEven() {
		try {
			int expected[] = { 1, 10, 2, 9, 3, 8, 4, 7, 5, 6 };
			assertArrayEquals(expected, ECC_48_IncrDecr.getIncreaseDecrease(10));
			System.out
					.println("#####IncreaseDecreaseTest | Passed | 35 / 35 | Passed for Even Number Input####");
		} catch (AssertionError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 35 | Failed for Even Number Input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 35 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 35 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetIncreaseDecreaseOdd() {
		try {
			int expected[] = { 1, 11, 2, 10, 3, 9, 4, 8, 5, 7, 6 };
			assertArrayEquals(expected, ECC_48_IncrDecr.getIncreaseDecrease(11));
			System.out
					.println("#####IncreaseDecreaseTest | Passed | 35 / 35 | Passed for Odd Number Input####");
		} catch (AssertionError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 35 | Failed for Odd Number Input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 35 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 35 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetIncreaseDecreaseLowestNumber() {
		try {

			assertNull(ECC_48_IncrDecr.getIncreaseDecrease(-3));
			assertNull(ECC_48_IncrDecr.getIncreaseDecrease(1));
			assertNull(ECC_48_IncrDecr.getIncreaseDecrease(0));

			System.out
					.println("#####IncreaseDecreaseTest | Passed | 15 / 15 | Passed for 1 or Less Number Input####");
		} catch (AssertionError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 15 | Failed for 1 or less Number Input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetIncreaseDecreaseBigNumber() {
		try {

			assertNull(ECC_48_IncrDecr.getIncreaseDecrease(21));

			System.out
					.println("#####IncreaseDecreaseTest | Passed | 15 / 15 | Passed for 20 and more Number as input####");
		} catch (AssertionError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 15 | Failed for 20 and more Number as input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####IncreaseDecreaseTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
