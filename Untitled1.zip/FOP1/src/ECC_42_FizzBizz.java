public class ECC_42_FizzBizz {

	public static String getOutputString(int number){
		String str="";	
		if(number>0)
		{
			if(number%3==0 && number%5==0 ) 
				str="FIZZBIZZ";			
			else if(number%5==0)
				str="BIZZ";
			else if(number%3==0)
				str="FIZZ";
			else if(number%3!=0 || number%5!=0 )
				str=String.valueOf(number);
			return str;
		}
		else
		{
			return "Error";
		}
	}

	public static void main(String args[])
	{
		int number=30;

		String str=getOutputString(number);

		System.out.println(str);
	}
}

