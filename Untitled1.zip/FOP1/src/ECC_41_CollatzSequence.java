
public class ECC_41_CollatzSequence {

	public static String getCollatzSequence(int number) {
		int counter = 1;
		String str = "";
		if (number <= 0) {
			return "Error";
		}
		str = "" + number + " ";

		while (number > 1) {
			++counter;
			if (number % 2 == 0) {
				number = number / 2;
			} else {
				number = (number * 3) + 1;
			}

			str = str + number + " ";
			if (counter >= 100 && number != 1) {
				return "Does not Converge";
			}
		}
		return str.trim();
	}

	public static void main(String[] args) {
		int number =107;
		System.out.println(getCollatzSequence(number));
	}
}