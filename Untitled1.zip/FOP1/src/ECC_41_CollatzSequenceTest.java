import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_41_CollatzSequenceTest {

		@Test
	public void collatzSequenceTest() {
		try

		{
			assertEquals("5 16 8 4 2 1",new ECC_41_CollatzSequence().getCollatzSequence(5));
System.out.println("#####CollatzSequenceTest | Passed | 40/40 | Passed for CollatzSequence test#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CollatzSequenceTest | Failed | 0/40 | Failed for CollatzSequence test#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CollatzSequenceTest | Failed | 0/40 | No such method found: getCollatzSequence()#####");

		} catch (Exception e) {
			System.out
			.println("#####CollatzSequenceTest | Failed | 0/40 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	@Test
	public void collatzSequenceNegativeTest() {
		try

		{
			assertEquals("Error",new ECC_41_CollatzSequence().getCollatzSequence(-95));
			System.out.println("#####CollatzSequenceTest | Passed | 10/10 | Passed for Negative input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CollatzSequenceTest | Failed | 0/10 | Failed for negative input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CollatzSequenceTest | Failed | 0/10 | No such method found: getCollatzSequence()#####");

		} catch (Exception e) {
			System.out
			.println("#####CollatzSequenceTest | Failed | 0/10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}

@Test
	public void isZero() {
		try

		{
			assertEquals("Error",new ECC_41_CollatzSequence().getCollatzSequence(0));
			System.out.println("#####isZero | Passed | 10/10 | Passed for as zero input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####isZero | Failed | 0/10 | Failed for zero as input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####isZero | Failed | 0/10 | No such method found: getCollatzSequence()#####");

		} catch (Exception e) {
			System.out
			.println("#####isZero | Failed | 0/10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
			@Test
	public void collatzSequenceNotConverge() {
		try

		{
			assertEquals("Does not Converge",new ECC_41_CollatzSequence().getCollatzSequence(107));
			System.out.println("#####CollatzSequenceTest | Passed | 40/40 | Passed for Non-Coverge number input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####CollatzSequenceTest | Failed | 0/40 | Failed for Non-Converge number input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####CollatzSequenceTest | Failed | 0/40 | No such method found: getCollatzSequence()#####");

		} catch (Exception e) {
			System.out
			.println("#####CollatzSequenceTest | Failed | 0/40 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
}