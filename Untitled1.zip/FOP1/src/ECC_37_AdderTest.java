
import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_37_AdderTest {

	@Test
	public void isNegative() {
		try {
			
			assertEquals("Error", ECC_37_Adder.getSum(-5, 5));
			assertEquals("Error", ECC_37_Adder.getSum(5, -5));
			assertEquals("Error", ECC_37_Adder.getSum(-5, -5));
			System.out
					.println("#####isNegative|Passed|20/20|Checking for negative values as input#####");
		} catch (AssertionError e) {
			System.out
					.println("#####isNegative|Failed|0/20|Checking for negative values as input#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####isNegative|Failed|0/20|Wrong method name:could not find method getSum()#####");
		} catch (Exception e) {
			System.out.println("#####isNegative|Failed|0/20|Runtime Exception:"
					+ e.getMessage() + "#####");
		}
	}

	@Test
	public void isZero() {
		try {
			 
			assertEquals("Error", ECC_37_Adder.getSum(0, 1));
			assertEquals("Error", ECC_37_Adder.getSum(9, 0));
			assertEquals("Error", ECC_37_Adder.getSum(0, 0));

			 
			System.out
					.println("#####isZero|Passed|20/20|Checking for zero as input#####");
		} catch (AssertionError e) {
			System.out
					.println("#####isZero|Failed|0/20|Checking for zero as input#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####isZero|Failed|0/20|Wrong method name:could not find method getSum()#####");
		} catch (Exception e) {
			System.out.println("#####isZero|Failed|0/20|Runtime Exception:"
					+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testgetSum() {
		try {
			
			assertEquals("21", ECC_37_Adder.getSum(11, 10));			
			
			System.out
					.println("#####checkPalindromeTest|Passed|60/60|Checking for sum of two numbers#####");
		} catch (AssertionError e) {
			System.out
					.println("#####checkPalindromeTest|Failed|0/60|Checking for sum of two numbers#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####checkPalindromeTest|Failed|0/60|Wrong method name:could not find method getSum()#####");
		} catch (Exception e) {
			System.out.println("#####checkPalindromeTest|Failed|0/60|Runtime Exception:"
					+ e.getMessage() + "#####");
		}
	}


}