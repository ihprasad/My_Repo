public class ECC_47_OddSum {
	public static int getOddSum(int[] inputArray)
	{
		if(inputArray==null)
			return -4;
		if(inputArray.length!=5)
			return -1;
		
		int sum=0;
		for(int i:inputArray)
		{
			if(i<=0)
				return -2;
			if(i%2!=0)
				sum+=i;
		}
		
		if(sum==0)
			return -3;
		else
		return sum;
	}
	public static void main(String[] args) {
		System.out.println(getOddSum(new int[]{2,2,2,2,2}));

		System.out.println(getOddSum(null));
		System.out.println(getOddSum(new int[]{5,7,8,2,1}));
	}
}
