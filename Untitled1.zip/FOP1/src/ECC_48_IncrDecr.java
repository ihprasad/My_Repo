public class ECC_48_IncrDecr {
	public static int[] getIncreaseDecrease(int input) {
		if(input<=1 || input > 20)
			return null;
	
		int arr[] = new int[input];
		int last = input;
		int first = 1;
		int ctr = 0;
		do {
			if (ctr == input)
				break;
			if (ctr % 2 == 0)
				arr[ctr] = first++;
			else
				arr[ctr] = last--;
			ctr++;
		} while (true);
		
		return arr;
	}

	public static void main(String[] args) {
		for (int i : getIncreaseDecrease(11)) {
			System.out.print(i + ",");
		}
	}
}
