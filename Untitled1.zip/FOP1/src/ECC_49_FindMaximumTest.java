import static org.junit.Assert.*;
import org.junit.Test;

public class ECC_49_FindMaximumTest {

	@Test
	public void testFindMaxMixedNumbers() {
		try {
			
			assertEquals(4,ECC_49_FindMaximum.findMax(new int[]{1,1,1,-1,2,2,-2,2,3,-3,3,-4,4,4}));
			System.out
					.println("#####FindingMaximumTest | Passed | 35 / 35 | Passed for some positive, some negative and repeated numbers as Input####");
		} catch (AssertionError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 35 | Failed Passed for some positive, some negative and repeated numbers as Input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 35 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 35 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testFindMax() {
		try {
			
			assertEquals(-20,ECC_49_FindMaximum.findMax(new int[]{-1999,-2000,-20}));
			System.out
					.println("#####FindingMaximumTest | Passed | 35 / 35 | Passed for all -ve numbers in array as Input####");
		} catch (AssertionError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 35 | Failed for all -ve numbers in array as Input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 35 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 35 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testFindMaxLessInputs() {
		try {
			
			assertEquals(-1,ECC_49_FindMaximum.findMax(new int[]{-1999,-2000}));

			System.out
					.println("#####FindingMaximumTest | Passed | 15 / 15 | Passed for less than 3 elements in array as Input####");
		} catch (AssertionError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 15 | Failed for less than 3 elements in array as Input####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testFindMaxNull() {
		try {
			
			assertEquals(0,ECC_49_FindMaximum.findMax(null));
			System.out
					.println("#####FindingMaximumTest | Passed | 15 / 15 | Passed for Null array####");
		} catch (AssertionError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 15 | Failed for Null####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####FindingMaximumTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
