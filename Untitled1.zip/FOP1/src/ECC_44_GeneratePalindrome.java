
public class ECC_44_GeneratePalindrome {

	public static String getPalindromeList(int num) {
		if(num<=99 || num>999)
			return "Error";
		int prev=0;
		int count=1;
		String output="";
		while (true) {
			num=num+prev;
			output=output+num+",";
			if(palin(num))
			{
				
				break;
			}
			else
			{
				prev=revNum(num);
				output=output+prev+",";
			}
			count+=2;
			if(count>20)
				break;
		}
		
		return output.substring(0,output.length()-1);
	}

	public static int revNum(int num) {
		int rno=0;
		while(num>0)
		{
			rno=rno*10+num%10;
			num=num/10;
			
		}
		return rno;
	}

	public static boolean palin(int num) {
		if (num == revNum(num))
			return true;
		else
			return false;
	}

	public static void main(String args[]) {
		int num = Integer.parseInt(args[0]);	
			System.out.println(getPalindromeList(-5));
	}
}