import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_40_RussianMultiplicationTest {

	@Test
	public void testGetProduct(){
		try{
				assertEquals(200, ECC_40_RussianMultiplication.getProduct(10, 20));
				assertEquals(2, ECC_40_RussianMultiplication.getProduct(1, 2));
				assertEquals(2000, ECC_40_RussianMultiplication.getProduct(100, 20));	
				System.out.println("#####RussianMultiplicationTest | Passed | 50/50 | Passed for multiplication#####");

		} catch (AssertionError e) {
			System.err.println("#####RussianMultiplicationTest | Failed | 0/50 | Failed for multiplication#####");
		} catch (NoSuchMethodError e) {
			System.err.println("#####RussianMultiplicationTest | Failed | 0/50 | Failed could not find method getProduct(int, int)#####");
		} catch (Exception e) {
			System.err.println("#####RussianMultiplicationTest | Failed | 0/50 | Failed RuntimeError#####" + e.getMessage());
		} 
	}
		@Test
		public void isZeroTest(){
			try{
					assertEquals(-1, ECC_40_RussianMultiplication.getProduct(0, 20));
					assertEquals(-1, ECC_40_RussianMultiplication.getProduct(0, 0));
					assertEquals(-1, ECC_40_RussianMultiplication.getProduct(100, 0));	
					System.out.println("#####isZeroTest | Passed | 25/25 | Passed for zero as input#####");

			} catch (AssertionError e) {
				System.err.println("#####isZeroTest | Failed | 0/25 | Failed for zero as input#####");
			} catch (NoSuchMethodError e) {
				System.err.println("#####isZeroTest | Failed | 0/25 | Failed could not find method getProduct(int, int)#####");
			} catch (Exception e) {
				System.err.println("#####isZeroTest | Failed | 0/25 | Failed RuntimeError#####" + e.getMessage());
			} 
		}
			
			@Test
			public void isNegativeTest(){
				try{
						assertEquals(-1, ECC_40_RussianMultiplication.getProduct(-10, 20));
						assertEquals(-1, ECC_40_RussianMultiplication.getProduct(-10, -20));
						assertEquals(-1, ECC_40_RussianMultiplication.getProduct(100, -10));	
						System.out.println("#####isNegativeTest | Passed | 25/25 | Passed for negative as input#####");

				} catch (AssertionError e) {
					System.err.println("#####isNegativeTest | Failed | 0/25 | Failed for negative as input#####");
				} catch (NoSuchMethodError e) {
					System.err.println("#####isNegativeTest | Failed | 0/25 | Failed could not find method getProduct(int, int)#####");
				} catch (Exception e) {
					System.err.println("#####isNegativeTest | Failed | 0/25 | Failed RuntimeError#####" + e.getMessage());
				} 
		
		
		
		
	}
	
	

}
