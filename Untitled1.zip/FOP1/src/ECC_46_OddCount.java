public class ECC_46_OddCount {
	public static String getOddCount(int[] inputArray)
	{
		if(inputArray==null)
			return "-4";
		if(inputArray.length!=5)
			return "-1";
		
		int count=0;
		for(int i:inputArray)
		{
			if(i<=0)
				return "-2";
			if(i%2!=0)
				count++;
		}
		
		if(count==0)
			return "-3";
		else
		return ""+count;
	}
	public static void main(String[] args) {
		// YOU CAN TEST YOUR CODE HERE
	}
}
