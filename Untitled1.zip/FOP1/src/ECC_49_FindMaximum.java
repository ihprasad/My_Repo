import java.util.Arrays;

public class ECC_49_FindMaximum {
	public static int findMax(int[] input) {
		if(input==null)
			return 0;
		int count=0;
	
		int max=input[0];
		for(int i:input)
		{
			if(i<0)
				count++;
			if(i>max)
				max=i;
		}
		if(count<3)
			return -1;
		return max;
	}

	public static void main(String[] args) {
		System.out.println(findMax(new int[]{-12,-199,-400}));
	}
}
