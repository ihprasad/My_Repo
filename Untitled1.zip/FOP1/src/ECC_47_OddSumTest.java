import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ECC_47_OddSumTest {

	@Test
	public void testGetOddForNull() {
		try {
	
			assertEquals(-4,ECC_47_OddSum.getOddSum(null));
			System.out.println("#####OddSumTest | Passed | 10 / 10 | Passed for null array####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | Failed for null array####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testGetOddForLessSize() {
		try {
			assertEquals(-1,
					 ECC_47_OddSum.getOddSum(new int[]{2,4}));
			System.out
			.println("#####OddSumTest | Passed | 10 / 10 | Passed for size less than required####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | Failed for size less than required####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testGetOddForMoreSize() {
		try {
			assertEquals(-1,
					 ECC_47_OddSum.getOddSum(new int[]{2,4,3,3,3,4,5,7,7}));
			System.out
			.println("#####OddSumTest | Passed | 10 / 10 | Passed for size more than required####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | Failed for size more than required####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testGetOddForAllEvens() {
		try {
			assertEquals(-3,
					ECC_47_OddSum.getOddSum(new int[]{2,4,6,8,100}));
			System.out
			.println("#####OddSumTest | Passed | 20 / 20 | Passed for all even numbers in array####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 20 | Failed for all even numbers in array####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetOddSumSomeNegatives() {
		try {
			assertEquals(-2,
					ECC_47_OddSum.getOddSum(new int[]{-115,5,9,99,11111}));
			System.out
			.println("#####OddSumTest | Passed | 10 / 10 | Passed for one element as negative element#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | Failed for one element as negative element#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetOddSumSomeZeros() {
		try {
			assertEquals(-2,
					ECC_47_OddSum.getOddSum(new int[]{5,5,0,99,11111}));
			System.out
			.println("#####OddSumTest | Passed | 10 / 10 | Passed for 0 as one of the element#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | Failed for 0 as one of the element#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetOddSumAllElements() {
		try {
			assertEquals(25,
					ECC_47_OddSum.getOddSum(new int[]{1,3,5,7,9}));
			System.out
			.println("#####OddSumTest | Passed | 15 / 15 | Passed for right array with 5 inputs and all are odd numbers#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 15 | Failed for right array with 5 inputs and all are odd numbers#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testGetOddSum() {
		try {
		
			assertEquals(13,
					ECC_47_OddSum.getOddSum(new int[]{5,7,8,2,1}));
			System.out
			.println("#####OddSumTest | Passed | 15 / 15 | Passed for right array with 5 inputs and 3 odd numbers#####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 15 | Failed for right array with 5 inputs and 3 odd numbers#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddSumTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
