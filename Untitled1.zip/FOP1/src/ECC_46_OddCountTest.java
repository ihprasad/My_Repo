import static org.junit.Assert.*;
import org.junit.Test;
public class ECC_46_OddCountTest {
	@Test
	public void testGetOddForNull() {
		try {
			assertEquals("-4",
					ECC_46_OddCount.getOddCount(null));
			System.out.println("#####OddCountTest | Passed | 10 / 10 | Passed for null array####");

		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | Failed for null array####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testGetOddForLessSize() {
		try {
			assertEquals("-1",
					new ECC_46_OddCount().getOddCount(new int[]{2,4}));
			System.out.println("#####OddCountTest | Passed | 10 / 10 | Passed for size less than required####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | Failed for size less than required####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testGetOddForMoreSize() {
		try {
			assertEquals("-1",
					new ECC_46_OddCount().getOddCount(new int[]{2,4,3,3,3,4,5,7,7}));
			System.out.println("#####OddCountTest | Passed | 10 / 10 | Passed for size more than required####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | Failed for size more than required####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	
	@Test
	public void testGetOddForAllEvens() {
		try {
			assertEquals("-3",
					new ECC_46_OddCount().getOddCount(new int[]{2,4,6,8,100}));
			System.out.println("#####OddCountTest | Passed | 20 / 20 | Passed for all even numbers in array####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 20 | Failed for all even numbers in array####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 20 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetOddCountSomeNegatives() {
		try {
			assertEquals("-2",
					new ECC_46_OddCount().getOddCount(new int[]{-115,5,9,99,11111}));
			System.out.println("#####OddCountTest | Passed | 10 / 10 | Passed for one element as negative element#####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | Failed for one element as negative element#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetOddCountSomeZeros() {
		try {
			assertEquals("-2",
					new ECC_46_OddCount().getOddCount(new int[]{5,5,0,99,11111}));
			System.out.println("#####OddCountTest | Passed | 10 / 10 | Passed for 0 as one of the element#####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | Failed for 0 as one of the element#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetOddCountAllElements() {
		try {
			assertEquals("5",
					new ECC_46_OddCount().getOddCount(new int[]{5,5,21,99,11111}));
			System.out.println("#####OddCountTest | Passed | 15 / 15 | Passed for right array with 5 inputs and all are odd numbers#####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 15 | Failed for right array with 5 inputs and all are odd numbers#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}
	@Test
	public void testGetOddCount() {
		try {
			assertEquals("3",
					new ECC_46_OddCount().getOddCount(new int[]{5,7,8,2,1}));
			System.out.println("#####OddCountTest  | Passed | 15 / 15 | Passed for right array with 5 inputs and 3 odd numbers#####");
		} catch (AssertionError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 15 | Failed for right array with 5 inputs and 3 odd numbers#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 15 | No such method found#####");

		} catch (Exception e) {
			System.out
					.println("#####OddCountTest | Failed | 0 / 15 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
