import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_42_FizzBizzTest {

	@Test
	public void forFizzTest() {
		try

		{
			assertEquals("FIZZ",new ECC_42_FizzBizz().getOutputString(33));
			System.out.println("#####forFizzTest | Passed | 20 / 20 | Passed for fizz test#####");

		} catch (AssertionError e) {
			System.out.println("#####forFizzTest | Failed | 0 / 20 | Failed for bizz testt#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####forFizzTest | Failed | 0 / 20 | No such method found: getOutputString()#####");

		} catch (Exception e) {
			System.out
			.println("#####forFizzTest | Failed | 0 / 20 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	@Test
	public void forBizzTest() {
		try

		{
			assertEquals("BIZZ",new ECC_42_FizzBizz().getOutputString(5));
			System.out.println("#####forBizzTest | Passed | 20 / 20 | Passed for bizz test#####");

		} catch (AssertionError e) {
			System.out
					.println("#####forBizzTest | Failed | 0 / 20 | Failed for bizz test#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####forBizzTest | Failed | 0 / 20 | No such method found()#####");

		} catch (Exception e) {
			System.out
			.println("#####forBizzTest | Failed | 0 / 20 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	@Test
	public void forFizzBizzTest() {
		try

		{
			assertEquals("FIZZBIZZ",new ECC_42_FizzBizz().getOutputString(15));
			System.out.println("#####forFizzBizzTest | Passed | 20 / 20 | Passed for fizzbizz test#####");

		} catch (AssertionError e) {
			System.out
					.println("#####forFizzBizzTest | Failed | 0 / 20 | Failed for fizzbizz test#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####forFizzBizzTest | Failed | 0 / 20 | No such method found: getOutputString()#####");

		} catch (Exception e) {
			System.out
			.println("#####forFizzBizzTest | Failed | 0 / 20 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	@Test
	public void normalNumbersTest() {
		try

		{
			assertEquals("22",new ECC_42_FizzBizz().getOutputString(22));
			System.out.println("#####normalNumbersTest | Passed | 20 / 20 | Passed for normal number test#####");

		} catch (AssertionError e) {
			System.out
					.println("#####normalNumbersTest | Failed | 0 / 20 | Failed for  normal number#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####normalNumbersTest | Failed | 0 / 20 | No such method found: getOutputString()#####");

		} catch (Exception e) {
			System.out
			.println("#####normalNumbersTest | Failed | 0 / 20 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
	@Test
	public void fizzBizzNegativeTest() {
		try

		{
			assertEquals("Error",new ECC_42_FizzBizz().getOutputString(-5));
			System.out.println("#####fizzBizzNegativeTest | Passed | 10 / 10 | Passed for negative number input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####fizzBizzNegativeTest | Failed | 0 / 10 | Failed for negative number input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####fizzBizzNegativeTest | Failed | 0 / 10 | No such method found: getOutputString()#####");

		} catch (Exception e) {
			System.out
			.println("#####fizzBizzNegativeTest | Failed | 0 / 10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}

@Test
	public void fizzBizzZeroTest() {
		try

		{
			assertEquals("Error",new ECC_42_FizzBizz().getOutputString(0));
			System.out.println("#####fizzBizzZeroTest | Passed | 10 / 10 | Passed for zero as input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####fizzBizzZeroTest | Failed | 0 / 10 | Failed for zero as input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####fizzBizzZeroTest | Failed | 0 / 10 | No such method found: getOutputString()#####");

		} catch (Exception e) {
			System.out
			.println("#####fizzBizzZeroTest | Failed | 0 / 10 |Runtime Exception:"
					+ e.getMessage()+"#####");
		}
	}
}
