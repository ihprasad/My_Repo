import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


public class TestTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public final void testDisplay() {
		System.out.println("Welcome");
	}

}
