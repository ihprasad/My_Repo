import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


public class StuMedalHashMap6Test {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public final void test() {
		fail("Not yet implemented"); // TODO
	}

}
