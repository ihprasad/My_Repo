import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class StuMedalHashMap6 {
	static Map<Integer, String> stumedal(Map<Integer, Integer> m) {
		Map<Integer, String> rm = new HashMap<Integer, String>();
		Set<Integer> s = m.keySet();
		Iterator<Integer> it = s.iterator();
		int id;
		while (it.hasNext()) {
			id = it.next();
			int n = m.get(id);
			System.out.println(n + "*****");
			int nn = n / 10;
			System.out.println(nn + "-----");
			switch (nn) {
			case 9:
				rm.put(id, "Gold");
				break;
			case 8:
				rm.put(id, "Silver");
				break;
			case 7:
				rm.put(id, "Bronze");
				break;
			}
		}
		return rm;
	}

	public static void main(String[] args) {
		HashMap<Integer, Integer> h = new HashMap<Integer, Integer>();
		h.put(121, 90);
		h.put(122, 80);
		h.put(123, 70);
		h.put(124, 60);
		h.put(125, 50);
		h.put(126, 98);
		h.put(127, 85);
		h.put(128, 77);
		h.put(129, 69);
		System.out.println(h);
		Map<Integer, String> res = StuMedalHashMap6.stumedal(h);
		Map<Integer, String> res1 = StuMedalHashMap6.stumedal(h);
		System.out.println(res);
		System.out.println(res1);
	}
}