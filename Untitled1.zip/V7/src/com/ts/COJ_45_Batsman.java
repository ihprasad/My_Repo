package com.ts;

public class COJ_45_Batsman {
	// Four variables
		String name;
		int runs;
		int matches;
		float batting_avg;
		
		public COJ_45_Batsman() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		// One Constructor with three arguments
		public COJ_45_Batsman(String name, int runs, int matches) {
			this.name = name;
			this.runs = runs;
			this.matches = matches;
		}

		// two methods - computeBattingAverage() and getStatistics()
		public void computeBattingAverage() {
			batting_avg = (float) runs / matches;
			System.out.println("Batting_Avg: " + batting_avg);
		}

		public void getStatistics() {
			System.out.println("Name: " + name);
			System.out.println("Runs: " + runs);
			System.out.println("Matches: " + matches);

		}
	}

	class COJ_45_Testing {

		public static void main(String[] args2) {
			// Create one Batsman Object and call the computeBattingAverage() method
			// getStatistics() method.
			COJ_45_Batsman b = new COJ_45_Batsman("Sachin", 18000, 463);
			b.getStatistics();
			b.computeBattingAverage();
		}

}
