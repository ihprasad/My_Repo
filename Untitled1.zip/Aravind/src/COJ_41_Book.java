abstract class COJ_41_Book 
{
  	String title;

   	abstract void setTitle(String s);

   	String getTitle()
   	{
   		return title;
   	}
}

class COJ_41_MyBook extends COJ_41_Book
{
	void setTitle(String s)
   	{
      		title=s;
   	}	

	String getTitle()
   	{
   		return "The title of my book is : "+title;
   	}
}
