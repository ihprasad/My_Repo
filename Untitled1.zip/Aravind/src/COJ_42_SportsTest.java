import org.junit.Assert;
import org.junit.Test;
import org.junit.BeforeClass;
import java.lang.reflect.Method;

public class COJ_42_SportsTest
{
	@BeforeClass
	public static void verifyParentClass() 
	{
		String mname="";
		try 
		{
			Class c=Class.forName("COJ_42_Sports");
			
			mname="getName";
			Method m=c.getDeclaredMethod("getName");
			System.out.println("#####SportsTest | PASSED | 10/10 | getName method defined in parent class.#####");

			String rtype=m.getReturnType().getName();
			if(!(rtype.equals("java.lang.String")))
			{
				System.out.println("#####SportsTest | FAILED | 0/10 | getName method does not have String return type in parent class.#####");
				System.exit(0);
			}
			System.out.println("#####SportsTest | PASSED | 10/10 | getName method have String return type in parent class.#####");

			mname="getNumberOfTeamMembers";
			m=c.getDeclaredMethod("getNumberOfTeamMembers");
			System.out.println("#####SportsTest | PASSED | 10/10 | getNumberOfTeamMembers method defined in parent class.#####");

			rtype=m.getReturnType().getName();
			if(!(rtype.equals("java.lang.String")))
			{
				System.out.println("#####SportsTest | FAILED | 0/10 | getNumberOfTeamMembers method does not have String return type in parent class.#####");
				System.exit(0);
			}
			System.out.println("#####SportsTest | PASSED | 10/10 | getNumberOfTeamMembers method have String return type in parent class.#####");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####SportsTest | FAILED | 0/10 | Sports class not defined.#####");
			System.exit(0);
		}
		catch(NoSuchMethodException nsme) 
		{
			System.out.println("#####SportsTest | FAILED | 0/10 | "+mname+" method not defined in parent class.#####");
			System.exit(0);
		}
	}

	@BeforeClass
	public static void verifyChildClass() 
	{
		String mname="";
		try 
		{
			Class c=Class.forName("COJ_42_Soccer");
			if(!(c.getSuperclass().getName().equals("COJ_42_Sports")))
			{			
				System.out.println("#####SportsTest | FAILED | 0/10 | COJ_42_Soccer class does not extend COJ_42_Sports class.#####");
				System.exit(0);
			}

			System.out.println("#####SportsTest | PASSED | 10/10 | COJ_42_Soccer class extends COJ_42_Sports class.#####");

			mname="getName";
			Method m=c.getDeclaredMethod("getName");
			System.out.println("#####SportsTest | PASSED | 10/10 | getName method overrided in child class.#####");

			String rtype=m.getReturnType().getName();
			if(!(rtype.equals("java.lang.String")))
			{
				System.out.println("#####SportsTest | FAILED | 0/10 | getName method does not have String return type in child class.#####");
				System.exit(0);
			}
			System.out.println("#####SportsTest | PASSED | 10/10 | getName method have String return type in child class.#####");

			mname="getNumberOfTeamMembers";
			m=c.getDeclaredMethod("getNumberOfTeamMembers");
			System.out.println("#####SportsTest | PASSED | 10/10 | getNumberOfTeamMembers method overrided in child class.#####");

			rtype=m.getReturnType().getName();
			if(!(rtype.equals("java.lang.String")))
			{
				System.out.println("#####SportsTest | FAILED | 0/10 | getNumberOfTeamMembers method does not have String return type in child class.#####");
				System.exit(0);
			}
			System.out.println("#####SportsTest | PASSED | 10/10 | getNumberOfTeamMembers method have String return type in child class.#####");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####SportsTest | FAILED | 0/10 | COJ_42_Soccer class not defined in child class.#####");
			System.exit(0);
		}
		catch(NoSuchMethodException nsme) 
		{
			System.out.println("#####SportsTest | FAILED | 0/10 | "+mname+" method not overrided in child class.#####");
			System.exit(0);
		}
	}

	@Test
	public void testCase() throws Exception
	{
		String message="";
		try
		{
			COJ_42_Soccer scobj=new COJ_42_Soccer();

			String str=scobj.getNumberOfTeamMembers();

			String expectedresult="In Soccer,\teach team has 11 players.";				
								
			message="TEST VALUE="+expectedresult+", EXPECTED RESULT="+expectedresult+", ACTUAL RESULT="+str;
	
			Assert.assertEquals(expectedresult,str);

			System.out.println("#####SportsTest | PASSED | 10/10 | "+message+"#####");
		}
		catch(AssertionError aserr)
		{
			System.out.println("#####SportsTest | FAILED | 0/10 | "+message+"#####");			
		}
	}
}

