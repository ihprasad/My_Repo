import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.junit.BeforeClass;
import java.util.Arrays;
import java.util.Collection;
import java.lang.reflect.Method;

@RunWith(Parameterized.class)
public class COJ_44_MyCalculatorTest
{
	private int num;
	private int expectedresult;
	
	public COJ_44_MyCalculatorTest(int num,int expectedresult)
	{
		this.num=num;
		this.expectedresult=expectedresult;
	}

	@BeforeClass
	public static void verifyInterface() 
	{
		try 
		{
			Class c=Class.forName("COJ_44_AdvancedArithmetic");
			if(!c.isInterface())
			{
				System.out.println("#####MyCalculatorTest | FAILED | 0/10 | AdvancedArithmetic is not an interface.#####");
				System.exit(0);
			}
			System.out.println("#####MyCalculatorTest | PASSED | 10/10 | AdvancedArithmetic is an interface.#####");
			
			Method m=c.getDeclaredMethod("divisorSum",int.class);

			System.out.println("#####MyCalculatorTest | PASSED | 10/10 | AdvancedArithmetic contains divisorSum(int) method.#####");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####MyCalculatorTest | FAILED | 0/10 | AdvancedArithmetic interface not defined.#####");
			System.exit(0);
		}
		catch(NoSuchMethodException nsme) 
		{
			System.out.println("#####MyCalculatorTest | FAILED | 0/10 | divisorSum(int) method not defined in AdvancedArithmetic interface.#####");
			System.exit(0);
		}
	}

	@BeforeClass
	public static void verifyClass() 
	{
		try 
		{
			Class c=Class.forName("COJ_44_MyCalculator");
			if(c.isInterface())
			{
				System.out.println("#####MyCalculatorTest | FAILED | 0/10 | MyCalculator is not a class.#####");
				System.exit(0);
			}	
			System.out.println("#####MyCalculatorTest | PASSED | 10/10 | MyCalculator is a valid class.#####");

			Class[] cc=c.getInterfaces();
			if(cc.length==0||!(cc[0].getName().equals("COJ_44_AdvancedArithmetic")))
			{
				System.out.println("#####MyCalculatorTest | FAILED | 0/10 | MyCalculator class does not implement AdvancedArithmetic interface.#####");
				System.exit(0);
			}

			System.out.println("#####MyCalculatorTest | PASSED | 10/10 | MyCalculator class implements AdvancedArithmetic interface.#####");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####MyCalculatorTest | FAILED | 0/10 | MyCalculator class is not defined.#####");
			System.exit(0);
		}
	}

	@Parameters
	public static Collection<Object[]> data()
	{
		return Arrays.asList(new Object[][]{{6,12},{0,0},{-1,-1}});
	}

	@Test
	public void testCase()
	{
		COJ_44_MyCalculator mycalobj=new COJ_44_MyCalculator();
		
		int result=mycalobj.divisorSum(num);
		
		String message="TEST VALUE="+num+", EXPECTED RESULT="+expectedresult+", ACTUAL RESULT="+result;
		
		try
		{
			if(expectedresult==0)
				message="Value must not be 0. TEST VALUE="+num+", EXPECTED RESULT="+expectedresult+", ACTUAL RESULT="+result;
			else if(expectedresult==-1)
				message="Value must not be negative. TEST VALUE="+num+", EXPECTED RESULT="+expectedresult+", ACTUAL RESULT="+result;
					
			Assert.assertEquals(expectedresult,result);

			System.out.println("#####MyCalculatorTest | PASSED | 20/20 | "+message+"#####");
		}
		catch(AssertionError aserr)
		{
			System.out.println("#####MyCalculatorTest | FAILED | 0/20 | "+message+"#####");			
		}
	}
}

