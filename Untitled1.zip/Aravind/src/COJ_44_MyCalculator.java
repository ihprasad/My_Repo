interface COJ_44_AdvancedArithmetic
{
	public abstract int divisorSum(int n);
}
public class COJ_44_MyCalculator implements COJ_44_AdvancedArithmetic 
{
	public int divisorSum(int n)
	{
		if(n==0)
			return 0;

		if(n<0)
			return -1;

		int sum=0;
		
		for(int i=1;i<=n;i++)
		{
		    if(n%i==0)
		        sum+=i;
		}  
		
		return sum;
	}	
}
