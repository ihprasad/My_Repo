import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.junit.BeforeClass;
import java.util.Arrays;
import java.util.Collection;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;

@RunWith(Parameterized.class)
public class COJ_41_BookTest
{
	private String title;
	private String expectedresult;
	
	public COJ_41_BookTest(String title,String expectedresult)
	{
		this.title=title;
		this.expectedresult=expectedresult;
	}

	@BeforeClass
	public static void verifyAbstractClass() 
	{
		String mname="";
		try 
		{
			Class c=Class.forName("COJ_41_Book");
			String mod=Modifier.toString(c.getModifiers());
			if(!(mod.equals("abstract")))
			{
				System.out.println("#####BookTest | FAILED | 0/10 | Book is not an abstract class.#####");
				System.exit(0);
			}

			System.out.println("#####BookTest | PASSED | 10/10 | Book is a valid abstract class.#####");

			Field f=c.getDeclaredField("title");
			System.out.println("#####BookTest | PASSED | 10/10 | field title defined.#####");
			
			mname="setter";
			Method m=c.getDeclaredMethod("setTitle",String.class);
			mod=Modifier.toString(m.getModifiers());
			if(!(mod.equals("abstract")))
			{
				System.out.println("#####BookTest | FAILED | 0/10 | abstract setter method not defined.#####");
				System.exit(0);
			}
			
			System.out.println("#####BookTest | PASSED | 10/10 | abstract setter method defined.#####");
		
			mname="getter";
			m=c.getDeclaredMethod("getTitle");
			mod=Modifier.toString(m.getModifiers());
			if(mod.equals("abstract"))
			{
				System.out.println("#####BookTest | FAILED | 0/10 | getter method must not be abstract.#####");
				System.exit(0);
			}
			
			System.out.println("#####BookTest | PASSED | 10/10 | getter method defined.#####");						
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####BookTest | FAILED | 0/10 | Book abstract class not defined.#####");
			System.exit(0);
		}
		catch(NoSuchFieldException nsfe) 
		{
			System.out.println("#####BookTest | FAILED | 0/10 | title field not defined.#####");
			System.exit(0);
		}
		catch(NoSuchMethodException nsme) 
		{
			System.out.println("#####BookTest | FAILED | 0/10 | "+mname+" method not defined.#####");
			System.exit(0);
		}
	}

	@BeforeClass
	public static void verifyClass() 
	{
		String mname="";

		try 
		{
			Class c=Class.forName("COJ_41_MyBook");
			if(!(c.getSuperclass().getName().equals("COJ_41_Book")))
			{			
				System.out.println("#####BookTest | FAILED | 0/10 | MyBook class does not extend Book abstract class.#####");
				System.exit(0);
			}

			System.out.println("#####BookTest | PASSED | 10/10 | MyBook class extends Book abstract class.#####");

			mname="setter";
			Method m=c.getDeclaredMethod("setTitle",String.class);
			System.out.println("#####BookTest | PASSED | 10/10 | abstract setter method overrided.#####");
		
			mname="getter";
			m=c.getDeclaredMethod("getTitle");
			System.out.println("#####BookTest | PASSED | 10/10 | getter method overrided.#####");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####BookTest | FAILED | 0/10 | MyBook class not defined.#####");
			System.exit(0);
		}
		catch(NoSuchMethodException nsme) 
		{
			System.out.println("#####BookTest | FAILED | 0/10 | "+mname+" method not defined.#####");
			System.exit(0);
		}
	}

	@Parameters
	public static Collection<Object[]> data()
	{
		return Arrays.asList(new Object[][]{{"A Tale of 2 Cities","The title of my book is : A Tale of 2 Cities"}});
	}

	@Test
	public void testCase()
	{
		COJ_41_MyBook mybobj=new COJ_41_MyBook();
		
		mybobj.setTitle(title);
		String result=mybobj.getTitle();
		
		String message="TEST VALUE = "+title+", EXPECTED RESULT="+expectedresult+", ACTUAL RESULT="+result;
		
		try
		{
			Assert.assertEquals(expectedresult,result);

			System.out.println("#####BookTest | PASSED | 30/30 | "+message+"#####");
		}
		catch(AssertionError aserr)
		{
			System.out.println("#####BookTest | FAILED | 30/30 | "+message+"#####");			
		}
	}
}

