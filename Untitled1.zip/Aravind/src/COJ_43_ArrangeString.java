class COJ_43_ArrangeString
{
	String arrange(String str1,String str2)
   	{
		String result="";

		int sum=str1.length()+str2.length();
		result+=sum;
        
		if(str1.compareTo(str2)<=0)
			result+="\tNo";
        	else 
			result+="\tYes";
	
	        result+="\t"+str1.substring(0,1).toUpperCase()+str1.substring(1)+" "+str2.substring(0,1).toUpperCase()+str2.substring(1);

      		return result;
   	}	
}
