import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.junit.BeforeClass;
import java.util.Arrays;
import java.util.Collection;
import java.lang.reflect.Method;

@RunWith(Parameterized.class)
public class COJ_43_ArrangeStringTest
{
	private String str1;
	private String str2;
	private String expectedresult;
	
	public COJ_43_ArrangeStringTest(String str1,String str2,String expectedresult)
	{
		this.str1=str1;
		this.str2=str2;
		this.expectedresult=expectedresult;
	}

	@BeforeClass
	public static void verifyClass() 
	{
		String mname="";
		try 
		{
			Class c=Class.forName("COJ_43_ArrangeString");
			System.out.println("#####ArrangeStringTest | PASSED | 20/20 | ArrangeString is a valid class not an abstract class.#####");
			
			Method m=c.getDeclaredMethod("arrange",String.class,String.class);
			System.out.println("#####ArrangeStringTest | PASSED | 20/20 | arrange method defined.#####");
		
			String rtype=m.getReturnType().getName();
			if(!(rtype.equals("java.lang.String")))
			{
				System.out.println("#####ArrangeStringTest | FAILED | 0/20 | arrange method does not have String return type.#####");
				System.exit(0);
			}
			System.out.println("#####ArrangeStringTest | PASSED | 20/20 | arrange method have String return type.#####");
		} 
		catch(ClassNotFoundException cnfe) 
		{
			System.out.println("#####ArrangeStringTest | FAILED | 0/100 | ArrangeString class not defined.#####");
			System.exit(0);
		}
		catch(NoSuchMethodException nsme) 
		{
			System.out.println("#####ArrangeStringTest | FAILED | 0/100 | arrange method not defined.#####");
			System.exit(0);
		}
	}

	@Parameters
	public static Collection<Object[]> data()
	{
		return Arrays.asList(new Object[][]{{"hello","java","9\tNo\tHello Java"}});
	}

	@Test
	public void testCase()
	{
		COJ_43_ArrangeString asobj=new COJ_43_ArrangeString();
		
		String result=asobj.arrange(str1,str2);
		
		String message="TEST VALUE 1="+str1+", TEST VALUE 2="+str2+", EXPECTED RESULT="+expectedresult+", ACTUAL RESULT="+result;
		
		try
		{
			Assert.assertEquals(expectedresult,result);

			System.out.println("#####ArrangeStringTest | PASSED | 40/40 | "+message+"#####");
		}
		catch(AssertionError aserr)
		{
			System.out.println("#####ArrangeStringTest | FAILED | 0/40 | "+message+"#####");			
		}
	}
}

