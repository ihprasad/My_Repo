public class COJ_42_Sports
{
	String getName()
   	{
      		return "Sports";
   	}
   	
	String getNumberOfTeamMembers()
   	{
       		return "Each team has n players in "+getName();
   	}
}

class COJ_42_Soccer extends COJ_42_Sports
{
	String getName()
   	{
      		return "Soccer";
   	}

	String getNumberOfTeamMembers()
   	{
       		return "In "+getName()+",\teach team has 11 players.";
   	}
}
