import static org.junit.Assert.*;

import org.junit.Test;

public class ECC_54_DecryptionTest {

	@Test
	public void testDecrypt() {
		try

		{
			assertEquals("abc", ECC_54_Decryption.decrypt("zyx"));
			assertEquals("zyx", ECC_54_Decryption.decrypt("abc"));
			System.out
					.println("#####testDecrypt|Passed|60/60|Decrypting text#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testDecrypt|Failed|0/60|Decrypting text#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testDecrypt|Failed|0/100|No such method found  : could not find method decrypt(String)#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testDecrypt|Failed|0/60|Runtime Exception:"
							+ e.getClass() + "#####");
		}
	}

	@Test
	public void testDecryptWithSpeChars() {
		try

		{
			assertNull(ECC_54_Decryption.decrypt("ab2c"));
			assertNull(ECC_54_Decryption.decrypt("zyx#"));
			System.out
					.println("#####testDecryptWithSpeChars|Passed|20/20|Checking with special characters#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testDecryptWithSpeChars|Failed|0/20|Checking with special characters#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testDecrypt|Failed|0/100|No such method found  : could not find method decrypt(String)#####");
			System.exit(0);
		} catch (Exception e) {
			System.out
					.println("#####testDecryptWithSpeChars|Failed|0/20|Runtime Exception:"
							+ e.getClass() + "#####");
		}
	}

	@Test
	public void testDecryptWithNull() {
		try

		{
			assertEquals(null, ECC_54_Decryption.decrypt(null));

			System.out
					.println("#####testDecryptWithNull|Passed|20/20|with null input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testDecryptWithNull|Failed|0/20|with null input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testDecrypt|Failed|0/100|No such method found  : could not find method decrypt(String)#####");
			System.exit(0);
		} catch (Exception e) {
			System.out
					.println("#####testDecryptWithNull|Failed|0/20|Runtime Exception:"
							+ e.getClass() + "#####");
		}
	}

}
