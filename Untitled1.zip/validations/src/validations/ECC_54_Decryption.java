package validations;

public class ECC_54_Decryption {
	
	static String pt = "abcdefghijklmnopqrstuvwxyz";
	static String ct = "zyxwvutsrqponmlkjihgfedcba";
	
	static String decrypt(String cpt){
		String s = "";
		char ch;
		for(int i = 0; i < cpt.length(); i++){
			s += pt.charAt(ct.indexOf(cpt.charAt(i)));
		}
		return s;
	}
	
	public static void main(String[] args) {
		ECC_54_Decryption e = new ECC_54_Decryption();
		System.out.println(e.decrypt("cat"));
	}
	

}
