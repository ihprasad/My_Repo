
public class ECC_55_MajorMinor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
	public static boolean isMajor(int gender, int age) {
		
		return ((gender == 1 && age >= 18) || (gender == 2 && age >= 21)) && (age > 0 && age < 100);
		
	}

}
