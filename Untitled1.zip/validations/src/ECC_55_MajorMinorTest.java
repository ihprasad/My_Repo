import static org.junit.Assert.*;

import org.junit.Test;


public class ECC_55_MajorMinorTest {

	@Test
	public void testIsMajorWithTrue() {
		try

		{
			
			assertTrue(ECC_55_MajorMinor.isMajor(1, 18));
			assertTrue(ECC_55_MajorMinor.isMajor(1, 68));
			assertTrue(ECC_55_MajorMinor.isMajor(2, 21));
			assertTrue(ECC_55_MajorMinor.isMajor(2, 55));
			
			System.out
			.println("#####testIsMajorWithTrue|Passed|25/25|with values that are valid for major#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testIsMajorWithTrue|Failed|0/25|with values that are valid for major#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testIsMajorWithTrue|Failed|0/25|No such method found : could not find method isMajor(int, int)#####");

		} catch (Exception e) {
			System.out
			.println("#####testIsMajorWithTrue|Failed|0/25|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}

	@Test
	public void testIsMajorWithFalse() {
		try

		{
			
			assertFalse(ECC_55_MajorMinor.isMajor(1, 8));
			assertFalse(ECC_55_MajorMinor.isMajor(1, 1));
			assertFalse(ECC_55_MajorMinor.isMajor(2, 18));
			assertFalse(ECC_55_MajorMinor.isMajor(2, 3));
			
			System.out
			.println("#####testIsMajorWithFalse|Passed|25/25|with values that are valid for minor#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testIsMajorWithFalse|Failed|0/25|with values that are valid for minor#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testIsMajorWithFalse|Failed|0/25|No such method found : could not find method isMajor(int, int)#####");

		} catch (Exception e) {
			System.out
			.println("#####testIsMajorWithFalse|Failed|0/25|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}
	
	@Test
	public void testGreaterAge() {
		try

		{
			
			assertFalse(ECC_55_MajorMinor.isMajor(1, 100));
			assertFalse(ECC_55_MajorMinor.isMajor(2, 180));
			
			System.out
			.println("#####testGreaterAge|Passed|25/25|with larger values as input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGreaterAge|Failed|0/25|with larger values as input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGreaterAge|Failed|0/25|No such method found : could not find method isMajor(int, int)#####");

		} catch (Exception e) {
			System.out
			.println("#####testGreaterAge|Failed|0/25|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}
	
	@Test
	public void testNegative() {
		try

		{
			
			assertFalse(ECC_55_MajorMinor.isMajor(-1, 28));
			assertFalse(ECC_55_MajorMinor.isMajor(1, -28));
			assertFalse(ECC_55_MajorMinor.isMajor(-2, 18));
			assertFalse(ECC_55_MajorMinor.isMajor(2, -20));
			
			System.out
			.println("#####testNegative|Passed|25/25|with negative values as input#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testNegative|Failed|0/25|with negative values as input#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testNegative|Failed|0/25|No such method found : could not find method isMajor(int, int)#####");

		} catch (Exception e) {
			System.out
			.println("#####testNegative|Failed|0/25|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}
	
	

	
}
