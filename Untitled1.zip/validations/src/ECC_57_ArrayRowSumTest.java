import static org.junit.Assert.*;

import org.junit.Test;


public class ECC_57_ArrayRowSumTest {

	@Test
	public void testGetRowSumWithNull() {
		try{
				assertNull(ECC_57_ArrayRowSum.getRowSum(null));						
			System.out
			.println("#####testGetRowSumWithNull|Passed|10/10|with null value#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetRowSumWithNull|Failed|0/10|with null value#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetRowSumWithNull|Failed|0/10|No such method found : could not find method getRowSum(int[][])#####");

		} catch (Exception e) {
			System.out
			.println("#####testGetRowSumWithNull|Failed|0/10|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}

	@Test
	public void testGetRowSumWith2By2() {
		try

		{
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[2][2]));
			System.out
			.println("#####testGetRowSumWith2By2|Passed|10/10|for checking array size 3 X 3#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetRowSumWith2By2|Failed|0/10|for checking array size 3 X 3#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetRowSumWithNull|Failed|0/10|No such method found : could not find method getRowSum(int[][])#####");

		} catch (Exception e) {
			System.out
			.println("#####testGetRowSumWith2By2|Failed|0/10|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}

	@Test
	public void testGetRowSumWith3By3() {
		try

		{
				int[] actual = ECC_57_ArrayRowSum.getRowSum(new int[][]{{10, 20, 30},{40,50,60},{70,80,90}});
				assertEquals(60, actual[0]);
				assertEquals(150, actual[1]);
				assertEquals(240, actual[2]);
			System.out
			.println("#####testGetRowSumWith3By3|Passed|60/60|Getting row-wise sum#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetRowSumWith3By3|Failed|0/60|Getting row-wise sum#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetRowSumWith3By3|Failed|0/60|No such method found : could not find method getRowSum(int[][])#####");

		} catch (Exception e) {
			System.out
			.println("#####testGetRowSumWith3By3|Failed|0/60|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}
	
	@Test
	public void testGetRowSumWith4By4() {
		try

		{
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[4][4]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[4][3]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[4][2]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[2][4]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[3][4]));
			System.out
			.println("#####testGetRowSumWith4By4|Passed|10/10|for checking array size 4 X 4#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testGetRowSumWith4By4|Failed|0/10|for checking array size 4 X 4#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testGetRowSumWith4By4|Failed|0/10|No such method found : could not find method getRowSum(int[][])#####");

		} catch (Exception e) {
			System.out
			.println("#####testGetRowSumWith4By4|Failed|0/10|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}
	
	@Test
	public void testWithDistinctDimentions() {
		try

		{
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[4][3]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[4][2]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[2][4]));
				assertNull(ECC_57_ArrayRowSum.getRowSum(new int[3][4]));
			System.out
			.println("#####testWithDistinctDimentions|Passed|10/10|for checking array distinct dimentions#####");

		} catch (AssertionError e) {
			System.out
					.println("#####testWithDistinctDimentions|Failed|0/10|for checking array distinct dimentions#####");
		} catch (NoSuchMethodError e) {
			System.out
					.println("#####testWithDistinctDimentions|Failed|0/10|No such method found : could not find method getRowSum(int[][])#####");

		} catch (Exception e) {
			System.out
			.println("#####testWithDistinctDimentions|Failed|0/10|Runtime Exception:"
					+ e.getClass()+"#####");
		}
	}

	
}
