
public class ECC_57_ArrayRowSum {

	public static void main(String[] args) {
		int[] res = getRowSum(new int[][]{{10, 20, 30},{40,50,60},{70,80,90}});
		for(int i : res){
			System.out.println(i);
		}
		
		
	}
	
	public static int[] getRowSum(int[][] arr){
		
		if (arr == null || arr.length != 3 || arr[0].length != 3 || arr[1].length != 3 || arr[2].length != 3)
			return null;
		
		int[] sums = new int[arr.length];
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				sums[i] += arr[i][j];	
			}
		}
		
		return sums;
		
	}
}
