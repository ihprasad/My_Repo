
public class ECC_54_Decryption {

	public static void main(String[] args) {
		System.out.println(decrypt("zyx"));
		System.out.println(decrypt("talent2"));

	}
	
	public static String decrypt(String cipherText) {
		final String plain = "abcdefghijklmnopqrstuvwxyz";
		final String cipher = "zyxwvutsrqponmlkjihgfedcba";
		String plainText = "";
		
		if (cipherText == null)
			return null;
		int ch = 0;
		for (int i = 0; i < cipherText.length(); i++) {
			ch = cipher.indexOf(cipherText.charAt(i));
			if (ch == -1)
				return null;
			plainText += plain.charAt(ch); 
		}
		return plainText;
	}
}
