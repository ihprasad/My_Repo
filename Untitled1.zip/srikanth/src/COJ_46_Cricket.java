
public class COJ_46_Cricket {

}