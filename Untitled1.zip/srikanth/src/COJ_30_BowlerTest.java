import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_30_BowlerTest extends TestCase {

	PrintStream originalOut = System.out;
	OutputStream os = new ByteArrayOutputStream();
	PrintStream ps = new PrintStream(os);

	COJ_30_Bowler obj;

	@BeforeClass
	protected void setUp() throws Exception {
		super.setUp();
		obj = new COJ_30_Bowler();
		System.setOut(ps);
	}

	@After
	public void cleanUpStreams() {
		// Restore normal operation
		System.setOut(originalOut);

		System.setOut(null);
		System.setErr(null);

	}

	@Test
	public void testParametrizedConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			// boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for Batsman

			cons = new COJ_30_Bowler().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals(
						"COJ_30_Bowler(java.lang.String,int,int,int,int)")) {
					found = true;
					break;
				}
			}
			assertTrue("COJ_30_Bowler(java.lang.String,int,int,int,int) ",
					found);
			// originalOut
			originalOut
					.println("#####testParametrizedConstructors|Passed|5/5|Checking for parameterized constructor.#####");

		} catch (AssertionError ae) {
			// originalOut
			originalOut
					.println("#####testParametrizedConstructors|Failed|0/5|Parametrized Constructor definition not found: "
							+ ae.getMessage() + ".#####");

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testParametrizedConstructors|Failed|0/5|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testParametrizedConstructors|Failed|0/5|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDefaultConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			// boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for Batsman

			cons = new COJ_30_Bowler().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals("COJ_30_Bowler()")) {
					found = true;
					break;
				}
			}
			assertTrue("COJ_30_Bowler() ", found);
			// originalOut
			originalOut
					.println("#####testDefaultConstructors|Passed|5/5|Checking for default constructor.#####");

		} catch (AssertionError ae) {
			// originalOut
			originalOut
					.println("#####testDefaultConstructors|Failed|0/5|Default Constructor definition not found: "
							+ ae.getMessage() + ".#####");

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testDefaultConstructors|Failed|0/5|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testDefaultConstructors|Failed|0/5|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativeWicketsBA() {
		try {
			new COJ_30_Bowler("Sachin", -1, 1, 1, 1).computeBowlingAverage();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative wickets as input to calculate BowlingAverage.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative wickets as input to calculate BowlingAverage: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativematchesBA() {
		try {
			new COJ_30_Bowler("Sachin", 1, -1, 1, 1).computeBowlingAverage();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative matches as input to calculate BowlingAverage.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative matches as input to calculate BowlingAverage: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativeBallsBA() {
		try {
			new COJ_30_Bowler("Sachin", 1, 1, -1, 1).computeBowlingAverage();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative balls_bowled as input to calculate BowlingAverage.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative balls_bowled as input to calculate BowlingAverage: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	@Test
	public void testNegativeRunsBA() {
		try {
			new COJ_30_Bowler("Sachin", 1, 1, 1, -1).computeBowlingAverage();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative runs_conceded as input to calculate BowlingAverage.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative runs_conceded0 as input to calculate BowlingAverage: "
								+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativeWicketsSR() {
		try {
			new COJ_30_Bowler("Sachin", -1, 1, 1, 1).computeStrikeRate();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative wickets as input to calculate StrikeRate.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative wickets as input to calculate StrikeRate: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativematchesSR() {
		try {
			new COJ_30_Bowler("Sachin", 1, -1, 1, 1).computeStrikeRate();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative matches as input to calculate StrikeRate.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative matches as input to calculate StrikeRate: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativeBallsSR() {
		try {
			new COJ_30_Bowler("Sachin", 1, 1, -1, 1).computeStrikeRate();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative balls_bowled as input to calculate StrikeRate.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative balls_bowled as input to calculate StrikeRate: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	@Test
	public void testNegativeRunsSR() {
		try {
			new COJ_30_Bowler("Sachin", 1, 1, 1, -1).computeStrikeRate();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative runs_conceded as input to calculate StrikeRate.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative runs_conceded0 as input to calculate StrikeRate: "
								+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	@Test
	public void testNegativeWicketsStats() {
		try {
			new COJ_30_Bowler("Sachin", -1, 1, 1, 1).showStatistics();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative wickets as input to showStatistics.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative wickets as input to showStatistics: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativematchesStats() {
		try {
			new COJ_30_Bowler("Sachin", 1, -1, 1, 1).showStatistics();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative matches as input to showStatistics.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative matches as input to showStatistics: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testNegativeBallsStats() {
		try {
			new COJ_30_Bowler("Sachin", 1, 1, -1, 1).showStatistics();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative balls_bowled as input to showStatistics.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative balls_bowled as input to showStatistics: "
								+ ae.getMessage() + "#####");
			}
		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	@Test
	public void testNegativeRunsStats() {
		try {
			new COJ_30_Bowler("Sachin", 1, 1, 1, -1).showStatistics();
			try {
				assertEquals("Error\n", os.toString());
				originalOut
						.println("#####testNegativeValues|Passed|2/2|Passed for negative runs_conceded as input to showStatistics.#####");
			} catch (AssertionError ae) {
				originalOut
						.println("#####testNegativeValues|Failed|0/2|Failed for negative runs_conceded0 as input to showStatistics: "
								+ ae.getMessage() + "#####");
			}

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testNegativeValues|Failed|0/2|Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testComputeBowlingAverage() {
		try {
			obj = new COJ_30_Bowler("Sachin", 10, 5, 750, 463);
			obj.computeBowlingAverage();
			assertEquals("Name=Sachin\nbowling_avg=46.3\n", os.toString());

			originalOut
					.println("#####testComputeBowlingAverage|Passed|18/18|Checking for computeBowlingAverage method in COJ_30_Bowler.#####");
		} catch (AssertionError ae) {
			originalOut
					.println("#####testComputeBowlingAverage|Failed|0/18|Checking for computeBowlingAverage method in COJ_30_Bowler: "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testComputeBowlingAverage | Failed | 0/18 | No such method found: "
							+ e.getMessage() + "#####");

		}catch (Exception e) {
			originalOut
					.println("#####testComputeBowlingAverage|Failed|0/18|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
	
	@Test
	public void testComputeStrikeRate() {
		try {
			obj = new COJ_30_Bowler("Sachin", 10, 5, 750, 463);
			obj.computeStrikeRate();
			assertEquals("Name=Sachin\nStrike_rate=0.61733335\n", os.toString());

			originalOut
					.println("#####testComputeStrikeRate|Passed|18/18|Checking for computeStrikeRate method in COJ_30_Bowler.#####");
		} catch (AssertionError ae) {
			originalOut
					.println("#####testComputeStrikeRate|Failed|0/18|Checking for computeStrikeRate method in COJ_30_Bowler: "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testComputeStrikeRate | Failed | 0/18 | No such method found: "
							+ e.getMessage() + "#####");

		}catch (Exception e) {
			originalOut
					.println("#####testComputeStrikeRate|Failed|0/18|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public void testShowStatistics() {
		try {
			obj = new COJ_30_Bowler("Sachin", 10, 5, 750, 463);
			obj.showStatistics();
			assertEquals("Name=Sachin\nwickets=10\nmatches=5\nballs_bowled=750\nruns_conceded=463\n", os.toString());

			originalOut
					.println("#####testShowStatistics|Passed|20/20|Checking for showStatistics method in COJ_30_Bowler.#####");
		} catch (AssertionError ae) {
			originalOut
					.println("#####testShowStatistics|Failed|0/20|Checking for showStatistics method in COJ_30_Bowler: "
							+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			originalOut
					.println("#####testShowStatistics | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		}catch (Exception e) {
			originalOut
					.println("#####testShowStatistics|Failed|0/20|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

}
