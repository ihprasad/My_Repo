public class COJ_45_Batsman {
	// Four variables
	String name;
	int runs;
	int matches;
	float batting_avg;

	COJ_45_Batsman() {
		super();
		// TODO Auto-generated constructor stub
	}

	// One Constructor with three arguments
	COJ_45_Batsman(String name, int runs, int matches) {
		this.name = name;
		this.runs = runs;
		this.matches = matches;
	}

	// two methods - computeBattingAverage() and getStatistics()
	public void computeBattingAverage() {
		if ((runs < 0 || matches < 0) || (matches == 0 && runs > 0)){
			System.out.println("Error");
			return;
		}
		
		if (matches == 0){ 
			batting_avg = 0;
		}  else {
			batting_avg = (float) runs / matches;			
		}
		
		System.out.println("Name: " + name);
		System.out.println("Batting_Avg: " + batting_avg);
	}

	public void getStatistics() {
		if ((runs < 0 || matches < 0) || (matches == 0 && runs > 0)) {
			System.out.println("Error");
			return;
		}  
			System.out.println("Name: " + name);
			System.out.println("Runs: " + runs);
			System.out.println("Matches: " + matches);
		

	}
}

class COJ_45_Testing {

	public static void main(String[] args2) {
		COJ_45_Batsman b = new COJ_45_Batsman("Sachin", 18000, 463);
		b.getStatistics();
		b.computeBattingAverage();
	}
}