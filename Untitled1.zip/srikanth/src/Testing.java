import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Testing {

	public static void main(String[] args2) {
		COJ_30_Bowler bowler = new COJ_30_Bowler("Sachin", 10, 5, 750, 463);
		
		bowler.computeBowlingAverage();
		System.out.println("------------");
		bowler.computeStrikeRate();
		System.out.println("------------");
		bowler.showStatistics();
		
		
//		COJ_45_Batsman bat = new COJ_45_Batsman("Sachin", 10, 0);
//		
//		bat.computeBattingAverage();
//	      
	}
}