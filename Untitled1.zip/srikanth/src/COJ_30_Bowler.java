public class COJ_30_Bowler {
	// Six variables
	String name;
	int wickets;
	int matches;
	int balls_bowled;
	int runs_conceded;

	
	COJ_30_Bowler(){
		
	}
	// One Constructor with five arguments
	COJ_30_Bowler(String name, int wickets, int matches,
			int balls_bowled, int runs_conceded) {
		this.name = name;
		this.wickets = wickets;
		this.matches = matches;
		this.balls_bowled = balls_bowled;
		this.runs_conceded = runs_conceded;
	}

	// three methods - computeBowlingAverage(), computeEconomyRate() and
	// //getStatistics()
	public void computeBowlingAverage() {
		if((runs_conceded < 0 || balls_bowled < 0) || (runs_conceded > 0 && balls_bowled == 0) || matches < 0 || wickets < 0 || (matches == 0 && (balls_bowled > 0 || runs_conceded > 0))){
			System.out.println("Error");
			return;
		}
		float bowling_avg = (float) runs_conceded / wickets;
		System.out.println("Name=" + name);
		System.out.println("bowling_avg=" + bowling_avg);
	}

	public void computeStrikeRate() {
		if((runs_conceded < 0 || balls_bowled < 0) || (runs_conceded > 0 && balls_bowled == 0) || matches < 0 || wickets < 0 || (matches == 0 && (balls_bowled > 0 || runs_conceded > 0))){
			System.out.println("Error");
			return;
		}
		float strike_rate = (float) runs_conceded
				/ balls_bowled;
		System.out.println("Name=" + name);
		System.out.println("Strike_rate=" + strike_rate);
	}

	public void showStatistics() {
		if((runs_conceded < 0 || balls_bowled < 0) || (runs_conceded > 0 && balls_bowled == 0) || matches < 0 || wickets < 0 || (matches == 0 && (balls_bowled > 0 || runs_conceded > 0))){
			System.out.println("Error");
			return;
		}
		System.out.println("Name=" + name);
		System.out.println("wickets=" + wickets);
		System.out.println("matches=" + matches);
		System.out.println("balls_bowled=" + balls_bowled);
		System.out.println("runs_conceded="
				+ runs_conceded);
//		System.out.println("-----------");
	}

}
