import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_45_BatsmanTest1 extends TestCase {
	
	

	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// Test for fields
		
		System.out.println("Test");

		try {
			Class.forName("COJ_45_Batsman");
			

			Field[] fld = COJ_45_Batsman.class.getDeclaredFields();
			try {
				for (Field f : fld) {
					// System.out.println(f.getGenericType().toString());
					if ("runs".equals(f.getName()))
						assertTrue("Field 'id' not defined ", f
								.getGenericType().toString().equals("int"));

					if ("name".equals(f.getName()))
						assertTrue(
								"Field 'name' not defined ",
								f.getGenericType().toString()
										.equals("java.lang.String"));

					if ("matches".equals(f.getName()))
						assertTrue("Field 'basicSalary' not defined ", f
								.getGenericType().toString().equals("int"));
					if ("batting_avg".equals(f.getName()))
						assertTrue("Field 'HRAPer' not defined ", f
								.getGenericType().toString().equals("float"));
				}

			} catch (AssertionError ae) {
				System.out
						.println("#####testBatsmanFields | Failed | 0/4 | Checking for fields in COJ_45_Batsman: "
								+ ae.getMessage() + "#####");
			}

		} catch (ClassNotFoundException ce) {
			System.out
					.println("#####testClassDefinition | Failed | 0/50 |Class definition not found: "
							+ ce.getMessage() + " #####");
			System.exit(0);
		} catch (Exception e) {
			System.out
					.println("#####testClassDefinetion | Failed | 0/50 |Runtime Exception: "
							+ e.getMessage() + " #####");
			System.exit(0);
		}

	}


	/*@Test
	public void testComputeBattingAverage() {
//		System.out.println("Done");
		
		
		obj = new COJ_45_Batsman("Sachin", 18000, 463);
		obj.computeBattingAverage();
		try {
			
			assertEquals("Batting_Avg: 38.87689", os.toString());
//			System.setOut(originalOut);
			originalOut.println("Correct");
//			System.out.println("Done");
		} catch (AssertionError as) {
			originalOut.println("Error");
		}
	}*/

	@Test
	public void testConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for employee

			cons = new COJ_45_Batsman().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				if (con.toString().equals(
						"COJ_45_Batsman(java.lang.String,int,int)")) {
					found = true;
					break;
				}
			}
			assertTrue("COJ_45_Batsman(java.lang.String,int,int) ", found);
			System.out
			.println("#####testConstructors | Passed | 40/40 | Checking for parameterized constructor.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testConstructors | Failed | 0/4 | Constructor definition not found: "
							+ ae.getMessage() + ". #####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testConstructors | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testConstructors | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
	

//	@Test
//	public final void test() {
//		fail("Not yet implemented"); // TODO
//		//System.out.println("Done1");
//	}

}
