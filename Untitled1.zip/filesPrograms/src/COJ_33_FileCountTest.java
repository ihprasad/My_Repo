import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;

import org.junit.BeforeClass;
import org.junit.Test;

public class COJ_33_FileCountTest {

	static File f;
	COJ_33_FileCount obj;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		f = new File("/usercode/COJ_33.txt");
	}

	@Test
	public void testGetWordCount() {
		try {
			try {
				obj = new COJ_33_FileCount();

				assertEquals(10, obj.getWordCount(f));

				System.out
						.println("#####testGetWordCount|Passed|30/30|Passed for getWordCount method in COJ_33_FileCount.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetWordCount|Failed|0/30|Failed for getWordCount method in COJ_33_FileCount: "
								+ ae.getMessage() + "#####");

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetWordCount | Failed | 0/30 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetWordCount|Failed|0/30|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
	
	@Test
	public void testGetLineCount() {
		try {
			try {
				obj = new COJ_33_FileCount();

				assertEquals(3, obj.getLineCount(f));

				System.out
						.println("#####testGetLineCount|Passed|30/30|Passed for getLineCount method in COJ_33_FileCount.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetLineCount|Failed|0/30|Failed for getLineCount method in COJ_33_FileCount: "
								+ ae.getMessage() + "#####");

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetLineCount | Failed | 0/30 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetLineCount|Failed|0/30|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}
	
	@Test
	public void testGetCharacterCount() {
		try {
			try {
				obj = new COJ_33_FileCount();

				assertEquals(29, obj.getCharacterCount(f));

				System.out
						.println("#####testGetCharacterCount|Passed|40/40|Passed for getCharacterCount method in COJ_33_FileCount.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testGetCharacterCount|Failed|0/40|Failed for getCharacterCount method in COJ_33_FileCount: "
								+ ae.getMessage() + "#####");

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetCharacterCount | Failed | 0/40 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetCharacterCount|Failed|0/CharacterCount|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

//	@Test
//	public final void test() {
//		fail("Not yet implemented"); // TODO
//	}

}
