import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class COJ_33_FileCount {

	public static void main(String[] args) {
		File f = new File("inFile.txt");
		COJ_33_FileCount f1 = new COJ_33_FileCount();
		System.out.println(f1.getWordCount(f));
		System.out.println("=======" + f1.getCharacterCount(f));
		System.out.println(f1.getLineCount(f));
	}

	int getWordCount(File inputFile) {
		int count = 0;
		try {
			FileReader fr = new FileReader(inputFile);
			BufferedReader br = new BufferedReader(fr);


				String line = br.readLine();
				while (line != null) {
					String[] parts = line.split(" ");
					for (String w : parts) {
						count++;
					}
					line = br.readLine();
				}

		} catch (FileNotFoundException e) {
			return -1;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return count;
	}

	int getCharacterCount(File file) {
		FileReader fr = null;
		int charCount = 0;

		try {
			fr = new FileReader(file);
			int c = fr.read();
			while (c > -1) {
				if (((char) c != ' ') && ((char) c != '\n')) {
					// System.out.println((char) c + "---" + c);
					charCount++;
				}
				c = fr.read();
			}

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			if (null != fr)
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return charCount;
	}

	int getLineCount(File file) {
		int linenumber = 0;
		FileReader fr = null;
		try {
			fr = new FileReader(file);

			/**
			 * buffered character-input stream that keeps track of line numbers
			 */
			LineNumberReader lnr = new LineNumberReader(fr);
			while (lnr.readLine() != null) {
				linenumber++;
			}
			lnr.close();

			return linenumber;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			if (null != fr)
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return linenumber;
	}

}
