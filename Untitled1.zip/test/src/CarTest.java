import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.BeforeClass;
import org.junit.Test;

public class CarTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	
	


	@Test
	public void testGetFuel() {
		System.out.println("OK Car");
//		assertEquals(c.getFuel(), 0);
		
		try {
			System.out.println(Class.forName("Car").getModifiers() == Modifier.ABSTRACT);
			System.out.println(" tested");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
