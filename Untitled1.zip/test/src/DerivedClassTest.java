
import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class DerivedClassTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public final void testDisplay() {
		try {
			try {

				assertEquals(2, new com.DerivedClass().display());

				System.out
						.println("#####testDisplay|Passed|50/50|Passed for getCharacterCount method in COJ_33_FileCount.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testDisplay|Failed|0/50|Failed for getCharacterCount method in COJ_33_FileCount: "
								+ ae.getMessage() + "#####");

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplay | Failed | 0/50 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplay|Failed|0/CharacterCount|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

	@Test
	public final void testInheritance() {
		try {
			try {
				assertTrue((new com.DerivedClass().getClass().getSuperclass()
						.getName()).equals("com.ts.BaseClass"));

				System.out
						.println("#####testInheritance|Passed|50/50|Passed for getCharacterCount method in COJ_33_FileCount.#####");
			} catch (AssertionError ae) {
				System.out
						.println("#####testInheritance|Failed|0/50|Failed for getCharacterCount method in COJ_33_FileCount: "
								+ ae.getMessage() + "#####");

			}
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testInheritance | Failed | 0/50 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetCharacterCount|Failed|0/CharacterCount|Runtime Exception: "
							+ e.getMessage() + "#####");
			System.exit(0);
		}
	}

}
