
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*StaticTest st = new StaticTest();
		
		st.mrt(14);
		st.display();
		StaticTest s1 = new StaticTest();
		s1.mrt(10);
		s1.display();*/
		
		String[] e = {"for","tea","two"};
		String str = (e.length > 0) ? e[0] : null;
		System.out.println(str);
		

	}

}
