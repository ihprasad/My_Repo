
public class StaticTest {
	public static int count = 0;
	
	public void mrt(int n){
		if(n % 2 == 0)
			count++;
	}
	public void display(){
		System.out.println(count);
	}

}
