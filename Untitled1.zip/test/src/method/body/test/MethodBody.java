package method.body.test;

public class MethodBody {
	String name;
	int runs;
	int matches;
	float batting_avg;
	
	public MethodBody() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	// One Constructor with three arguments
	public MethodBody(String name, int runs, int matches) {
		this.name = name;
		this.runs = runs;
		this.matches = matches;
	}

	// two methods - computeBattingAverage() and getStatistics()
	public void computeBattingAverage() {
		batting_avg = (float) runs / matches;
		System.out.println("Batting_Avg: " + batting_avg);
	}

	public void getStatistics() {
		System.out.println("Name: " + name);
		System.out.println("Runs: " + runs);
		System.out.println("Matches: " + matches);

	}

}
