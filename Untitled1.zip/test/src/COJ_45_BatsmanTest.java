import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.HashMap;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

import com.ts.COJ_45_Batsman;


public class COJ_45_BatsmanTest extends TestCase {

	PrintStream originalOut = System.out;
	OutputStream os = new ByteArrayOutputStream();
	PrintStream ps = new PrintStream(os);

	COJ_45_Batsman obj;

	@BeforeClass
	protected void setUp() throws Exception {
		super.setUp();
		obj = new COJ_45_Batsman();
		System.setOut(ps);
	}
	
	@Test
	public final void testFields() {
		
		int marks = 0;

		try {
			Class.forName("com.ts.COJ_45_Batsman");
			obj = new COJ_45_Batsman();

			Field[] fld = COJ_45_Batsman.class.getDeclaredFields();
			ArrayList<String> fld1 = new ArrayList<String>();
			HashMap<String, String> hmap = new HashMap<String, String>();

			for (Field f : fld) {
				String key = f.getName();
				String value = f.getGenericType().getTypeName();

				hmap.put(key, value);

			}
			try {
				assertTrue("Field 'runs' not defined", hmap.containsKey("runs")
						&& hmap.get("runs").equals("int"));
				marks++;
			} catch (AssertionError ae) {
				originalOut
						.println("#####testBatsmanFields | Failed | 0/3 | Checking for fields in COJ_45_Batsman: "
								+ ae.getMessage() + "#####");
			}

			try {
				assertTrue("Field 'name' not defined", hmap.containsKey("name")
						&& hmap.get("name").equals("java.lang.String"));
				marks++;
			} catch (AssertionError ae) {
				originalOut
						.println("#####testBatsmanFields | Failed | 0/3 | Checking for fields in COJ_45_Batsman: "
								+ ae.getMessage() + "#####");
			}
			try {
				assertTrue("Field 'matches' not defined",
						hmap.containsKey("matches")
								&& hmap.get("matches").equals("int"));
				marks++;
			} catch (AssertionError ae) {
				originalOut
						.println("#####testBatsmanFields | Failed | 0/3 | Checking for fields in COJ_45_Batsman: "
								+ ae.getMessage() + "#####");
			}

			try {
				assertTrue(
						"Field 'batting_avg' not defined",
						hmap.containsKey("batting_avg")
								&& hmap.get("batting_avg").equals("float"));
				marks++;
			} catch (AssertionError ae) {
				originalOut
						.println("#####testBatsmanFields | Failed | 0/3 | Checking for fields in COJ_45_Batsman: "
								+ ae.getMessage() + "#####");
			}
			marks *= 2.5;
			
			originalOut.println("#####testBatsmanFields | Passed |" + marks +"/10 | Checking for fields in COJ_45_Batsman. #####");

		} catch (ClassNotFoundException ce) {
			originalOut
					.println("#####testBatsmanClass | Failed | 0/10 |Class definition not found: "
							+ ce.getMessage() + " #####");
			System.exit(0);
		} catch (Exception e) {
			originalOut
					.println("#####testBatsmanFields | Failed | 0/10 |Runtime Exception: "
							+ e.getMessage() + " #####");
			System.exit(0);
		}
	}

	@Test
	public final void testComputeBattingAverage() {
		try {
			obj = new COJ_45_Batsman("Sachin", 18000, 463);
			obj.computeBattingAverage();

			assertEquals("Batting_Avg: 38.87689\n", os.toString());
			originalOut
					.println("#####testComputeBattingAverage | Passed | 40/40 | Checking for computeBattingAverage method in COJ_45_Batsman. #####");
		} catch (AssertionError ae) {
			originalOut
					.println("#####testComputeBattingAverage | Failed | 0/40 | Checking for computeBattingAverage method in COJ_45_Batsman: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			originalOut
					.println("#####testClassDefinetion | Failed | 0/40 |Runtime Exception: "
							+ e.getMessage() + " #####");
			System.exit(0);
		}
	}

	@Test
	public final void testGetStatistics() {

		obj = new COJ_45_Batsman("Sachin", 18000, 463);
		obj.getStatistics();
		try {

			assertEquals("Name: Sachin\nRuns: 18000\nMatches: 463\n",
					os.toString());
			originalOut
					.println("#####testGetStatistics | Passed | 30/30 | Checking for getStatistics method in COJ_45_Batsman. #####");
		} catch (AssertionError ae) {
			originalOut
					.println("#####testBatsmanFields | Failed | 0/30 | Checking for getStatistics method in COJ_45_Batsman: "
							+ ae.getMessage() + "#####");
		} catch (Exception e) {
			originalOut
					.println("#####testClassDefinetion | Failed | 0/30 |Runtime Exception: "
							+ e.getMessage() + " #####");
			System.exit(0);
		}
	}

	@Test
	public void testParametrizedConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			// boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for Batsman

			cons = new COJ_45_Batsman().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
				
				if (con.toString().equals(
						"public com.ts.COJ_45_Batsman(java.lang.String,int,int)")) {
					found = true;
					originalOut.println("hai");
					break;
				}
				
			}
			assertTrue("COJ_45_Batsman(java.lang.String,int,int) ", found);
			// originalOut
			originalOut
					.println("#####testParametrizedConstructors | Passed | 10/10 | Checking for parameterized constructor.#####");

		} catch (AssertionError ae) {
			// originalOut
			originalOut
					.println("#####testParametrizedConstructors | Failed | 0/10 | Parametrized Constructor definition not found: "
							+ ae.getMessage() + ". #####");

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testParametrizedConstructors | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testParametrizedConstructors | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testDefaultConstructors() {
		try {
			Constructor[] cons;
			boolean found = false;
			// boolean accessible = false;
			int count = 0;
			int marks = 0;

			// constructor for Batsman

			cons = new COJ_45_Batsman().getClass().getDeclaredConstructors();
			for (Constructor con : cons) {
//				originalOut.println(con.toGenericString());
				if (con.toString().equals("public com.ts.COJ_45_Batsman()")) {
					found = true;
					break;
				}
			}
			assertTrue("COJ_45_Batsman() ", found);
			// originalOut
			originalOut
					.println("#####testDefaultConstructors | Passed | 10/10 | Checking for default constructor.#####");

		} catch (AssertionError ae) {
			// originalOut
			originalOut
					.println("#####testDefaultConstructors | Failed | 0/10 | Default Constructor definition not found: "
							+ ae.getMessage() + ". #####");

		} catch (NoSuchMethodError e) {

			// originalOut
			originalOut
					.println("#####testDefaultConstructors | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			// originalOut
			originalOut
					.println("#####testDefaultConstructors | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@After
	public void cleanUpStreams() {
		// Restore normal operation
		System.setOut(originalOut);

		System.setOut(null);
		System.setErr(null);

	}


}
