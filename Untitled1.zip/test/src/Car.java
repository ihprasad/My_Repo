abstract class Car {

  public void Car(int speed, int fuel) {
    this.speed = speed;
    this.fuel = fuel;
  }

  private int speed;
  private int fuel;

  abstract void drive();

  public int getSpeed() {
    return this.speed;
  }

  public int getFuel() {
    return this.fuel;
  }
}