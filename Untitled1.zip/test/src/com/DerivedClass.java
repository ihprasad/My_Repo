package com;

import com.ts.BaseClass;

public class DerivedClass extends BaseClass {
	public int display(){
		return 2;
	}

}
