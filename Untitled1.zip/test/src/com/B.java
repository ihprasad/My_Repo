package com;

public class B {

	static int a = 10;
	static {
		a = a++ + ++a;
	}

	//{
	//	a = a++ + ++a;
	//}

	public static void main(String[] args) {
		System.out.println(a);

	}

}