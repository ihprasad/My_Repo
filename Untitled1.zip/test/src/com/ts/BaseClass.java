package com.ts;

public class BaseClass {
	
	int display(){
		return 1;
	}

}
