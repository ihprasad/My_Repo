

//import static org.junit.Assert.*;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;


//import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

public class Class1Test extends TestCase {

	PrintStream originalOut = System.out;
	OutputStream os = new ByteArrayOutputStream();
	PrintStream ps = new PrintStream(os);

	Class1 obj;

	@BeforeClass
	protected void setUp() throws Exception {
		super.setUp();
		obj = new Class1();
		System.setOut(ps);

	}

	@After
	public void cleanUpStreams() {
		// Restore normal operation
		System.setOut(originalOut);

		System.setOut(null);
		System.setErr(null);
	}

	/*
	 * System.out.print testing
	 */

	@Test
	public final void testMyPrint() {
		// Prepare to capture output

		// System.setOut(ps);

		// Perform tests
		obj.test(1);
		try {
			assertEquals("One\ntwo", os.toString());
			// System.setOut(originalOut);
			originalOut.println("Correct");
		} catch (AssertionError as) {

			try {
				assertEquals("Error", os.toString());
				// System.setOut(originalOut);
				originalOut.println("Correct error");
			} catch (AssertionError afe) {
				// System.setOut(originalOut);
				originalOut.println("failed");
			}

		} finally {

		}
	}

	/*
	 * Test for System.out.println
	 */

	@Test
	public final void testMyPrintln() {
		String separator = System.getProperty("line.separator");
		obj.test(1);
		try {
			assertEquals("One" + separator + "two", os.toString());
			originalOut.println("Success for ln");
		} catch (AssertionError ae) {
			originalOut.println("failed for ln");
		}

	}

	

	// createStarPattern
	/*
	 * @Test public void isNegative() { try { Class1 obj = new Class1();
	 * assertEquals("-1", obj.createBoxPattern(-4, 5)); assertEquals("-1",
	 * obj.createBoxPattern(4, -5)); assertEquals("-1", obj.createBoxPattern(-4,
	 * -5));
	 * 
	 * System.out.println(
	 * "#####|isNegative|Passed|20/20|Checking for negative values as input|#####"
	 * ); } catch (AssertionError e) { System.out.println(
	 * "#####|isNegative|Failed|0/20|Checking for negative values as input|#####"
	 * ); } }
	 * 
	 * @Test public void isZero() { try { Class1 obj = new Class1();
	 * assertEquals("-2", obj.createBoxPattern(0, 5)); assertEquals("-2",
	 * obj.createBoxPattern(5, 0)); assertEquals("-2", obj.createBoxPattern(0,
	 * 0));
	 * 
	 * System.out.println(
	 * "#####|isZero|Passed|20/20|Checking for Zero as input|#####"); } catch
	 * (AssertionError e) { System.out.println(
	 * "#####|isZero|Failed|0/20|Checking for Zero as input|#####"); } }
	 * 
	 * 
	 * @Test public void isLargeNumber() { try { Class1 obj = new Class1();
	 * assertEquals("-3", obj.createBoxPattern(100)); System.out.println(
	 * "#####|isLargeNumber|Passed|20/20|Checking for larger value as input|#####"
	 * ); } catch (AssertionError e) { System.out.println(
	 * "#####|isLargeNumber|Failed|0/20|Checking for larger value as input|#####"
	 * ); } }
	 * 
	 * 
	 * @Test public void createBoxPattern() { try { Class1 obj = new Class1();
	 * assertEquals("* * * * *\n*       *\n*       *\n* * * * *",
	 * obj.createBoxPattern(4, 5)); assertEquals(
	 * "* * * * *\n*       *\n*       *\n*       *\n*       *\n* * * * *",
	 * obj.createBoxPattern(6, 5)); // assertEquals("1 2 3 4\n5 6 7 8\n9 10",
	 * obj.createBoxPattern(10)); System.out.println(
	 * "#####|createBoxPattern|Passed|40/40|Checking for numbers in given range in reverse order|#####"
	 * ); } catch (AssertionError e) { System.out.println(
	 * "#####|createBoxPattern|Failed|0/40|Checking for numbers in given range in reverse order|#####"
	 * ); } }
	 */

	
	
	/*
	
	@Test
	public void isNegative() {
		try {
			assertEquals("-1", obj.getFactorial(-5));
			System.out
					.println("#####|isNegative|Passed|20/20|Checking for negative values as input|#####");
		} catch (AssertionError e) {
			System.out
					.println("#####|isNegative|Failed|0/20|Checking for negative values as input|#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####|isNegative|Failed|0/20|Wrong method name:could not find method getFactorial()|#####");
		} catch (Exception e) {
			System.out.println("#####|isNegative|Failed|0/20|Runtime Exception:"
					+ e.getMessage() + "|#####");
		}
	}

	@Test
	public void isZero() {
		try {
			assertEquals("-2", obj.getFactorial(0));
			System.out
					.println("#####|isZero|Passed|20/20|Checking for four digit value as input|#####");
		} catch (AssertionError e) {
			System.out
					.println("#####|isZero|Failed|0/20|Checking for four digit value as input|#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####|isZero|Failed|0/20|Wrong method name:could not find method getFactorial()|#####");
		} catch (Exception e) {
			System.out.println("#####|isZero|Failed|0/20|Runtime Exception:"
					+ e.getMessage() + "|#####");
		}
	}

	@Test
	public void getFactorial() {
		try {
			assertEquals("ArmStrong Number", obj.getFactorial(1634));
			System.out
					.println("#####|getFactorial|Passed|30/30|Checking for NaturalNumbers number between two numbers|#####");
		} catch (AssertionError e) {
			System.out
					.println("#####|getFactorial|Failed|0/30|Checking for NaturalNumbers number between two numbers|#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####|getFactorial|Failed|0/20|Wrong method name:could not find method getFactorial()|#####");
		} catch (Exception e) {
			System.out.println("#####|getFactorial|Failed|0/20|Runtime Exception:"
					+ e.getMessage() + "|#####");
		}
	}

	@Test
	public void nonArmstrongNumbers() {
		try {
			MainTest obj = new MainTest();
			assertEquals("Not ArmStrong Number", obj.getFactorial(1633));
			System.out
					.println("#####|nonArmstrongNumbers|Passed|30/30|Checking for NaturalNumbers number between two numbers|#####");
		} catch (AssertionError e) {
			System.out
					.println("#####|nonArmstrongNumbers|Failed|0/30|Checking for NaturalNumbers number between two numbers|#####");
		} catch (NoSuchMethodError nsme) {
			System.out
					.println("#####|nonArmstrongNumbers|Failed|0/20|Wrong method name:could not find method getFactorial()|#####");
		} catch (Exception e) {
			System.out.println("#####|nonArmstrongNumbers|Failed|0/20|Runtime Exception:"
					+ e.getMessage() + "|#####");
		}
	}
	
*/	
	
	
}
