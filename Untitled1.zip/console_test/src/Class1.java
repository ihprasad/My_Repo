public class Class1 {
	public static void main(String[] args) {
		Class1 c = new Class1();
		// int n1 = 10;
		// int n2 = 45;
		// System.out.println(getGreatest(n1, n2));

		// printNos(11, 20);

		System.out.println(c.createBoxPattern(6, 5));
	}

	public static int getGreatest(int num1, int num2) {
		if (num1 < 0 || num2 < 0)
			return -1;
		if (num1 == 0 || num2 == 0)
			return -2;
		if (num1 > num2)
			return num1;
		return num2;
	}

	static void printNos(int n, int m) {
		if (n <= m) {
			printNos(n, m - 1);
			System.out.print(m + " ");
		}

	}

	public String getNaturalNumbers(int num1, int num2) {
		String result = "";

		if (num1 < 0 || num2 < 0)
			return "-1";
		if (num1 == 0 || num2 == 0)
			return "-2";
		else if (num1 <= num2) {
			if (num1 != num2)
				result += num1 + " ";
			else
				result += num1;

			return result += getNaturalNumbers(++num1, num2);
		}

		return result;
	}

	public String getNumbersInRange(int num1, int num2) {
		String result = "";

		if (num1 < 0 || num2 < 0)
			result = "-1";
		else if (num1 == num2)
			result = "-2";
		else if (num1 < num2)
			result = "-3";
		else {
			num1--;
			for (int i = num1; i > num2; i--) {
				if (!(i - num2 == 1))
					result += i + "\n"; // System.lineSeparator();
				else
					result += i;
			}
		}

		return result;
	}

	public String getNumbersInRange(int num1, int num2, int step) {
		String result = "";

		if (num1 < 0 || num2 < 0 || step < 0)
			result = "-1";
		else if (num1 == num2)
			result = "-2";
		else if (num1 > num2)
			result = "-3";
		else {
			for (int i = num1 + step; i < num2; i += step) {
				// if(i==num1||i==num2)
				// continue;
				// result += i;
				if ((num2 - step) < i)
					result += i;
				else
					result += i + " ";
			}
		}

		return result;
	}

	public String getFourPerLine(int num) {
		String result = "";

		if (num < 0)
			result = "-1";
		else if (num == 0)
			result = "-2";
		else if (num > 99)
			result = "-3";
		else {
			int counter = 1;
			for (int i = 1; i <= num; i++) {
				if ((i - num == 0) || counter == 4)
					result += i;
				else
					result += i + " ";

				if ((i - num != 0) && counter == 4) {
					result += "\n";
					counter = 0;
				}

				counter++;
			}
		}

		return result;
	}

	public String createBoxPattern(int rows, int cols) {
		String result = "";
		if (rows < 0 || cols < 0)
			return "-1";
		else if (rows == 0 || cols == 0)
			return "-2";
		else {
			for (int i = 1; i <= rows; i++) {
				for (int j = 1; j <= cols; j++) {
					if (i == 1 || i == rows) {
						if (j != cols)
							result += "*" + " ";
						else {
							if (i != rows)
								result += "*\n";
							else
								result += "*";
						}
					}
					else {
						if(j == 1)
							result += "*";
						else if(j == cols)
							result += " *\n";
						else
							result += "  ";
					}
				}
			}
			return result;
		}

	}
	
	public String createStarPattern(int rows)
	{
		String result="";
		
		if(rows<0)
			result="-1";
		else if(rows==0)
			result="-2";
		else
		{
			for(int i=1;i<=rows;i++)
			{
				for(int j=1;j<=i;j++)
				{
					result+="*"+" ";
				}
				result+="\n";
			}
		}
    		
		return result;
	}
	
	public void test(int i){
		if(i == 1){
			System.out.println("One");
		System.out.print("two");
		}
		else
			System.out.print("Error");
	}

}
