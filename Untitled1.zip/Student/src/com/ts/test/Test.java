package com.ts.test;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

			int i = Integer.parseInt("1");
			i = i / 0;

		} catch (ArithmeticException ae) {
			System.out.println("ae");
		}
		
		try {
			System.out.println("Test");
		}
		catch(Exception e){
			System.out.println("failed");
		}

	}

}
