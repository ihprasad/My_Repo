import static org.junit.Assert.*;

import java.lang.reflect.Field;

import org.junit.Test;

public class DayScholarTest {

	@Test
	public void testToStringDayScholar() {
		try {

			assertEquals(
					"DayScholar [transportFee=0.0, name=null, studentId=0, examFee=0.0]",
					new DayScholar().toString());
			assertEquals(
					"DayScholar [transportFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new DayScholar("TalentSprint", 101, 5000, 10000).toString());

			System.out
					.println("#####testToStringDayScholar | Passed | 20/20 | Checking for toString() in DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringDayScholar | Failed | 0/20 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringDayScholar | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringDayScholar | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsDayScholar() {
		try {

			assertEquals(
					"DayScholar [transportFee=0.0, name=null, studentId=0, examFee=0.0]",
					new DayScholar().displayDetails());
			assertEquals(
					"DayScholar [transportFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new DayScholar("TalentSprint", 101, 5000, 10000)
							.displayDetails());

			System.out
					.println("#####testDisplayDetailsDayScholar | Passed | 20/20 | Checking for displayDetails() in DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testDisplayDetailsDayScholar | Failed | 0/20 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsDayScholar | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsDayScholar | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testPayFeeDayScholar() {
		try {

			DayScholar pojo;
			pojo = new DayScholar();
			pojo.setExamFee(5000.0);
			pojo.setTransportFee(10000);

			assertEquals("Failed for payFee() in DayScholar, ", 12000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in DayScholar, ", 15000,
					new DayScholar("Talentsprint", 101, 10000.0, 15000)
							.payFee(10000), 0);

			System.out
					.println("#####testPayFeeDayScholar | Passed | 20/20 | Checking for payFee() in DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeDayScholar | Failed | 0/20 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeDayScholar | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeDayScholar | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDayScholar() {
		try {

			assertNotNull(new DayScholar());

			System.out
					.println("#####testDayScholar | Passed | 10/10 | Checking for default constructor of DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDayScholar | Failed | 0/10 | Checking for default constructor of DayScholar.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDayScholar | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testDayScholar | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDayScholarStringIntDoubleDouble() {
		try {
			assertNotNull(new DayScholar("Talentsprint", 101, 500.0, 1000));

			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Passed | 10/10 | Checking for parameterized constructor of DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Failed | 0/10 | Checking for parameterized constructor of DayScholar.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetTransportFee() {
		try {

			DayScholar pojo = new DayScholar();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass()
					.getDeclaredField("transportFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getTransportFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetTransportFee | Passed | 10/10 | Checking for getter method: getTransportFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetTransportFee | Failed | 0/10 | Checking for getter method: getTransportFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetTransportFee | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetTransportFee | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetTransportFee() {
		try {

			DayScholar pojo = new DayScholar();
			pojo.setTransportFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("transportFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetTransportFee | Passed | 10/10 | Checking for setter method: setTransportFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetTransportFee | Failed | 0/10 | Checking for setter method: setTransportFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetTransportFee | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetTransportFee | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
