public class DayScholar extends Student {

	double transportFee;
	 public DayScholar()
	 {
		 this.transportFee = 0;
	 }
	 
	 public DayScholar(String name, int studentId, double examFee,double tfee)
	 {
		 super(name,studentId,examFee);
		 this.transportFee = tfee;
	 }
	 public String toString() {
			return "DayScholar [transportFee="+transportFee+", name=" + name + ", studentId=" + studentId
					+ ", examFee=" + examFee  + "]";
		}
	 
	 public String displayDetails() {
			return this.toString();
		}

	public double payFee(double amount) {
			double toPay = (this.examFee + this.transportFee) - amount;
			return toPay;
		}

	public double getTransportFee() {
		return transportFee;
	}

	public void setTransportFee(double transportFee) {
		this.transportFee = transportFee;
	}
}
