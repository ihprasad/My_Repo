import static org.junit.Assert.*;

import java.lang.reflect.Field;

import org.junit.BeforeClass;
import org.junit.Test;

public class StudentTest {

	@Test
	public void testGetName() {
		try {

			Student pojo = new Student();
			// then
			final Field field = pojo.getClass().getDeclaredField("name");
			field.setAccessible(true);
			field.set(pojo, "Talentsprint");

			// when
			final String result = pojo.getName();

			// then
			assertEquals("field wasn't retrieved properly", result,
					"Talentsprint");
			System.out
					.println("#####testGetName | Passed | 4/4 | Checking for getter method: getName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetName | Failed | 0/4 | Checking for getter method: getName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetName | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testSetName() {
		try {

			Student pojo = new Student();
			pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("name");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), "Talentsprint");
			System.out
					.println("#####testSetName | Passed | 4/4 | Checking for setter method: setName().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetName | Failed | 0/4 | Checking for setter method: setName().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetName | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetStudentId() {
		try {

			Student pojo = new Student();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("studentId");
			field.setAccessible(true);
			field.set(pojo, 123);

			// when
			final int result = pojo.getStudentId();

			// then
			assertEquals("field wasn't retrieved properly", result, 123);
			System.out
					.println("#####testGetStudentId | Passed | 4/4 | Checking for getter method: getStudentId().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetStudentId | Failed | 0/4 | Checking for getter method: getStudentId().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetStudentId | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
		;
	}

	@Test
	public void testSetStudentId() {
		try {

			Student pojo = new Student();
			pojo.setStudentId(111);

			// then
			final Field field = pojo.getClass().getDeclaredField("studentId");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 111);
			System.out
					.println("#####testSetStudentId | Passed | 4/4 | Checking for setter method: setStudentId().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetStudentId | Failed | 0/4 | Checking for setter method: setStudentId().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetStudentId | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetStudentId | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetExamFee() {
		try {

			Student pojo = new Student();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("examFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getExamFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetExamFee | Passed | 4/4 | Checking for getter method: getExamFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetExamFee | Failed | 0/4 | Checking for getter method: getExamFee().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetExamFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetExamFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetExamFee() {
		try {

			Student pojo = new Student();
			pojo.setExamFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("examFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetExamFee | Passed | 4/4 | Checking for setter method: setExamFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetExamFee | Failed | 0/4 | Checking for setter method: setExamFee().#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetExamFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testStudent() {
		try {

			assertNotNull(new Student());

			System.out
					.println("#####testStudent | Passed | 5/5 | Checking for default constructor of Student.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testStudent | Failed | 0/5 | Checking for default constructor of Student.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testStudent | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testStudent | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testStudentStringIntDouble() {
		try {
			assertNotNull(new Student("Talentsprint", 101, 500.0));

			System.out
					.println("#####testStudent | Passed | 5/5 | Checking for parameterized constructor of Student.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testStudent | Failed | 0/5 | Checking for parameterized constructor of Student.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testStudent | Failed | 0/5 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testStudent | Failed | 0/5 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsStudent() {
		try {

			assertEquals("Student [name=null, studentId=0, examFee=0.0]",
					new Student().displayDetails());
			assertEquals(
					"Student [name=TalentSprint, studentId=101, examFee=5000.0]",
					new Student("TalentSprint", 101, 5000).displayDetails());

			System.out
					.println("#####testDisplayDetailsStudent | Passed | 4/4 | Checking for displayDetails().#####");

		} catch (AssertionError ae) {
			System.out.println("#####testDisplayDetailsStudent | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testPayFeeStudent() {
		try {

			Student pojo;
			pojo = new Student();
			pojo.setExamFee(5000.0);

			assertEquals("Failed for payFee() in Student, ", 2000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in Student, ", 7000, new Student(
					"Talentsprint", 101, 10000.0).payFee(3000), 0);

			System.out
					.println("#####testPayFeeStudent | Passed | 4/4 | Checking for payFee() in Student.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeStudent | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testToStringStudent() {
		try {

			assertEquals("Student [name=null, studentId=0, examFee=0.0]",
					new Student().toString());
			assertEquals(
					"Student [name=TalentSprint, studentId=101, examFee=5000.0]",
					new Student("TalentSprint", 101, 5000).toString());

			System.out
					.println("#####testToStringStudent | Passed | 4/4 | Checking for toString() in Student.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringStudent | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringStudent | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringStudent | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}
	
//	Hosteller Testcases
	

	@Test
	public void testToStringHosteller() {
		try {

			assertEquals(
					"Hosteller [hostelFee=0.0, name=null, studentId=0, examFee=0.0]",
					new Hosteller().toString());
			assertEquals(
					"Hosteller [hostelFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new Hosteller("TalentSprint", 101, 5000, 10000).toString());

			System.out
					.println("#####testToStringHosteller | Passed | 4/4 | Checking for toString() in Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringHosteller | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringHosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringHosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsHosteller() {
		try {

			assertEquals(
					"Hosteller [hostelFee=0.0, name=null, studentId=0, examFee=0.0]",
					new Hosteller().displayDetails());
			assertEquals(
					"Hosteller [hostelFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new Hosteller("TalentSprint", 101, 5000, 10000).displayDetails());

			System.out
					.println("#####testDisplayDetailsHosteller | Passed | 4/4 | Checking for displayDetails() in Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testDisplayDetailsHosteller | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsHosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsHosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testPayFeeHosteller() {
		try {

			Hosteller pojo;
			pojo = new Hosteller();
			pojo.setExamFee(5000.0);
			pojo.setHostelFee(10000);

			assertEquals("Failed for payFee() in Hosteller, ", 12000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in Hosteller, ", 15000,
					new Hosteller("Talentsprint", 101, 10000.0, 15000)
							.payFee(10000), 0);

			System.out
					.println("#####testPayFeeHosteller | Passed | 4/4 | Checking for payFee() in Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeHosteller | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeHosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeHosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testHosteller() {
		try {

			assertNotNull(new Hosteller());

			System.out
					.println("#####testHosteller | Passed | 4/4 | Checking for default constructor of Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testHosteller | Failed | 0/4 | Checking for default constructor of Hosteller.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testHosteller | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testHosteller | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testHostellerStringIntDoubleDouble() {
		try {
			assertNotNull(new Hosteller("Talentsprint", 101, 500.0, 1000));

			System.out
					.println("#####testHostellerStringIntDoubleDouble | Passed | 4/4 | Checking for parameterized constructor of Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testHostellerStringIntDoubleDouble | Failed | 0/4 | Checking for parameterized constructor of Hosteller.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testHostellerStringIntDoubleDouble | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testHostellerStringIntDoubleDouble | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetHostelFee() {
		try {

			Hosteller pojo = new Hosteller();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("hostelFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getHostelFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetHostelFee | Passed | 4/4 | Checking for getter method: getHostelFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetHostelFee | Failed | 0/4 | Checking for getter method: getHostelFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetHostelFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetHostelFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetHostelFee() {
		try {

			Hosteller pojo = new Hosteller();
			pojo.setHostelFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("hostelFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetExamFee | Passed | 4/4 | Checking for setter method: setHostelFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetExamFee | Failed | 0/4 | Checking for setter method: setHostelFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetExamFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	
//	DayScholar Test cases
	

	@Test
	public void testToStringDayScholar() {
		try {

			assertEquals(
					"DayScholar [transportFee=0.0, name=null, studentId=0, examFee=0.0]",
					new DayScholar().toString());
			assertEquals(
					"DayScholar [transportFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new DayScholar("TalentSprint", 101, 5000, 10000).toString());

			System.out
					.println("#####testToStringDayScholar | Passed | 4/4 | Checking for toString() in DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringDayScholar | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringDayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringDayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsDayScholar() {
		try {

			assertEquals(
					"DayScholar [transportFee=0.0, name=null, studentId=0, examFee=0.0]",
					new DayScholar().displayDetails());
			assertEquals(
					"DayScholar [transportFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new DayScholar("TalentSprint", 101, 5000, 10000)
							.displayDetails());

			System.out
					.println("#####testDisplayDetailsDayScholar | Passed | 4/4 | Checking for displayDetails() in DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testDisplayDetailsDayScholar | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsDayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsDayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testPayFeeDayScholar() {
		try {

			DayScholar pojo;
			pojo = new DayScholar();
			pojo.setExamFee(5000.0);
			pojo.setTransportFee(10000);

			assertEquals("Failed for payFee() in DayScholar, ", 12000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in DayScholar, ", 15000,
					new DayScholar("Talentsprint", 101, 10000.0, 15000)
							.payFee(10000), 0);

			System.out
					.println("#####testPayFeeDayScholar | Passed | 4/4 | Checking for payFee() in DayScholar.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeDayScholar | Failed | 0/4 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeDayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeDayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDayScholar() {
		try {

			assertNotNull(new DayScholar());

			System.out
					.println("#####testDayScholar | Passed | 4/4 | Checking for default constructor of DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDayScholar | Failed | 0/4 | Checking for default constructor of DayScholar.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDayScholar | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testDayScholar | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDayScholarStringIntDoubleDouble() {
		try {
			assertNotNull(new DayScholar("Talentsprint", 101, 500.0, 1000));

			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Passed | 4/4 | Checking for parameterized constructor of DayScholar.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Failed | 0/4 | Checking for parameterized constructor of DayScholar.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testDayScholarStringIntDoubleDouble | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetTransportFee() {
		try {

			DayScholar pojo = new DayScholar();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass()
					.getDeclaredField("transportFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getTransportFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetTransportFee | Passed | 4/4 | Checking for getter method: getTransportFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetTransportFee | Failed | 0/4 | Checking for getter method: getTransportFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetTransportFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetTransportFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetTransportFee() {
		try {

			DayScholar pojo = new DayScholar();
			pojo.setTransportFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("transportFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetTransportFee | Passed | 4/4 | Checking for setter method: setTransportFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetTransportFee | Failed | 0/4 | Checking for setter method: setTransportFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetTransportFee | Failed | 0/4 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetTransportFee | Failed | 0/4 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
