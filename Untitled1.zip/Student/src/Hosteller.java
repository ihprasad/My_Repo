
public class Hosteller extends Student {
	double hostelFee;
	
	public Hosteller()
	{
		this.hostelFee = 0;
	}
	
	public Hosteller(String name, int studentId, double examFee,double hFee)
	{
		super(name,studentId,examFee);
		this.hostelFee = hFee;
	}
	public String toString() {
		return "Hosteller [hostelFee="+hostelFee+", name=" + name + ", studentId=" + studentId
				+ ", examFee=" + examFee  +  "]";
	}

	
	public String displayDetails() {
		return this.toString();
	}

	public double payFee(double amount) {
		double toPay = (this.examFee + this.hostelFee) - amount;
		return toPay;
	}

	public double getHostelFee() {
		return hostelFee;
	}

	public void setHostelFee(double hostelFee) {
		this.hostelFee = hostelFee;
	}
}
