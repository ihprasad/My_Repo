import static org.junit.Assert.*;

import java.lang.reflect.Field;

import org.junit.BeforeClass;
import org.junit.Test;

public class HostellerTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Test
	public void testToStringHosteller() {
		try {

			assertEquals(
					"Hosteller [hostelFee=0.0, name=null, studentId=0, examFee=0.0]",
					new Hosteller().toString());
			assertEquals(
					"Hosteller [hostelFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new Hosteller("TalentSprint", 101, 5000, 10000).toString());

			System.out
					.println("#####testToStringHosteller | Passed | 20/20 | Checking for toString() in Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testToStringHosteller | Failed | 0/20 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testToStringHosteller | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testToStringHosteller | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testDisplayDetailsHosteller() {
		try {

			assertEquals(
					"Hosteller [hostelFee=0.0, name=null, studentId=0, examFee=0.0]",
					new Hosteller().displayDetails());
			assertEquals(
					"Hosteller [hostelFee=10000.0, name=TalentSprint, studentId=101, examFee=5000.0]",
					new Hosteller("TalentSprint", 101, 5000, 10000).displayDetails());

			System.out
					.println("#####testDisplayDetailsHosteller | Passed | 20/20 | Checking for displayDetails() in Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testDisplayDetailsHosteller | Failed | 0/20 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testDisplayDetailsHosteller | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testDisplayDetailsHosteller | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}

	}

	@Test
	public void testPayFeeHosteller() {
		try {

			Hosteller pojo;
			pojo = new Hosteller();
			pojo.setExamFee(5000.0);
			pojo.setHostelFee(10000);

			assertEquals("Failed for payFee() in Hosteller, ", 12000,
					pojo.payFee(3000), 0);

			assertEquals("Failed for payFee() in Hosteller, ", 15000,
					new Hosteller("Talentsprint", 101, 10000.0, 15000)
							.payFee(10000), 0);

			System.out
					.println("#####testPayFeeHosteller | Passed | 20/20 | Checking for payFee() in Hosteller.#####");

		} catch (AssertionError ae) {
			System.out.println("#####testPayFeeHosteller | Failed | 0/20 | "
					+ ae.getMessage() + "#####");

		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testPayFeeHosteller | Failed | 0/20 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testPayFeeHosteller | Failed | 0/20 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testHosteller() {
		try {

			assertNotNull(new Hosteller());

			System.out
					.println("#####testHosteller | Passed | 10/10 | Checking for default constructor of Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testHosteller | Failed | 0/10 | Checking for default constructor of Hosteller.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testHosteller | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testHosteller | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testHostellerStringIntDoubleDouble() {
		try {
			assertNotNull(new Hosteller("Talentsprint", 101, 500.0, 1000));

			System.out
					.println("#####testHostellerStringIntDoubleDouble | Passed | 10/10 | Checking for parameterized constructor of Hosteller.#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testHostellerStringIntDoubleDouble | Failed | 0/10 | Checking for parameterized constructor of Hosteller.#####");
			System.exit(0);
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testHostellerStringIntDoubleDouble | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");
			System.exit(0);

		} catch (Exception e) {
			System.out
					.println("#####testHostellerStringIntDoubleDouble | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testGetHostelFee() {
		try {

			Hosteller pojo = new Hosteller();
			// pojo.setName("Talentsprint");

			// then
			final Field field = pojo.getClass().getDeclaredField("hostelFee");
			field.setAccessible(true);
			field.set(pojo, 500.0);

			// when
			final double result = pojo.getHostelFee();

			// then
			// assertEquals("field wasn't retrieved properly", result, 500.0);
			assertEquals("field wasn't retrieved properly", 500, result, 0);
			System.out
					.println("#####testGetHostelFee | Passed | 10/10 | Checking for getter method: getHostelFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testGetHostelFee | Failed | 0/10 | Checking for getter method: getHostelFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testGetHostelFee | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testGetHostelFee | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

	@Test
	public void testSetHostelFee() {
		try {

			Hosteller pojo = new Hosteller();
			pojo.setHostelFee(5000.0);

			// then
			final Field field = pojo.getClass().getDeclaredField("hostelFee");
			field.setAccessible(true);
			assertEquals("Fields didn't match", field.get(pojo), 5000.0);
			System.out
					.println("#####testSetExamFee | Passed | 10/10 | Checking for setter method: setHostelFee().#####");

		} catch (AssertionError ae) {
			System.out
					.println("#####testSetExamFee | Failed | 0/10 | Checking for setter method: setHostelFee()."
							+ ae.getMessage() + "#####");
		} catch (NoSuchMethodError e) {

			System.out
					.println("#####testSetExamFee | Failed | 0/10 | No such method found: "
							+ e.getMessage() + "#####");

		} catch (Exception e) {
			System.out
					.println("#####testSetName | Failed | 0/10 |Runtime Exception:"
							+ e.getMessage() + "#####");
		}
	}

}
