
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(new DayScholar());
		System.out.println(new DayScholar("TalentSprint", 101, 5000, 10000).toString());

	}

}
